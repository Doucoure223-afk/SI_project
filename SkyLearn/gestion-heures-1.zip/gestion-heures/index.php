<?php
/**
 * ============================================================
 * Point d'entrée principal
 * Gestion des Heures d'Enseignement
 * ============================================================
 */

require_once __DIR__ . '/includes/session.php';

// Si l'utilisateur est connecté, rediriger vers son dashboard
if (isLoggedIn()) {
    $role = getCurrentUserRole();
    
    switch ($role) {
        case 'ADMIN':
            header('Location: admin/dashboard.php');
            break;
        case 'CHEF_DER':
            header('Location: chef_der/dashboard.php');
            break;
        case 'ENSEIGNANT':
            header('Location: enseignant/dashboard.php');
            break;
        case 'RESPONSABLE':
            header('Location: responsable/dashboard.php');
            break;
        default:
            header('Location: login.php');
    }
    exit();
}

// Sinon, rediriger vers la page de connexion
header('Location: login.php');
exit();
?>
