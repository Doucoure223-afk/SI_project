<?php
/**
 * ============================================================
 * Configuration de la connexion à la base de données
 * Couche Données - Architecture 3-tiers
 * ============================================================
 */

class Database {
    // Paramètres de connexion
    private $host = "localhost";
    private $db_name = "gestion_des_heures";
    private $username = "root";
    private $password = "";
    private $conn = null;

    /**
     * Obtenir la connexion PDO
     * @return PDO|null
     */
    public function getConnection() {
        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=utf8mb4",
                $this->username,
                $this->password,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
        } catch(PDOException $e) {
            error_log("Erreur de connexion : " . $e->getMessage());
            die("Erreur de connexion à la base de données.");
        }
        
        return $this->conn;
    }
}
?>
