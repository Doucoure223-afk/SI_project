-- =============================================================
-- SCRIPT DE MISE À JOUR V4
-- Modifications : Classe dans Semestre, Contenu_Seance, Grade obligatoire
-- =============================================================

USE `gestion des heures`;

-- =============================================================
-- 1. Ajout de la colonne Classe dans la table Semestre
-- =============================================================
ALTER TABLE Semestre
    ADD COLUMN Classe VARCHAR(10) NOT NULL DEFAULT 'L1S1' AFTER date_fin;

-- =============================================================
-- 2. Ajout du champ Contenu_Seance dans Seances (remplace Chapitres)
-- =============================================================
ALTER TABLE Seances
    ADD COLUMN Contenu_Seance TEXT NULL AFTER Chapitres_idChapitres;

-- =============================================================
-- 3. Mettre à jour les données de test des semestres
-- =============================================================
UPDATE Semestre SET Classe = 'L3S5' WHERE idSemestre = 1;
UPDATE Semestre SET Classe = 'L3S6' WHERE idSemestre = 2;

-- =============================================================
-- 4. Mettre à jour les classes des responsables existants
-- =============================================================
UPDATE Responsable_Classe SET Classe = 'L3S5' WHERE idResponsable_Classe = 1;
UPDATE Responsable_Classe SET Classe = 'M1S1' WHERE idResponsable_Classe = 2;

-- =============================================================
-- 5. Mettre à jour les grades des enseignants existants
-- =============================================================
UPDATE Enseignants SET Grade = 'Professeur' WHERE idEnseignants = 1;
UPDATE Enseignants SET Grade = 'Maître de conférences' WHERE idEnseignants = 2;
UPDATE Enseignants SET Grade = 'Assistant' WHERE idEnseignants = 3;
