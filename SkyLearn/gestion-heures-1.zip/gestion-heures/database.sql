-- =============================================================
-- SCRIPT SQL - Gestion des Heures d'Enseignement
-- À exécuter dans phpMyAdmin sous WAMP
-- =============================================================

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS;
SET UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS;
SET FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE;
SET SQL_MODE='STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION';

-- Création de la base de données
CREATE SCHEMA IF NOT EXISTS `gestion des heures`
DEFAULT CHARACTER SET utf8mb4
COLLATE utf8mb4_general_ci;

USE `gestion des heures`;

-- =============================================================
-- TABLE: Utilisateurs
-- =============================================================
CREATE TABLE IF NOT EXISTS Utilisateurs (
  idUtilisateurs INT AUTO_INCREMENT PRIMARY KEY,
  Nom VARCHAR(100),
  Prenom VARCHAR(100),
  Login VARCHAR(50) NOT NULL UNIQUE,
  Mot_De_Passe VARCHAR(255) NOT NULL,
  Role ENUM('ADMIN','CHEF_DER','ENSEIGNANT','RESPONSABLE')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================================
-- TABLE: Enseignants
-- =============================================================
CREATE TABLE IF NOT EXISTS Enseignants (
  idEnseignants INT AUTO_INCREMENT PRIMARY KEY,
  Grade VARCHAR(50),
  Utilisateurs_idUtilisateurs INT NOT NULL UNIQUE,
  FOREIGN KEY (Utilisateurs_idUtilisateurs)
    REFERENCES Utilisateurs(idUtilisateurs)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================================
-- TABLE: Chef_DER
-- =============================================================
CREATE TABLE IF NOT EXISTS Chef_DER (
  idChef_DER INT AUTO_INCREMENT PRIMARY KEY,
  Enseignants_idEnseignants INT NOT NULL UNIQUE,
  FOREIGN KEY (Enseignants_idEnseignants)
    REFERENCES Enseignants(idEnseignants)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================================
-- TABLE: Responsable_Classe
-- =============================================================
CREATE TABLE IF NOT EXISTS Responsable_Classe (
  idResponsable_Classe INT AUTO_INCREMENT PRIMARY KEY,
  Classe VARCHAR(20),
  Utilisateurs_idUtilisateurs INT NOT NULL UNIQUE,
  FOREIGN KEY (Utilisateurs_idUtilisateurs)
    REFERENCES Utilisateurs(idUtilisateurs)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================================
-- TABLE: Semestre
-- =============================================================
CREATE TABLE IF NOT EXISTS Semestre (
  idSemestre INT AUTO_INCREMENT PRIMARY KEY,
  date_debut DATE,
  date_fin DATE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================================
-- TABLE: Unite_enseignement
-- =============================================================
CREATE TABLE IF NOT EXISTS Unite_enseignement (
  idUnite_enseignement INT AUTO_INCREMENT PRIMARY KEY,
  Nom VARCHAR(100),
  Semestre_idSemestre INT,
  FOREIGN KEY (Semestre_idSemestre)
    REFERENCES Semestre(idSemestre)
    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================================
-- TABLE: Modules
-- =============================================================
CREATE TABLE IF NOT EXISTS Modules (
  idModules INT AUTO_INCREMENT PRIMARY KEY,
  Nom VARCHAR(100),
  Volume_Horaires_CM INT DEFAULT 0,
  Volume_Horaires_TD INT DEFAULT 0,
  Volume_Horaires_TP INT DEFAULT 0,
  Unite_enseignement_idUnite_enseignement INT,
  FOREIGN KEY (Unite_enseignement_idUnite_enseignement)
    REFERENCES Unite_enseignement(idUnite_enseignement)
    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================================
-- TABLE: Seances
-- =============================================================
CREATE TABLE IF NOT EXISTS Seances (
  idSeances INT AUTO_INCREMENT PRIMARY KEY,
  date_Seance DATE,
  heures_Effectuees INT,
  Type_Seance ENUM('CM','TD','TP'),
  Etat ENUM('En_attente', 'Validée', 'Contestée') DEFAULT 'En_attente',
  Motif_Contestation TEXT NULL,
  Responsable_Classe_idResponsable_Classe INT,
  Modules_idModules INT,
  Enseignants_idEnseignants INT,
  FOREIGN KEY (Responsable_Classe_idResponsable_Classe)
    REFERENCES Responsable_Classe(idResponsable_Classe)
    ON DELETE SET NULL,
  FOREIGN KEY (Modules_idModules)
    REFERENCES Modules(idModules)
    ON DELETE SET NULL,
  FOREIGN KEY (Enseignants_idEnseignants)
    REFERENCES Enseignants(idEnseignants)
    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================================
-- TABLE: Rapports
-- =============================================================
CREATE TABLE IF NOT EXISTS Rapports (
  idRapports INT AUTO_INCREMENT PRIMARY KEY,
  Total_H_Effectuee INT,
  Date_Generation DATETIME DEFAULT CURRENT_TIMESTAMP,
  Chef_DER_idChef_DER INT,
  FOREIGN KEY (Chef_DER_idChef_DER)
    REFERENCES Chef_DER(idChef_DER)
    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================================
-- TABLE: Chapitres
-- =============================================================
CREATE TABLE IF NOT EXISTS Chapitres (
  idChapitres INT AUTO_INCREMENT PRIMARY KEY,
  Nom VARCHAR(100),
  Modules_idModules INT,
  FOREIGN KEY (Modules_idModules)
    REFERENCES Modules(idModules)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================================
-- DONNÉES DE TEST
-- =============================================================

-- Administrateur (mot de passe: admin123)
INSERT INTO Utilisateurs (Nom, Prenom, Login, Mot_De_Passe, Role) VALUES
('Admin', 'Système', 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ADMIN');

-- Chef DER (mot de passe: chef123)
INSERT INTO Utilisateurs (Nom, Prenom, Login, Mot_De_Passe, Role) VALUES
('Dupont', 'Jean', 'chef', '$2y$10$HfzIhGCCaxqyaIdGgjARSuOKAcm1Uy82YfLuNaajn6JrjLWy9Sj/W', 'CHEF_DER');

INSERT INTO Enseignants (Grade, Utilisateurs_idUtilisateurs) VALUES
('Professeur', 2);

INSERT INTO Chef_DER (Enseignants_idEnseignants) VALUES
(1);

-- Enseignants (mot de passe: prof123)
INSERT INTO Utilisateurs (Nom, Prenom, Login, Mot_De_Passe, Role) VALUES
('Martin', 'Pierre', 'prof1', '$2y$10$dI/EB.EgqKc0hkJzT8a3/.Y.dMf0AJPDD0LHxYGNa7TXPLRbFxvbG', 'ENSEIGNANT'),
('Bernard', 'Marie', 'prof2', '$2y$10$dI/EB.EgqKc0hkJzT8a3/.Y.dMf0AJPDD0LHxYGNa7TXPLRbFxvbG', 'ENSEIGNANT');

INSERT INTO Enseignants (Grade, Utilisateurs_idUtilisateurs) VALUES
('Maître de Conférences', 3),
('ATER', 4);

-- Responsables de classe (mot de passe: resp123)
INSERT INTO Utilisateurs (Nom, Prenom, Login, Mot_De_Passe, Role) VALUES
('Leroy', 'Sophie', 'resp1', '$2y$10$dRKlS3VYP.1XG6yTF/Wp5OJmCwLgQr/p0kE5jWG7kT2a3Vj3i8KOq', 'RESPONSABLE'),
('Moreau', 'Lucas', 'resp2', '$2y$10$dRKlS3VYP.1XG6yTF/Wp5OJmCwLgQr/p0kE5jWG7kT2a3Vj3i8KOq', 'RESPONSABLE');

INSERT INTO Responsable_Classe (Classe, Utilisateurs_idUtilisateurs) VALUES
('L3 Informatique', 5),
('M1 Informatique', 6);

-- Semestres
INSERT INTO Semestre (date_debut, date_fin) VALUES
('2024-09-01', '2025-01-31'),
('2025-02-01', '2025-06-30');

-- Unités d'enseignement
INSERT INTO Unite_enseignement (Nom, Semestre_idSemestre) VALUES
('UE Programmation', 1),
('UE Base de données', 1),
('UE Réseaux', 2);

-- Modules
INSERT INTO Modules (Nom, Volume_Horaires_CM, Volume_Horaires_TD, Volume_Horaires_TP, Unite_enseignement_idUnite_enseignement) VALUES
('Programmation Web', 20, 15, 25, 1),
('Algorithmique Avancée', 25, 20, 15, 1),
('SQL et NoSQL', 18, 12, 20, 2),
('Administration BD', 15, 10, 15, 2),
('Protocoles Réseaux', 20, 15, 20, 3);

-- Chapitres
INSERT INTO Chapitres (Nom, Modules_idModules) VALUES
('HTML5 et CSS3', 1),
('JavaScript ES6+', 1),
('PHP et MySQL', 1),
('Complexité algorithmique', 2),
('Structures de données', 2),
('Requêtes SQL avancées', 3),
('MongoDB', 3);

-- Restauration des paramètres
SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
