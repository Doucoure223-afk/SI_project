-- =============================================================
-- SCRIPT DE MISE À JOUR V3
-- Modifications : Semestres, Rapports, Types de séance, Révision
-- =============================================================

USE `gestion des heures`;

-- =============================================================
-- 1. Modification de la table Semestre
--    Ajout état (En_cours / Terminé), date_fin nullable
-- =============================================================
ALTER TABLE Semestre
    ADD COLUMN Etat ENUM('En_cours', 'Terminé') NOT NULL DEFAULT 'En_cours' AFTER date_fin,
    MODIFY COLUMN date_fin DATE NULL DEFAULT NULL;

-- Mettre à jour les semestres existants qui ont une date_fin passée
UPDATE Semestre SET Etat = 'Terminé' WHERE date_fin IS NOT NULL AND date_fin < CURDATE();

-- =============================================================
-- 2. Modification de la table Seances
--    - Ajout Devoir et Examen dans Type_Seance
--    - Renommage Contestée → Revision_demandee
--    - Renommage Motif_Contestation → Motif_Revision
-- =============================================================
ALTER TABLE Seances
    MODIFY COLUMN Type_Seance ENUM('CM', 'TD', 'TP', 'Devoir', 'Examen') NOT NULL,
    MODIFY COLUMN Etat ENUM('En_attente', 'Validée', 'Revision_demandee') NOT NULL DEFAULT 'En_attente';

-- Renommer la colonne Motif_Contestation en Motif_Revision
ALTER TABLE Seances CHANGE COLUMN Motif_Contestation Motif_Revision TEXT NULL;

-- Migrer les anciennes données contestées
UPDATE Seances SET Etat = 'Revision_demandee' WHERE Etat = 'Contestée';

-- =============================================================
-- 3. Modification de la table Rapports
--    Suppression colonnes obsolètes, ajout nouvelles colonnes
-- =============================================================
ALTER TABLE Rapports
    DROP COLUMN Total_H_Effectuee,
    DROP COLUMN Date_Generation,
    ADD COLUMN Semestre_idSemestre INT NULL AFTER idRapports,
    ADD COLUMN Heures_CM_Validees INT DEFAULT 0,
    ADD COLUMN Heures_TD_Validees INT DEFAULT 0,
    ADD COLUMN Heures_TP_Validees INT DEFAULT 0,
    ADD COLUMN Heures_Total_Validees INT DEFAULT 0,
    ADD COLUMN Heures_Total_Prevues INT DEFAULT 0,
    ADD COLUMN Pourcentage_Avancement DECIMAL(5,2) DEFAULT 0.00,
    ADD COLUMN Date_Cloture DATETIME NULL,
    ADD COLUMN Observations TEXT NULL,
    ADD CONSTRAINT fk_rapport_semestre FOREIGN KEY (Semestre_idSemestre)
        REFERENCES Semestre(idSemestre) ON DELETE SET NULL;
