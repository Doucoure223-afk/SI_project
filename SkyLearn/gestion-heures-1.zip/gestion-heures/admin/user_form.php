<?php
/**
 * Point d'entrée - Formulaire utilisateur
 */
require_once __DIR__ . '/../controllers/AdminController.php';

$controller = new AdminController();
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$controller->userForm($id);
?>
