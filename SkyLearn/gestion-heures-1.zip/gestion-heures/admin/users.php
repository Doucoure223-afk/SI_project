<?php
/**
 * Point d'entrée - Liste des utilisateurs
 */
require_once __DIR__ . '/../controllers/AdminController.php';

$controller = new AdminController();
$controller->listUsers();
?>
