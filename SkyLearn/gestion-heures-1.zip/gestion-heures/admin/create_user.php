<?php
/**
 * Point d'entrée - Création utilisateur
 */
require_once __DIR__ . '/../controllers/AdminController.php';

$controller = new AdminController();
$controller->createUser();
?>
