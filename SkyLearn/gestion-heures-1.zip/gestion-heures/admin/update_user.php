<?php
/**
 * Point d'entrée - Modification utilisateur
 */
require_once __DIR__ . '/../controllers/AdminController.php';

$controller = new AdminController();
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

if (!$id) {
    header("Location: users.php");
    exit();
}

$controller->updateUser($id);
?>
