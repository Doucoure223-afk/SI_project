<?php
/**
 * Point d'entrée - Dashboard Admin
 */
require_once __DIR__ . '/../controllers/AdminController.php';

$controller = new AdminController();
$controller->dashboard();
?>
