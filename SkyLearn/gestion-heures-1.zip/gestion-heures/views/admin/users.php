<?php
/**
 * Liste des utilisateurs - Admin
 */
$pageTitle = "Gestion des utilisateurs";
require_once __DIR__ . '/../templates/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Liste des utilisateurs</h2>
        <div style="display: flex; gap: 10px; align-items: center;">
            <input type="text" id="table-search" class="form-control" placeholder="Rechercher..." style="width: 200px;">
            <a href="<?= url('admin/user_form.php') ?>" class="btn btn-primary">
                <i class="fas fa-plus"></i> Nouvel utilisateur
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <!--<th>ID</th>-->
                        <th>Nom complet</th>
                        <th>Login</th>
                        <th>Rôle</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($users)): ?>
                        <tr>
                            <td colspan="5" class="text-center">Aucun utilisateur trouvé.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($users as $user): ?>
                        <tr>
                            <!--<td><?= $user['idUtilisateurs'] ?></td>-->
                            <td>
                                <strong><?= escape($user['Prenom'] . ' ' . $user['Nom']) ?></strong>
                            </td>
                            <td><?= escape($user['Login']) ?></td>
                            <td>
                                <span class="badge badge-<?= 
                                    $user['Role'] === 'ADMIN' ? 'danger' : 
                                    ($user['Role'] === 'CHEF_DER' ? 'warning' : 
                                    ($user['Role'] === 'ENSEIGNANT' ? 'success' : 'info')) 
                                ?>">
                                    <?= getRoleLabel($user['Role']) ?>
                                </span>
                            </td>
                            <td class="actions">
                                <a href="<?= url('admin/user_form.php?id=' . $user['idUtilisateurs']) ?>" 
                                   class="btn btn-outline btn-sm" title="Modifier">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <?php if ($user['idUtilisateurs'] != getCurrentUserId()): ?>
                                <a href="<?= url('admin/delete_user.php?id=' . $user['idUtilisateurs']) ?>" 
                                   class="btn btn-danger btn-sm"
                                   data-confirm="Êtes-vous sûr de vouloir supprimer cet utilisateur ?"
                                   title="Supprimer">
                                    <i class="fas fa-trash"></i>
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
