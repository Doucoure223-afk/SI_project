<?php
/**
 * Dashboard Administrateur
 */
$pageTitle = "Tableau de bord Administrateur";
require_once __DIR__ . '/../templates/header.php';
?>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon primary">
            <i class="fas fa-users"></i>
        </div>
        <div class="stat-content">
            <h3><?= $stats['total_users'] ?></h3>
            <p>Utilisateurs totaux</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon warning">
            <i class="fas fa-user-shield"></i>
        </div>
        <div class="stat-content">
            <h3><?= $stats['admins'] ?></h3>
            <p>Administrateurs</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon success">
            <i class="fas fa-chalkboard-teacher"></i>
        </div>
        <div class="stat-content">
            <h3><?= $stats['enseignants'] ?></h3>
            <p>Enseignants</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon info">
            <i class="fas fa-user-graduate"></i>
        </div>
        <div class="stat-content">
            <h3><?= $stats['responsables'] ?></h3>
            <p>Responsables de classe</p>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Actions rapides</h2>
    </div>
    <div class="card-body">
        <div style="display: flex; gap: 15px; flex-wrap: wrap;">
            <a href="<?= url('admin/user_form.php') ?>" class="btn btn-primary">
                <i class="fas fa-user-plus"></i> Créer un utilisateur
            </a>
            <a href="<?= url('admin/users.php') ?>" class="btn btn-secondary">
                <i class="fas fa-list"></i> Voir tous les utilisateurs
            </a>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Derniers utilisateurs</h2>
        <a href="<?= url('admin/users.php') ?>" class="btn btn-outline btn-sm">Voir tout</a>
    </div>
    <div class="card-body">
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Login</th>
                        <th>Rôle</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $latestUsers = array_slice($users, 0, 5);
                    foreach ($latestUsers as $user): 
                    ?>
                    <tr>
                        <td><?= escape($user['Prenom'] . ' ' . $user['Nom']) ?></td>
                        <td><?= escape($user['Login']) ?></td>
                        <td><?= getRoleLabel($user['Role']) ?></td>
                        <td class="actions">
                            <a href="<?= url('admin/user_form.php?id=' . $user['idUtilisateurs']) ?>" class="btn btn-outline btn-sm">
                                <i class="fas fa-edit"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
