<?php
/**
 * Formulaire création/modification utilisateur - Admin
 */
$pageTitle = $user ? "Modifier l'utilisateur" : "Nouvel utilisateur";
require_once __DIR__ . '/../templates/header.php';
$grades = getGradesList();
$classes = getClassesList();
$currentGrade = $enseignant['Grade'] ?? '';
$currentClasse = $responsable['Classe'] ?? '';
?>

<div class="card" style="max-width: 600px;">
    <div class="card-header">
        <h2 class="card-title"><?= $pageTitle ?></h2>
    </div>
    <div class="card-body">
        <form action="<?= $user ? url('admin/update_user.php?id=' . $user['idUtilisateurs']) : url('admin/create_user.php') ?>" 
              method="POST" data-validate>
            <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
            
            <div class="form-row">
                <div class="form-group">
                    <label for="prenom" class="form-label">Prénom *</label>
                    <input type="text" id="prenom" name="prenom" class="form-control" 
                           value="<?= escape($user['Prenom'] ?? '') ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="nom" class="form-label">Nom *</label>
                    <input type="text" id="nom" name="nom" class="form-control" 
                           value="<?= escape($user['Nom'] ?? '') ?>" required>
                </div>
            </div>
            
            <div class="form-group">
                <label for="login" class="form-label">Login *</label>
                <input type="text" id="login" name="login" class="form-control" 
                       value="<?= escape($user['Login'] ?? '') ?>" required>
            </div>
            
            <div class="form-group">
                <label for="password" class="form-label">
                    Mot de passe <?= $user ? '(laisser vide pour conserver)' : '*' ?>
                </label>
                <input type="password" id="password" name="password" class="form-control" 
                       <?= $user ? '' : 'required' ?>>
            </div>
            
            <div class="form-group">
                <label for="role" class="form-label">Rôle *</label>
                <select id="role" name="role" class="form-control" required>
                    <option value="">Sélectionner un rôle</option>
                    <option value="ADMIN" <?= ($user['Role'] ?? '') === 'ADMIN' ? 'selected' : '' ?>>
                        Administrateur
                    </option>
                    <option value="CHEF_DER" <?= ($user['Role'] ?? '') === 'CHEF_DER' ? 'selected' : '' ?>>
                        Chef de DER
                    </option>
                    <option value="ENSEIGNANT" <?= ($user['Role'] ?? '') === 'ENSEIGNANT' ? 'selected' : '' ?>>
                        Enseignant
                    </option>
                    <option value="RESPONSABLE" <?= ($user['Role'] ?? '') === 'RESPONSABLE' ? 'selected' : '' ?>>
                        Responsable de classe
                    </option>
                </select>
            </div>
            
            <!-- Champ Grade (pour Enseignant/Chef DER) -->
            <div class="form-group" id="grade-field" style="display: none;">
                <label for="grade" class="form-label">Grade *</label>
                <select id="grade" name="grade" class="form-control">
                    <option value="">Sélectionner un grade</option>
                    <?php foreach ($grades as $code => $label): ?>
                        <option value="<?= escape($code) ?>" <?= $currentGrade === $code ? 'selected' : '' ?>>
                            <?= escape($label) ?>
                        </option>
                    <?php endforeach; ?>
                    <option value="Autre" <?= (!empty($currentGrade) && !isset($grades[$currentGrade])) ? 'selected' : '' ?>>
                        Autre
                    </option>
                </select>
                <div id="grade-autre-field" style="display: <?= (!empty($currentGrade) && !isset($grades[$currentGrade])) ? 'block' : 'none' ?>;">
                    <input type="text" id="grade_autre" name="grade_autre" class="form-control" 
                           value="<?= (!empty($currentGrade) && !isset($grades[$currentGrade])) ? escape($currentGrade) : '' ?>"
                           placeholder="Précisez le grade...">
                </div>
            </div>
            
            <!-- Champ Classe (pour Responsable) -->
            <div class="form-group" id="classe-field" style="display: none;">
                <label for="classe" class="form-label">Classe *</label>
                <select id="classe" name="classe" class="form-control">
                    <option value="">Sélectionner une classe</option>
                    <?php foreach ($classes as $code => $label): ?>
                        <option value="<?= escape($code) ?>" <?= $currentClasse === $code ? 'selected' : '' ?>>
                            <?= escape($code . ' - ' . $label) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div style="display: flex; gap: 10px; margin-top: 20px;">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <?= $user ? 'Modifier' : 'Créer' ?>
                </button>
                <a href="<?= url('admin/users.php') ?>" class="btn btn-outline">
                    <i class="fas fa-times"></i> Annuler
                </a>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
