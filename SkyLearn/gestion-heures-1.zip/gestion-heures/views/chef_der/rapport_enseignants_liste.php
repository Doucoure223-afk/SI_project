<?php
/**
 * Liste des enseignants avec statistiques - Chef DER (filtré par classe)
 */
$pageTitle = "Rapport par enseignant";
if (!empty($classeFilter)) {
    $pageTitle .= " — Classe " . $classeFilter;
}
require_once __DIR__ . '/../templates/header.php';
?>

<div class="card" style="margin-bottom: 20px;">
    <div class="card-body" style="display: flex; align-items: center; gap: 15px; flex-wrap: wrap;">
        <label for="classe-select" style="font-weight: bold; white-space: nowrap;">
            <i class="fas fa-graduation-cap"></i> Classe :
        </label>
        <select id="classe-select" class="form-control" style="max-width: 250px;"
                onchange="window.location.href='<?= url('chef_der/rapport_enseignants.php') ?>?classe=' + this.value">
            <option value="">-- Toutes les classes --</option>
            <?php foreach ($allClasses as $clKey => $clLabel): ?>
                <option value="<?= $clKey ?>" <?= $classeFilter === $clKey ? 'selected' : '' ?>><?= $clKey ?> — <?= $clLabel ?></option>
            <?php endforeach; ?>
        </select>
        <?php if ($classeFilter): ?>
            <span class="badge badge-primary"><?= escape($classeFilter) ?></span>
            <a href="<?= url('chef_der/rapport_enseignants.php') ?>" class="btn btn-outline btn-sm">
                <i class="fas fa-times"></i> Réinitialiser
            </a>
        <?php endif; ?>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title"><i class="fas fa-user-tie"></i> Heures par enseignant</h2>
        <?php $classeParam = !empty($classeFilter) ? '?classe=' . $classeFilter : ''; ?>
        <a href="<?= url('chef_der/rapport_global.php') . $classeParam ?>" class="btn btn-outline btn-sm">
            <i class="fas fa-arrow-left"></i> Rapport global
        </a>
    </div>
    <div class="card-body">
        <?php if (empty($statsEnseignants)): ?>
            <p style="color: var(--text-muted); text-align: center;">Aucun enseignant enregistré<?= $classeFilter ? ' pour la classe ' . escape($classeFilter) : '' ?>.</p>
        <?php else: ?>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Enseignant</th>
                            <th>Grade</th>
                            <th>Séances</th>
                            <th>Heures validées</th>
                            <th>Heures en attente</th>
                            <th>Total heures</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($statsEnseignants as $ens): ?>
                        <tr>
                            <td><strong><?= escape($ens['enseignant_nom']) ?></strong></td>
                            <td><?= escape($ens['Grade'] ?? 'N/A') ?></td>
                            <td><?= $ens['total_seances'] ?></td>
                            <td><span class="badge badge-success"><?= $ens['heures_validees'] ?>h</span></td>
                            <td><span class="badge badge-warning"><?= $ens['heures_en_attente'] ?>h</span></td>
                            <td><?= $ens['heures_totales'] ?>h</td>
                            <td>
                                <a href="<?= url('chef_der/rapport_enseignants.php?id=' . $ens['idEnseignants']) . ($classeFilter ? '&classe=' . $classeFilter : '') ?>" class="btn btn-outline btn-sm">
                                    <i class="fas fa-eye"></i> Détails
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>