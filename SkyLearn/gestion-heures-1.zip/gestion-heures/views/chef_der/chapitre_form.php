<?php
/**
 * Formulaire création/modification chapitre - Chef DER
 */
$pageTitle = $chapitre ? "Modifier le chapitre" : "Nouveau chapitre";
require_once __DIR__ . '/../templates/header.php';
?>

<div class="card" style="max-width: 500px;">
    <div class="card-header">
        <h2 class="card-title"><?= $pageTitle ?></h2>
    </div>
    <div class="card-body">
        <form action="<?= $chapitre ? url('chef_der/update_chapitre.php?id=' . $chapitre['idChapitres']) : url('chef_der/create_chapitre.php') ?>" 
              method="POST" data-validate>
            <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
            
            <div class="form-group">
                <label for="nom" class="form-label">Nom du chapitre *</label>
                <input type="text" id="nom" name="nom" class="form-control" 
                       value="<?= escape($chapitre['Nom'] ?? '') ?>" required
                       placeholder="Ex: Introduction aux bases de données">
            </div>
            
            <div class="form-group">
                <label for="module" class="form-label">Module *</label>
                <select id="module" name="module_id" class="form-control" required>
                    <option value="">Sélectionner un module</option>
                    <?php foreach ($modules as $mod): ?>
                        <option value="<?= $mod['idModules'] ?>" 
                                <?= ($chapitre['Modules_idModules'] ?? '') == $mod['idModules'] ? 'selected' : '' ?>>
                            <?= escape($mod['Nom']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div style="display: flex; gap: 10px; margin-top: 20px;">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <?= $chapitre ? 'Modifier' : 'Créer' ?>
                </button>
                <a href="<?= url('chef_der/chapitres.php') ?>" class="btn btn-outline">
                    <i class="fas fa-times"></i> Annuler
                </a>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
