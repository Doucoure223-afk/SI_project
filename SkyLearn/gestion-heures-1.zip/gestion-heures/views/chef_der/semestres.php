<?php
/**
 * Liste des semestres - Chef DER (organisé par classe)
 */
$pageTitle = "Gestion des Semestres";
require_once __DIR__ . '/../templates/header.php';
$classes = getClassesList();

// Grouper les semestres par classe
$semestresByClasse = [];
foreach ($semestres as $sem) {
    $classe = $sem['Classe'] ?? 'Non défini';
    $semestresByClasse[$classe][] = $sem;
}
?>

<div class="card">
    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
        <h2 class="card-title">Liste des Semestres</h2>
        <a href="<?= url('chef_der/semestre_form.php') ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> Nouveau semestre
        </a>
    </div>
    <div class="card-body">
        <?php if (empty($semestres)): ?>
            <p class="text-center" style="color: var(--text-muted);">Aucun semestre enregistré.</p>
        <?php else: ?>
            <?php foreach ($semestresByClasse as $classe => $classSemestres): ?>
                <div class="classe-section">
                    <i class="fas fa-graduation-cap"></i> <?= escape($classe) ?> 
                    <?php if (isset($classes[$classe])): ?>
                        - <?= escape($classes[$classe]) ?>
                    <?php endif; ?>
                </div>
                <div class="table-container" style="margin-bottom: 20px;">
                    <table>
                        <thead>
                            <tr>
                                <!--<th>ID</th>-->
                                <th>Date début</th>
                                <th>Date fin</th>
                                <th>État</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($classSemestres as $sem): ?>
                                <tr>
                                    <!--<td><?= $sem['idSemestre'] ?></td>-->
                                    <td><?= date('d/m/Y', strtotime($sem['date_debut'])) ?></td>
                                    <td><?= !empty($sem['date_fin']) ? date('d/m/Y', strtotime($sem['date_fin'])) : '<em>En cours</em>' ?></td>
                                    <td><?= getEtatSemestreLabel($sem['Etat']) ?></td>
                                    <td>
                                        <?php if ($sem['Etat'] === 'En_cours'): ?>
                                            <a href="<?= url('chef_der/semestre_form.php?id=' . $sem['idSemestre']) ?>" 
                                               class="btn btn-sm btn-outline" title="Modifier">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="<?= url('chef_der/cloturer_semestre.php?id=' . $sem['idSemestre']) ?>" 
                                               class="btn btn-sm btn-danger"
                                               onclick="return confirm('⚠️ Attention : En mettant fin à ce semestre, aucune modification ne sera possible par la suite. Cette action est irréversible.\n\nVoulez-vous continuer ?')" 
                                               title="Mettre fin au semestre">
                                                <i class="fas fa-stop-circle"></i> Mettre fin
                                            </a>
                                            <a href="<?= url('chef_der/delete_semestre.php?id=' . $sem['idSemestre']) ?>" 
                                               class="btn btn-sm btn-danger" 
                                               onclick="return confirm('Supprimer ce semestre ?')" title="Supprimer">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        <?php endif; ?>
                                        
                                        <div style="display: inline-flex; gap: 5px; margin-top: <?= $sem['Etat'] === 'En_cours' ? '5px' : '0' ?>;">
                                            <a href="<?= url('chef_der/rapport_global.php?semestre=' . $sem['idSemestre']) ?>" 
                                               class="btn btn-sm btn-info" title="Rapport global">
                                                <i class="fas fa-chart-bar"></i> Global
                                            </a>
                                            <a href="<?= url('chef_der/rapport_modules.php?semestre=' . $sem['idSemestre']) ?>" 
                                               class="btn btn-sm btn-primary" title="Rapport par module">
                                                <i class="fas fa-chart-pie"></i> Modules
                                            </a>
                                            <a href="<?= url('chef_der/rapport_enseignants.php?semestre=' . $sem['idSemestre']) ?>" 
                                               class="btn btn-sm btn-secondary" title="Rapport par enseignant">
                                                <i class="fas fa-user-tie"></i> Enseignants
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
