<?php
/**
 * Rapport global - Chef de DER (filtré par classe)
 */
$pageTitle = "Rapport global";
if (!empty($classeFilter)) {
    $pageTitle .= " — Classe " . $classeFilter;
}
require_once __DIR__ . '/../templates/header.php';
?>

<!-- Sélecteur de classe -->
<div class="card" style="margin-bottom: 20px;">
    <div class="card-body" style="display: flex; align-items: center; gap: 15px; flex-wrap: wrap;">
        <label for="classe-select" style="font-weight: bold; white-space: nowrap;">
            <i class="fas fa-graduation-cap"></i> Classe :
        </label>
        <select id="classe-select" class="form-control" style="max-width: 250px;"
                onchange="window.location.href='<?= url('chef_der/rapport_global.php') ?>?classe=' + this.value">
            <option value="">-- Toutes les classes --</option>
            <?php foreach ($allClasses as $clKey => $clLabel): ?>
                <option value="<?= $clKey ?>" <?= $classeFilter === $clKey ? 'selected' : '' ?>><?= $clKey ?> — <?= $clLabel ?></option>
            <?php endforeach; ?>
        </select>
        <?php if ($classeFilter): ?>
            <span class="badge badge-primary"><?= escape($classeFilter) ?></span>
            <a href="<?= url('chef_der/rapport_global.php') ?>" class="btn btn-outline btn-sm">
                <i class="fas fa-times"></i> Réinitialiser
            </a>
        <?php endif; ?>
    </div>
</div>

<div style="display: flex; justify-content: flex-end; gap: 10px; margin-bottom: 20px;">
    <button id="print-report" class="btn btn-outline">
        <i class="fas fa-print"></i> Imprimer
    </button>
    <button id="export-csv" class="btn btn-outline">
        <i class="fas fa-download"></i> Exporter CSV
    </button>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon success">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="stat-content">
            <h3><?= $stats['heures_validees'] ?? 0 ?>h</h3>
            <p>Heures validées</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon warning">
            <i class="fas fa-clock"></i>
        </div>
        <div class="stat-content">
            <h3><?= $stats['heures_en_attente'] ?? 0 ?>h</h3>
            <p>Heures en attente</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon primary">
            <i class="fas fa-calendar-check"></i>
        </div>
        <div class="stat-content">
            <h3><?= $stats['total'] ?? 0 ?></h3>
            <p>Séances totales</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon info">
            <i class="fas fa-percentage"></i>
        </div>
        <div class="stat-content">
            <h3><?= $pourcentageGlobal ?>%</h3>
            <p>Avancement global</p>
        </div>
    </div>
</div>

<!-- Répartition par type -->
<div class="card">
    <div class="card-header">
        <h2 class="card-title">Répartition par type de séance (validées)</h2>
    </div>
    <div class="card-body">
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 30px; text-align: center;">
            <div>
                <div style="font-size: 2.5rem; font-weight: bold; color: var(--success-color);">
                    <?= $stats['cm_valides'] ?? 0 ?>h
                </div>
                <div style="color: var(--text-muted);">Cours Magistraux</div>
            </div>
            <div>
                <div style="font-size: 2.5rem; font-weight: bold; color: var(--info-color);">
                    <?= $stats['td_valides'] ?? 0 ?>h
                </div>
                <div style="color: var(--text-muted);">Travaux Dirigés</div>
            </div>
            <div>
                <div style="font-size: 2.5rem; font-weight: bold; color: var(--warning-color);">
                    <?= $stats['tp_valides'] ?? 0 ?>h
                </div>
                <div style="color: var(--text-muted);">Travaux Pratiques</div>
            </div>
        </div>
    </div>
</div>

<!-- Liens vers rapports détaillés -->
<div class="card">
    <div class="card-body" style="display: flex; gap: 15px; flex-wrap: wrap;">
        <?php $classeParam = $classeFilter ? '?classe=' . $classeFilter : ''; ?>
        <a href="<?= url('chef_der/rapport_modules.php') . $classeParam ?>" class="btn btn-primary">
            <i class="fas fa-chart-pie"></i> Rapport par module
        </a>
        <a href="<?= url('chef_der/rapport_enseignants.php') . $classeParam ?>" class="btn btn-secondary">
            <i class="fas fa-user-tie"></i> Rapport par enseignant
        </a>
    </div>
</div>

<!-- Historique des séances -->
<div class="card">
    <div class="card-header">
        <h2 class="card-title">Historique des séances</h2>
        <input type="text" id="table-search" class="form-control" placeholder="Rechercher..." style="width: 200px;">
    </div>
    <div class="card-body">
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Module</th>
                        <th>Contenu</th>
                        <th>UE</th>
                        <th>Type</th>
                        <th>Heures</th>
                        <th>Enseignant</th>
                        <th>Saisi par</th>
                        <th>État</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($seances)): ?>
                        <tr>
                            <td colspan="9" style="text-align: center;">Aucune séance enregistrée.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($seances as $seance): ?>
                        <tr>
                            <td><?= formatDateFr($seance['date_Seance']) ?></td>
                            <td><?= escape($seance['module_nom']) ?></td>
                            <td><?= escape($seance['Contenu_Seance'] ?? '-') ?></td>
                            <td><?= escape($seance['ue_nom'] ?? '-') ?></td>
                            <td><span class="badge badge-info"><?= $seance['Type_Seance'] ?></span></td>
                            <td><?= $seance['heures_Effectuees'] ?>h</td>
                            <td><?= escape($seance['enseignant_nom']) ?></td>
                            <td>
                                <?= escape($seance['responsable_nom']) ?>
                                <br><small style="color: var(--text-muted);"><?= escape($seance['Classe'] ?? $seance['classe_semestre'] ?? '') ?></small>
                            </td>
                            <td><?= getEtatLabel($seance['Etat']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>