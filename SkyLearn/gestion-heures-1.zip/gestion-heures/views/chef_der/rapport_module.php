<?php
/**
 * Rapport par module - Chef DER
 */
$pageTitle = "Rapport Module: " . escape($module['Nom']);
require_once __DIR__ . '/../templates/header.php';
$semParam = $semestreInfo ? '&semestre=' . $semestreInfo['idSemestre'] : '';
$semParamFirst = $semestreInfo ? '?semestre=' . $semestreInfo['idSemestre'] : '';
?>

<div class="card">
    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
        <h2 class="card-title"><?= $pageTitle ?></h2>
        <a href="<?= url('chef_der/rapport_modules.php') . $semParamFirst ?>" class="btn btn-outline">
            <i class="fas fa-arrow-left"></i> Retour
        </a>
    </div>
    <div class="card-body">
        <?php if ($semestreInfo): ?>
            <div style="margin-bottom: 20px; padding: 10px; background: var(--gray-light); border-radius: 5px;">
                <i class="fas fa-calendar-alt"></i> 
                <strong>Semestre :</strong> 
                <?= date('d/m/Y', strtotime($semestreInfo['date_debut'])) ?>
                <?= !empty($semestreInfo['date_fin']) ? ' — ' . date('d/m/Y', strtotime($semestreInfo['date_fin'])) : ' — En cours' ?>
            </div>
        <?php endif; ?>

        <!-- Volumes horaires -->
        <h3 style="margin-bottom: 15px;">Volumes horaires</h3>
        <div class="stats-grid" style="margin-bottom: 30px;">
            <div class="stat-card">
                <div class="stat-info" style="text-align: center;">
                    <span class="stat-value" style="color: var(--primary);">
                        <?= $stats['cm_effectue'] ?? 0 ?> / <?= $module['Volume_Horaires_CM'] ?>h
                    </span>
                    <span class="stat-label">CM (<?= $stats['cm_restant'] ?? $module['Volume_Horaires_CM'] ?>h restant)</span>
                    <div class="progress" style="margin-top: 10px;">
                        <div class="progress-bar" style="width: <?= $module['Volume_Horaires_CM'] > 0 ? (($stats['cm_effectue'] ?? 0) / $module['Volume_Horaires_CM'] * 100) : 0 ?>%;"></div>
                    </div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-info" style="text-align: center;">
                    <span class="stat-value" style="color: var(--success);">
                        <?= $stats['td_effectue'] ?? 0 ?> / <?= $module['Volume_Horaires_TD'] ?>h
                    </span>
                    <span class="stat-label">TD (<?= $stats['td_restant'] ?? $module['Volume_Horaires_TD'] ?>h restant)</span>
                    <div class="progress" style="margin-top: 10px;">
                        <div class="progress-bar bg-success" style="width: <?= $module['Volume_Horaires_TD'] > 0 ? (($stats['td_effectue'] ?? 0) / $module['Volume_Horaires_TD'] * 100) : 0 ?>%;"></div>
                    </div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-info" style="text-align: center;">
                    <span class="stat-value" style="color: var(--warning);">
                        <?= $stats['tp_effectue'] ?? 0 ?> / <?= $module['Volume_Horaires_TP'] ?>h
                    </span>
                    <span class="stat-label">TP (<?= $stats['tp_restant'] ?? $module['Volume_Horaires_TP'] ?>h restant)</span>
                    <div class="progress" style="margin-top: 10px;">
                        <div class="progress-bar bg-warning" style="width: <?= $module['Volume_Horaires_TP'] > 0 ? (($stats['tp_effectue'] ?? 0) / $module['Volume_Horaires_TP'] * 100) : 0 ?>%;"></div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Enseignants intervenants -->
        <h3 style="margin-bottom: 15px;">Enseignants intervenants</h3>
        <?php if (empty($enseignants)): ?>
            <p style="color: var(--gray);">Aucun enseignant n'est intervenu sur ce module.</p>
        <?php else: ?>
            <table class="table" style="margin-bottom: 30px;">
                <thead>
                    <tr>
                        <th>Enseignant</th>
                        <th>Grade</th>
                        <th>Heures effectuées</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($enseignants as $ens): ?>
                        <tr>
                            <td><?= escape($ens['Prenom'] . ' ' . $ens['Nom']) ?></td>
                            <td><?= escape($ens['Grade'] ?? 'N/A') ?></td>
                            <td><?= $ens['total_heures'] ?>h</td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
        
        <!-- Chapitres -->
        <h3 style="margin-bottom: 15px;">Chapitres du module</h3>
        <?php if (empty($chapitres)): ?>
            <p style="color: var(--gray);">Aucun chapitre défini pour ce module.</p>
        <?php else: ?>
            <ul style="list-style: none; padding: 0;">
                <?php foreach ($chapitres as $index => $chap): ?>
                    <li style="padding: 10px; background: var(--gray-light); margin-bottom: 5px; border-radius: 5px;">
                        <i class="fas fa-bookmark" style="color: var(--primary); margin-right: 10px;"></i>
                        Chapitre <?= $index + 1 ?>: <?= escape($chap['Nom']) ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
        
        <!-- Historique des séances -->
        <h3 style="margin: 30px 0 15px;">Historique des séances</h3>
        <?php if (empty($seances)): ?>
            <p style="color: var(--gray);">Aucune séance enregistrée pour ce module.</p>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Enseignant</th>
                        <th>Type</th>
                        <th>Heures</th>
                        <th>État</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($seances as $seance): ?>
                        <tr>
                            <td><?= date('d/m/Y', strtotime($seance['date_Seance'])) ?></td>
                            <td><?= escape($seance['enseignant_nom'] ?? 'N/A') ?></td>
                            <td>
                                <span class="badge badge-<?= strtolower($seance['Type_Seance']) ?>">
                                    <?= $seance['Type_Seance'] ?>
                                </span>
                            </td>
                            <td><?= $seance['heures_Effectuees'] ?>h</td>
                            <td>
                                <?php if ($seance['Etat'] === 'Validée'): ?>
                                    <span class="badge badge-success">Validée</span>
                                <?php else: ?>
                                    <span class="badge badge-warning">En attente</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<style>
.progress {
    height: 8px;
    background: var(--gray-light);
    border-radius: 4px;
    overflow: hidden;
}
.progress-bar {
    height: 100%;
    background: var(--primary);
    transition: width 0.3s ease;
}
.progress-bar.bg-success { background: var(--success); }
.progress-bar.bg-warning { background: var(--warning); }
</style>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
