<?php
/**
 * Liste des unités d'enseignement - Chef DER (organisé par classe)
 */
$pageTitle = "Gestion des Unités d'Enseignement";
require_once __DIR__ . '/../templates/header.php';
$classes = getClassesList();

// Grouper les UE par classe (via semestre)
$uesByClasse = [];
foreach ($unites as $ue) {
    $classe = $ue['classe'] ?? 'Non défini';
    $uesByClasse[$classe][] = $ue;
}
?>

<div class="card">
    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
        <h2 class="card-title">Liste des Unités d'Enseignement</h2>
        <a href="<?= url('chef_der/unite_form.php') ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> Nouvelle UE
        </a>
    </div>
    <div class="card-body">
        <?php if (empty($unites)): ?>
            <p class="text-center" style="color: var(--text-muted);">Aucune unité d'enseignement enregistrée.</p>
        <?php else: ?>
            <?php foreach ($uesByClasse as $classe => $classUes): ?>
                <div class="classe-section">
                    <i class="fas fa-graduation-cap"></i> <?= escape($classe) ?>
                    <?php if (isset($classes[$classe])): ?>
                        - <?= escape($classes[$classe]) ?>
                    <?php endif; ?>
                </div>
                <div class="table-container" style="margin-bottom: 20px;">
                    <table>
                        <thead>
                            <tr>
                                <th>Nom</th>
                                <th>Semestre</th>
                                <th>Nb Modules</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($classUes as $ue): ?>
                                <tr>
                                    <td><?= escape($ue['Nom']) ?></td>
                                    <td>
                                        <?php if ($ue['date_debut']): ?>
                                            <?= date('d/m/Y', strtotime($ue['date_debut'])) ?> - <?= !empty($ue['date_fin']) ? date('d/m/Y', strtotime($ue['date_fin'])) : 'En cours' ?>
                                        <?php else: ?>
                                            <span style="color: var(--text-muted);">Non défini</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= $ue['nb_modules'] ?? 0 ?></td>
                                    <td>
                                        <a href="<?= url('chef_der/unite_form.php?id=' . $ue['idUnite_enseignement']) ?>" 
                                           class="btn btn-sm btn-outline" title="Modifier">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="<?= url('chef_der/delete_unite.php?id=' . $ue['idUnite_enseignement']) ?>" 
                                           class="btn btn-sm btn-danger" 
                                           onclick="return confirm('Supprimer cette UE ?')" title="Supprimer">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
