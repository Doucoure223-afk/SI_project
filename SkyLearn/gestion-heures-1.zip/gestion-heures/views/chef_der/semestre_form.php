<?php
/**
 * Formulaire création/modification semestre - Chef DER
 */
$pageTitle = $semestre ? "Modifier le semestre" : "Nouveau semestre";
require_once __DIR__ . '/../templates/header.php';
$classes = getClassesList();
?>

<div class="card" style="max-width: 500px;">
    <div class="card-header">
        <h2 class="card-title"><?= $pageTitle ?></h2>
    </div>
    <div class="card-body">
        <?php if ($semestre && $semestre['Etat'] === 'Terminé'): ?>
            <div class="alert alert-danger">
                <i class="fas fa-lock"></i>
                Ce semestre est terminé et ne peut plus être modifié.
            </div>
            <a href="<?= url('chef_der/semestres.php') ?>" class="btn btn-outline">
                <i class="fas fa-arrow-left"></i> Retour
            </a>
        <?php else: ?>
            <form action="<?= $semestre ? url('chef_der/update_semestre.php?id=' . $semestre['idSemestre']) : url('chef_der/create_semestre.php') ?>" 
                  method="POST" data-validate>
                <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                
                <div class="form-group">
                    <label for="classe" class="form-label">Classe *</label>
                    <select id="classe" name="classe" class="form-control" required>
                        <option value="">Sélectionner une classe</option>
                        <?php foreach ($classes as $code => $label): ?>
                            <option value="<?= $code ?>" <?= ($semestre['Classe'] ?? '') === $code ? 'selected' : '' ?>>
                                <?= escape($code . ' - ' . $label) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="date_debut" class="form-label">Date de début *</label>
                    <input type="date" id="date_debut" name="date_debut" class="form-control" 
                           value="<?= escape($semestre['date_debut'] ?? '') ?>" required>
                </div>
                
                <?php if (!$semestre): ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    Le semestre sera créé avec l'état <strong>"En cours"</strong>. 
                    La date de fin sera enregistrée automatiquement lors de la clôture du semestre.
                </div>
                <?php endif; ?>
                
                <div style="display: flex; gap: 10px; margin-top: 20px;">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> <?= $semestre ? 'Modifier' : 'Créer' ?>
                    </button>
                    <a href="<?= url('chef_der/semestres.php') ?>" class="btn btn-outline">
                        <i class="fas fa-times"></i> Annuler
                    </a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
