<?php
/**
 * Formulaire création/modification unité d'enseignement - Chef DER
 */
$pageTitle = $unite ? "Modifier l'unité d'enseignement" : "Nouvelle unité d'enseignement";
require_once __DIR__ . '/../templates/header.php';
$classes = getClassesList();
?>

<div class="card" style="max-width: 500px;">
    <div class="card-header">
        <h2 class="card-title"><?= $pageTitle ?></h2>
    </div>
    <div class="card-body">
        <form action="<?= $unite ? url('chef_der/update_unite.php?id=' . $unite['idUnite_enseignement']) : url('chef_der/create_unite.php') ?>" 
              method="POST" data-validate>
            <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
            
            <div class="form-group">
                <label for="nom" class="form-label">Nom de l'UE *</label>
                <input type="text" id="nom" name="nom" class="form-control" 
                       value="<?= escape($unite['Nom'] ?? '') ?>" required
                       placeholder="Ex: UE Informatique Fondamentale">
            </div>
            
            <div class="form-group">
                <label for="semestre" class="form-label">Semestre *</label>
                <select id="semestre" name="semestre_id" class="form-control" required>
                    <option value="">Sélectionner un semestre</option>
                    <?php foreach ($semestres as $sem): ?>
                        <option value="<?= $sem['idSemestre'] ?>" 
                                <?= ($unite['Semestre_idSemestre'] ?? '') == $sem['idSemestre'] ? 'selected' : '' ?>>
                            <?= escape($sem['Classe'] ?? '') ?> - 
                            <?= date('d/m/Y', strtotime($sem['date_debut'])) ?> - <?= !empty($sem['date_fin']) ? date('d/m/Y', strtotime($sem['date_fin'])) : 'En cours' ?>
                            (<?= escape($sem['Etat'] ?? '') ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div style="display: flex; gap: 10px; margin-top: 20px;">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <?= $unite ? 'Modifier' : 'Créer' ?>
                </button>
                <a href="<?= url('chef_der/unites.php') ?>" class="btn btn-outline">
                    <i class="fas fa-times"></i> Annuler
                </a>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
