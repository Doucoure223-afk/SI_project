<?php
/**
 * Rapport par enseignant - Chef DER
 */
$pageTitle = "Rapport Enseignant: " . escape($enseignant['Prenom'] . ' ' . $enseignant['Nom']);
require_once __DIR__ . '/../templates/header.php';
$semParamFirst = $semestreInfo ? '?semestre=' . $semestreInfo['idSemestre'] : '';
?>

<div class="card">
    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
        <h2 class="card-title"><?= $pageTitle ?></h2>
        <a href="<?= url('chef_der/rapport_enseignants.php') . $semParamFirst ?>" class="btn btn-outline">
            <i class="fas fa-arrow-left"></i> Retour
        </a>
    </div>
    <div class="card-body">
        <?php if ($semestreInfo): ?>
            <div style="margin-bottom: 20px; padding: 10px; background: var(--gray-light); border-radius: 5px;">
                <i class="fas fa-calendar-alt"></i> 
                <strong>Semestre :</strong> 
                <?= date('d/m/Y', strtotime($semestreInfo['date_debut'])) ?>
                <?= !empty($semestreInfo['date_fin']) ? ' — ' . date('d/m/Y', strtotime($semestreInfo['date_fin'])) : ' — En cours' ?>
            </div>
        <?php endif; ?>

        <!-- Informations enseignant -->
        <div class="stats-grid" style="margin-bottom: 30px;">
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, var(--primary), var(--primary-dark));">
                    <i class="fas fa-user-tie"></i>
                </div>
                <div class="stat-info">
                    <span class="stat-value"><?= escape($enseignant['Grade'] ?? 'N/A') ?></span>
                    <span class="stat-label">Grade</span>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, var(--success), #27ae60);">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="stat-info">
                    <span class="stat-value"><?= $stats['heures_validees'] ?? 0 ?>h</span>
                    <span class="stat-label">Heures Validées</span>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, var(--warning), #f39c12);">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="stat-info">
                    <span class="stat-value"><?= $stats['heures_attente'] ?? 0 ?>h</span>
                    <span class="stat-label">En Attente</span>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, var(--info), #2980b9);">
                    <i class="fas fa-book"></i>
                </div>
                <div class="stat-info">
                    <span class="stat-value"><?= $stats['nb_modules'] ?? 0 ?></span>
                    <span class="stat-label">Modules</span>
                </div>
            </div>
        </div>
        
        <!-- Répartition par type -->
        <h3 style="margin-bottom: 15px;">Répartition par type de séance</h3>
        <div class="stats-grid" style="margin-bottom: 30px;">
            <div class="stat-card">
                <div class="stat-info" style="text-align: center;">
                    <span class="stat-value" style="color: var(--primary);"><?= $stats['heures_cm'] ?? 0 ?>h</span>
                    <span class="stat-label">Cours Magistraux (CM)</span>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-info" style="text-align: center;">
                    <span class="stat-value" style="color: var(--success);"><?= $stats['heures_td'] ?? 0 ?>h</span>
                    <span class="stat-label">Travaux Dirigés (TD)</span>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-info" style="text-align: center;">
                    <span class="stat-value" style="color: var(--warning);"><?= $stats['heures_tp'] ?? 0 ?>h</span>
                    <span class="stat-label">Travaux Pratiques (TP)</span>
                </div>
            </div>
        </div>
        
        <!-- Historique des séances -->
        <h3 style="margin-bottom: 15px;">Historique des séances</h3>
        <?php $seancesArray = is_array($seances) ? $seances : []; ?>
        <?php if (empty($seancesArray)): ?>
            <p style="color: var(--gray);">Aucune séance enregistrée pour cet enseignant.</p>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Module</th>
                        <th>Type</th>
                        <th>Heures</th>
                        <th>État</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($seancesArray as $seance): ?>
                        <tr>
                            <td><?= date('d/m/Y', strtotime($seance['date_Seance'])) ?></td>
                            <td><?= escape($seance['module_nom'] ?? 'N/A') ?></td>
                            <td>
                                <span class="badge badge-<?= strtolower($seance['Type_Seance']) ?>">
                                    <?= $seance['Type_Seance'] ?>
                                </span>
                            </td>
                            <td><?= $seance['heures_Effectuees'] ?>h</td>
                            <td>
                                <?php if ($seance['Etat'] === 'Validée'): ?>
                                    <span class="badge badge-success">Validée</span>
                                <?php else: ?>
                                    <span class="badge badge-warning">En attente</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
