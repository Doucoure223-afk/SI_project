<?php
/**
 * Dashboard Chef de DER avec filtre par classe
 */
$pageTitle = "Tableau de bord";
if (!empty($classeFilter)) {
    $pageTitle .= " — Classe " . $classeFilter;
}
require_once __DIR__ . '/../templates/header.php';
?>

<!-- Sélecteur de classe -->
<div class="card" style="margin-bottom: 20px;">
    <div class="card-body" style="display: flex; align-items: center; gap: 15px; flex-wrap: wrap;">
        <label for="classe-select" style="font-weight: bold; white-space: nowrap;">
            <i class="fas fa-graduation-cap"></i> Classe :
        </label>
        <select id="classe-select" class="form-control" style="max-width: 250px;"
                onchange="window.location.href='<?= url('chef_der/dashboard.php') ?>?classe=' + this.value">
            <option value="">-- Toutes les classes --</option>
            <?php foreach ($allClasses as $clKey => $clLabel): ?>
                <option value="<?= $clKey ?>" <?= $classeFilter === $clKey ? 'selected' : '' ?>><?= $clKey ?> — <?= $clLabel ?></option>
            <?php endforeach; ?>
        </select>
        <?php if ($classeFilter): ?>
            <span class="badge badge-primary"><?= escape($classeFilter) ?></span>
            <a href="<?= url('chef_der/dashboard.php') ?>" class="btn btn-outline btn-sm">
                <i class="fas fa-times"></i> Réinitialiser
            </a>
        <?php endif; ?>
    </div>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon success">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="stat-content">
            <h3><?= $totalHeuresEffectuees ?? 0 ?>h</h3>
            <p>Heures effectuées (validées)</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon primary">
            <i class="fas fa-calendar-alt"></i>
        </div>
        <div class="stat-content">
            <h3><?= $totalHeuresPrevues ?? 0 ?>h</h3>
            <p>Heures prévues totales</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon warning">
            <i class="fas fa-hourglass-half"></i>
        </div>
        <div class="stat-content">
            <h3><?= $stats['heures_en_attente'] ?? 0 ?>h</h3>
            <p>Heures en attente</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon info">
            <i class="fas fa-percentage"></i>
        </div>
        <div class="stat-content">
            <h3><?= $pourcentageGlobal ?>%</h3>
            <p>Avancement global</p>
        </div>
    </div>
</div>

<!-- Barre de progression globale -->
<div class="card">
    <div class="card-header">
        <h2 class="card-title">Avancement global <?= $classeFilter ? 'de la classe ' . escape($classeFilter) : 'du département' ?></h2>
    </div>
    <div class="card-body">
        <div style="margin-bottom: 10px; display: flex; justify-content: space-between;">
            <span>Progression</span>
            <span><strong><?= $pourcentageGlobal ?>%</strong></span>
        </div>
        <div class="progress <?= getProgressBarClass($pourcentageGlobal) ?>">
            <div class="progress-bar" style="width: <?= $pourcentageGlobal ?>%;"></div>
        </div>
        <div style="margin-top: 15px; display: flex; gap: 30px; color: var(--text-muted); font-size: 0.875rem;">
            <div><i class="fas fa-circle" style="color: var(--success-color);"></i> CM: <?= $stats['cm_valides'] ?? 0 ?>h</div>
            <div><i class="fas fa-circle" style="color: var(--info-color);"></i> TD: <?= $stats['td_valides'] ?? 0 ?>h</div>
            <div><i class="fas fa-circle" style="color: var(--warning-color);"></i> TP: <?= $stats['tp_valides'] ?? 0 ?>h</div>
        </div>
    </div>
</div>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
    <!-- Modules -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Avancement par module</h2>
            <a href="<?= url('chef_der/rapport_modules.php') . ($classeFilter ? '?classe=' . $classeFilter : '') ?>" class="btn btn-outline btn-sm">Détails</a>
        </div>
        <div class="card-body">
            <?php if (empty($statsModules)): ?>
                <p style="color: var(--text-muted); text-align: center;">Aucun module enregistré.</p>
            <?php else: ?>
                <?php foreach (array_slice($statsModules, 0, 5) as $module): 
                    $totalPrevu = $module['Volume_Horaires_CM'] + $module['Volume_Horaires_TD'] + $module['Volume_Horaires_TP'];
                    $totalEffectue = $module['cm_effectues'] + $module['td_effectues'] + $module['tp_effectues'];
                    $pct = $totalPrevu > 0 ? round(($totalEffectue / $totalPrevu) * 100, 1) : 0;
                ?>
                <div style="margin-bottom: 15px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                        <span><?= escape($module['module_nom']) ?></span>
                        <span><?= $totalEffectue ?>h / <?= $totalPrevu ?>h</span>
                    </div>
                    <div class="progress <?= getProgressBarClass($pct) ?>">
                        <div class="progress-bar" style="width: <?= $pct ?>%;"></div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Enseignants -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Heures par enseignant</h2>
            <a href="<?= url('chef_der/rapport_enseignants.php') . ($classeFilter ? '?classe=' . $classeFilter : '') ?>" class="btn btn-outline btn-sm">Détails</a>
        </div>
        <div class="card-body">
            <?php if (empty($statsEnseignants)): ?>
                <p style="color: var(--text-muted); text-align: center;">Aucun enseignant enregistré.</p>
            <?php else: ?>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Enseignant</th>
                                <th>Validées</th>
                                <th>En attente</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach (array_slice($statsEnseignants, 0, 5) as $ens): ?>
                            <tr>
                                <td><?= escape($ens['enseignant_nom']) ?></td>
                                <td><span class="badge badge-success"><?= $ens['heures_validees'] ?>h</span></td>
                                <td><span class="badge badge-warning"><?= $ens['heures_en_attente'] ?>h</span></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Actions rapides -->
<div class="card">
    <div class="card-header">
        <h2 class="card-title">Actions rapides</h2>
    </div>
    <div class="card-body">
        <div style="display: flex; gap: 15px; flex-wrap: wrap;">
            <a href="<?= url('chef_der/semestres.php') ?>" class="btn btn-secondary">
                <i class="fas fa-calendar-alt"></i> Gérer les semestres
            </a>
            <a href="<?= url('chef_der/modules.php') ?>" class="btn btn-primary">
                <i class="fas fa-book"></i> Gérer les modules
            </a>
            <a href="<?= url('chef_der/ues.php') ?>" class="btn btn-secondary">
                <i class="fas fa-layer-group"></i> Gérer les UE
            </a>
            <a href="<?= url('chef_der/rapport_global.php') . ($classeFilter ? '?classe=' . $classeFilter : '') ?>" class="btn btn-info">
                <i class="fas fa-chart-bar"></i> Rapport complet
            </a>
            <a href="<?= url('enseignant/seances.php') ?>" class="btn btn-warning">
                <i class="fas fa-calendar-check"></i> Mes séances (enseignant)
            </a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>