<?php
/**
 * Gestion des modules - Chef de DER (organisé par classe)
 */
$pageTitle = "Gestion des modules";
require_once __DIR__ . '/../templates/header.php';
$classes = getClassesList();

// Grouper les modules par classe
$modulesByClasse = [];
foreach ($modules as $module) {
    $classe = $module['classe'] ?? 'Non défini';
    $modulesByClasse[$classe][] = $module;
}
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Liste des modules</h2>
        <button class="btn btn-primary" data-modal="modal-add-module">
            <i class="fas fa-plus"></i> Nouveau module
        </button>
    </div>
    <div class="card-body">
        <?php if (empty($modules)): ?>
            <p style="text-align: center; color: var(--text-muted);">Aucun module enregistré.</p>
        <?php else: ?>
            <?php foreach ($modulesByClasse as $classe => $classModules): ?>
                <div class="classe-section">
                    <i class="fas fa-graduation-cap"></i> <?= escape($classe) ?>
                    <?php if (isset($classes[$classe])): ?>
                        - <?= escape($classes[$classe]) ?>
                    <?php endif; ?>
                </div>
                <div class="table-container" style="margin-bottom: 20px;">
                    <table>
                        <thead>
                            <tr>
                                <th>Module</th>
                                <th>Unité d'enseignement</th>
                                <th>CM</th>
                                <th>TD</th>
                                <th>TP</th>
                                <th>Total</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($classModules as $module): ?>
                            <tr>
                                <td><strong><?= escape($module['Nom']) ?></strong></td>
                                <td><?= escape($module['ue_nom'] ?? 'Non assigné') ?></td>
                                <td><?= $module['Volume_Horaires_CM'] ?>h</td>
                                <td><?= $module['Volume_Horaires_TD'] ?>h</td>
                                <td><?= $module['Volume_Horaires_TP'] ?>h</td>
                                <td>
                                    <strong>
                                        <?= $module['Volume_Horaires_CM'] + $module['Volume_Horaires_TD'] + $module['Volume_Horaires_TP'] ?>h
                                    </strong>
                                </td>
                                <td class="actions">
                                    <button class="btn btn-outline btn-sm" data-modal="modal-edit-<?= $module['idModules'] ?>">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <a href="<?= url('chef_der/delete_module.php?id=' . $module['idModules']) ?>" 
                                       class="btn btn-danger btn-sm"
                                       data-confirm="Supprimer ce module ?">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            
                            <!-- Modal d'édition -->
                            <div id="modal-edit-<?= $module['idModules'] ?>" class="modal-backdrop">
                                <div class="modal">
                                    <div class="modal-header">
                                        <h3 class="modal-title">Modifier le module</h3>
                                        <button class="modal-close">&times;</button>
                                    </div>
                                    <form action="<?= url('chef_der/update_module.php?id=' . $module['idModules']) ?>" method="POST">
                                        <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label class="form-label">Nom du module *</label>
                                                <input type="text" name="nom" class="form-control" 
                                                       value="<?= escape($module['Nom']) ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label class="form-label">Unité d'enseignement</label>
                                                <select name="unite_id" class="form-control">
                                                    <option value="">Aucune</option>
                                                    <?php foreach ($ues as $ue): ?>
                                                        <option value="<?= $ue['idUnite_enseignement'] ?>"
                                                            <?= $module['Unite_enseignement_idUnite_enseignement'] == $ue['idUnite_enseignement'] ? 'selected' : '' ?>>
                                                            <?= escape($ue['Nom']) ?> (<?= escape($ue['classe'] ?? '') ?>)
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            <div class="form-row">
                                                <div class="form-group">
                                                    <label class="form-label">Volume CM (h)</label>
                                                    <input type="number" name="volume_cm" class="form-control" 
                                                           value="<?= $module['Volume_Horaires_CM'] ?>" min="0">
                                                </div>
                                                <div class="form-group">
                                                    <label class="form-label">Volume TD (h)</label>
                                                    <input type="number" name="volume_td" class="form-control" 
                                                           value="<?= $module['Volume_Horaires_TD'] ?>" min="0">
                                                </div>
                                                <div class="form-group">
                                                    <label class="form-label">Volume TP (h)</label>
                                                    <input type="number" name="volume_tp" class="form-control" 
                                                           value="<?= $module['Volume_Horaires_TP'] ?>" min="0">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-outline" data-modal-close>Annuler</button>
                                            <button type="submit" class="btn btn-primary">Enregistrer</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Modal d'ajout -->
<div id="modal-add-module" class="modal-backdrop">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title">Nouveau module</h3>
            <button class="modal-close">&times;</button>
        </div>
        <form action="<?= url('chef_der/create_module.php') ?>" method="POST">
            <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Nom du module *</label>
                    <input type="text" name="nom" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Unité d'enseignement</label>
                    <select name="unite_id" class="form-control">
                        <option value="">Aucune</option>
                        <?php foreach ($ues as $ue): ?>
                            <option value="<?= $ue['idUnite_enseignement'] ?>">
                                <?= escape($ue['Nom']) ?> (<?= escape($ue['classe'] ?? '') ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Volume CM (h)</label>
                        <input type="number" name="volume_cm" class="form-control" value="0" min="0">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Volume TD (h)</label>
                        <input type="number" name="volume_td" class="form-control" value="0" min="0">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Volume TP (h)</label>
                        <input type="number" name="volume_tp" class="form-control" value="0" min="0">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" data-modal-close>Annuler</button>
                <button type="submit" class="btn btn-primary">Créer</button>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
