<?php
/**
 * Liste des modules avec statistiques - Chef DER (filtré par classe)
 */
$pageTitle = "Rapport par module";
if (!empty($classeFilter)) {
    $pageTitle .= " — Classe " . $classeFilter;
}
require_once __DIR__ . '/../templates/header.php';
?>

<div class="card" style="margin-bottom: 20px;">
    <div class="card-body" style="display: flex; align-items: center; gap: 15px; flex-wrap: wrap;">
        <label for="classe-select" style="font-weight: bold; white-space: nowrap;">
            <i class="fas fa-graduation-cap"></i> Classe :
        </label>
        <select id="classe-select" class="form-control" style="max-width: 250px;"
                onchange="window.location.href='<?= url('chef_der/rapport_modules.php') ?>?classe=' + this.value">
            <option value="">-- Toutes les classes --</option>
            <?php foreach ($allClasses as $clKey => $clLabel): ?>
                <option value="<?= $clKey ?>" <?= $classeFilter === $clKey ? 'selected' : '' ?>><?= $clKey ?> — <?= $clLabel ?></option>
            <?php endforeach; ?>
        </select>
        <?php if ($classeFilter): ?>
            <span class="badge badge-primary"><?= escape($classeFilter) ?></span>
            <a href="<?= url('chef_der/rapport_modules.php') ?>" class="btn btn-outline btn-sm">
                <i class="fas fa-times"></i> Réinitialiser
            </a>
        <?php endif; ?>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title"><i class="fas fa-chart-pie"></i> Avancement par module</h2>
        <?php $classeParam = !empty($classeFilter) ? '?classe=' . $classeFilter : ''; ?>
        <a href="<?= url('chef_der/rapport_global.php') . $classeParam ?>" class="btn btn-outline btn-sm">
            <i class="fas fa-arrow-left"></i> Rapport global
        </a>
    </div>
    <div class="card-body">
        <?php if (empty($statsModules)): ?>
            <p style="color: var(--text-muted); text-align: center;">Aucun module enregistré<?= $classeFilter ? ' pour la classe ' . escape($classeFilter) : '' ?>.</p>
        <?php else: ?>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Module</th>
                            <th>CM (effectué / prévu)</th>
                            <th>TD (effectué / prévu)</th>
                            <th>TP (effectué / prévu)</th>
                            <th>Avancement</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($statsModules as $m): 
                            $totalPrevu = $m['Volume_Horaires_CM'] + $m['Volume_Horaires_TD'] + $m['Volume_Horaires_TP'];
                            $totalEffectue = $m['cm_effectues'] + $m['td_effectues'] + $m['tp_effectues'];
                            $pct = $totalPrevu > 0 ? round(($totalEffectue / $totalPrevu) * 100, 1) : 0;
                        ?>
                        <tr>
                            <td><strong><?= escape($m['module_nom']) ?></strong></td>
                            <td><?= $m['cm_effectues'] ?>h / <?= $m['Volume_Horaires_CM'] ?>h</td>
                            <td><?= $m['td_effectues'] ?>h / <?= $m['Volume_Horaires_TD'] ?>h</td>
                            <td><?= $m['tp_effectues'] ?>h / <?= $m['Volume_Horaires_TP'] ?>h</td>
                            <td>
                                <div class="progress <?= getProgressBarClass($pct) ?>" style="width: 100px; display: inline-block;">
                                    <div class="progress-bar" style="width: <?= $pct ?>%;"></div>
                                </div>
                                <span><?= $pct ?>%</span>
                            </td>
                            <td>
                                <a href="<?= url('chef_der/rapport_modules.php?id=' . $m['idModules']) . ($classeFilter ? '&classe=' . $classeFilter : '') ?>" class="btn btn-outline btn-sm">
                                    <i class="fas fa-eye"></i> Détails
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>