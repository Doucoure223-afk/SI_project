<?php
/**
 * Liste des chapitres - Chef DER
 */
$pageTitle = "Gestion des Chapitres";
require_once __DIR__ . '/../templates/header.php';
?>

<div class="card">
    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
        <h2 class="card-title">Liste des Chapitres</h2>
        <a href="<?= url('chef_der/chapitre_form.php') ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> Nouveau chapitre
        </a>
    </div>
    <div class="card-body">
        <?php if (empty($chapitres)): ?>
            <p class="text-center" style="color: var(--gray);">Aucun chapitre enregistré.</p>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nom</th>
                        <th>Module</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($chapitres as $chap): ?>
                        <tr>
                            <td><?= $chap['idChapitres'] ?></td>
                            <td><?= escape($chap['Nom']) ?></td>
                            <td><?= escape($chap['module_nom'] ?? 'Non défini') ?></td>
                            <td>
                                <a href="<?= url('chef_der/chapitre_form.php?id=' . $chap['idChapitres']) ?>" 
                                   class="btn btn-sm btn-outline" title="Modifier">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="<?= url('chef_der/delete_chapitre.php?id=' . $chap['idChapitres']) ?>" 
                                   class="btn btn-sm btn-danger" 
                                   onclick="return confirm('Supprimer ce chapitre ?')" title="Supprimer">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
