<?php
/**
 * Formulaire création/modification module - Chef DER
 */
$pageTitle = $module ? "Modifier le module" : "Nouveau module";
require_once __DIR__ . '/../templates/header.php';
?>

<div class="card" style="max-width: 600px;">
    <div class="card-header">
        <h2 class="card-title"><?= $pageTitle ?></h2>
    </div>
    <div class="card-body">
        <form action="<?= $module ? url('chef_der/update_module.php?id=' . $module['idModules']) : url('chef_der/create_module.php') ?>" 
              method="POST" data-validate>
            <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
            
            <div class="form-group">
                <label for="nom" class="form-label">Nom du module *</label>
                <input type="text" id="nom" name="nom" class="form-control" 
                       value="<?= escape($module['Nom'] ?? '') ?>" required
                       placeholder="Ex: Programmation Web">
            </div>
            
            <div class="form-group">
                <label for="unite" class="form-label">Unité d'enseignement *</label>
                <select id="unite" name="unite_id" class="form-control" required>
                    <option value="">Sélectionner une UE</option>
                    <?php foreach ($unites as $ue): ?>
                        <option value="<?= $ue['idUnite_enseignement'] ?>" 
                                <?= ($module['Unite_enseignement_idUnite_enseignement'] ?? '') == $ue['idUnite_enseignement'] ? 'selected' : '' ?>>
                            <?= escape($ue['Nom']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="cm" class="form-label">Volume CM (heures) *</label>
                    <input type="number" id="cm" name="volume_cm" class="form-control" 
                           value="<?= escape($module['Volume_Horaires_CM'] ?? 0) ?>" 
                           min="0" required>
                </div>
                
                <div class="form-group">
                    <label for="td" class="form-label">Volume TD (heures) *</label>
                    <input type="number" id="td" name="volume_td" class="form-control" 
                           value="<?= escape($module['Volume_Horaires_TD'] ?? 0) ?>" 
                           min="0" required>
                </div>
                
                <div class="form-group">
                    <label for="tp" class="form-label">Volume TP (heures) *</label>
                    <input type="number" id="tp" name="volume_tp" class="form-control" 
                           value="<?= escape($module['Volume_Horaires_TP'] ?? 0) ?>" 
                           min="0" required>
                </div>
            </div>
            
            <div style="display: flex; gap: 10px; margin-top: 20px;">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <?= $module ? 'Modifier' : 'Créer' ?>
                </button>
                <a href="<?= url('chef_der/modules.php') ?>" class="btn btn-outline">
                    <i class="fas fa-times"></i> Annuler
                </a>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
