<?php
/**
 * Formulaire de saisie de séance - Responsable de classe
 */
$pageTitle = "Saisir une séance";
require_once __DIR__ . '/../templates/header.php';
?>

<div class="card" style="max-width: 700px;">
    <div class="card-header">
        <h2 class="card-title"><i class="fas fa-calendar-plus"></i> Nouvelle séance</h2>
        <?php if (!empty($resp['Classe'])): ?>
            <span class="badge badge-primary"><?= escape($resp['Classe']) ?></span>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <form action="<?= url('responsable/create_seance.php') ?>" method="POST" data-validate>
            <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
            
            <div class="form-row">
                <div class="form-group">
                    <label for="date_seance" class="form-label">Date de la séance *</label>
                    <input type="date" id="date_seance" name="date_seance" class="form-control" 
                           value="<?= date('Y-m-d') ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="heures" class="form-label">Nombre d'heures *</label>
                    <input type="number" id="heures" name="heures" class="form-control" 
                           min="1" max="8" value="3" required>
                    <small style="color: var(--text-muted);">Entre 1 et 8 heures</small>
                </div>
            </div>
            
            <div class="form-group">
                <label for="type_seance" class="form-label">Type de séance *</label>
                <select id="type_seance" name="type_seance" class="form-control" required>
                    <option value="">Sélectionner un type</option>
                    <option value="CM">CM - Cours Magistral</option>
                    <option value="TD">TD - Travaux Dirigés</option>
                    <option value="TP">TP - Travaux Pratiques</option>
                    <option value="Devoir">Devoir</option>
                    <option value="Examen">Examen</option>
                </select>
            </div>

            <div class="form-group">
                <label for="module_id" class="form-label">Module *</label>
                <select id="module_id" name="module_id" class="form-control" required>
                    <option value="">Sélectionner un module</option>
                    <?php foreach ($modules as $module): ?>
                        <option value="<?= $module['idModules'] ?>">
                            <?= escape($module['Nom']) ?> 
                            (<?= escape($module['ue_nom'] ?? 'Sans UE') ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="contenu_seance" class="form-label">Parties traitées lors de la séance</label>
                <textarea id="contenu_seance" name="contenu_seance" class="form-control" rows="3"
                          placeholder="Décrivez les différentes parties faites lors de cette séance..."></textarea>
            </div>
            
            <div class="form-group">
                <label for="enseignant_id" class="form-label">Enseignant *</label>
                <select id="enseignant_id" name="enseignant_id" class="form-control" required>
                    <option value="">Sélectionner l'enseignant</option>
                    <?php foreach ($enseignants as $ens): ?>
                        <option value="<?= $ens['idEnseignants'] ?>">
                            <?= escape($ens['Prenom'] . ' ' . $ens['Nom']) ?> 
                            <?= escape($ens['Grade'] ?? 'Enseignant') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i>
                La séance sera enregistrée avec l'état <strong>"En attente"</strong>. 
                L'enseignant concerné devra la valider pour qu'elle soit comptabilisée.
            </div>
            
            <div style="display: flex; gap: 10px; margin-top: 20px;">
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="fas fa-save"></i> Enregistrer la séance
                </button>
                <a href="<?= url('responsable/dashboard.php') ?>" class="btn btn-outline">
                    <i class="fas fa-times"></i> Annuler
                </a>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
