<?php
/**
 * Liste des séances saisies par le responsable de classe
 */
$pageTitle = $pageTitle ?? "Mes séances saisies";
require_once __DIR__ . '/../templates/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Mes séances saisies</h2>
        <a href="<?= url('responsable/saisie_seance.php') ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> Nouvelle séance
        </a>
    </div>
    <div class="card-body">
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Module</th>
                        <th>Contenu</th>
                        <th>Enseignant</th>
                        <th>Type</th>
                        <th>Heures</th>
                        <th>État</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($seances)): ?>
                        <tr>
                            <td colspan="8" style="text-align: center;">Aucune séance enregistrée.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($seances as $seance): ?>
                        <tr>
                            <td><?= formatDateFr($seance['date_Seance']) ?></td>
                            <td><?= escape($seance['module_nom'] ?? 'N/A') ?></td>
                            <td>
                                <?php if (!empty($seance['Contenu_Seance'])): ?>
                                    <small title="<?= escape($seance['Contenu_Seance']) ?>">
                                        <?= escape(mb_substr($seance['Contenu_Seance'], 0, 40)) ?><?= mb_strlen($seance['Contenu_Seance']) > 40 ? '...' : '' ?>
                                    </small>
                                <?php else: ?>
                                    <span style="color: var(--text-muted);">-</span>
                                <?php endif; ?>
                            </td>
                            <td><?= escape($seance['enseignant_nom'] ?? 'N/A') ?></td>
                            <td><?= getTypeSeanceLabel($seance['Type_Seance']) ?></td>
                            <td><strong><?= $seance['heures_Effectuees'] ?>h</strong></td>
                            <td>
                                <?= getEtatLabel($seance['Etat']) ?>
                                <?php if ($seance['Etat'] === 'Revision_demandee' && !empty($seance['Motif_Revision'])): ?>
                                    <br><small style="color: var(--danger-color);" title="<?= escape($seance['Motif_Revision']) ?>">
                                        <i class="fas fa-comment-dots"></i> 
                                        <?= escape(mb_substr($seance['Motif_Revision'], 0, 40)) ?><?= mb_strlen($seance['Motif_Revision']) > 40 ? '...' : '' ?>
                                    </small>
                                <?php endif; ?>
                            </td>
                            <td class="actions">
                                <?php if (in_array($seance['Etat'], ['En_attente', 'Revision_demandee'])): ?>
                                    <a href="<?= url('responsable/edit_seance.php?id=' . $seance['idSeances']) ?>" 
                                       class="btn btn-warning btn-sm" title="Modifier">
                                        <i class="fas fa-edit"></i> Modifier
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
