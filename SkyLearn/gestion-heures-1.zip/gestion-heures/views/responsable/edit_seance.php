<?php
/**
 * Formulaire de modification de séance - Responsable de classe
 */
$pageTitle = "Modifier une séance";
require_once __DIR__ . '/../templates/header.php';
?>

<div class="card" style="max-width: 700px;">
    <div class="card-header">
        <h2 class="card-title"><i class="fas fa-edit"></i> Modifier la séance #<?= $seance['idSeances'] ?></h2>
    </div>
    <div class="card-body">
        <?php if ($seance['Etat'] === 'Revision_demandee' && !empty($seance['Motif_Revision'])): ?>
        <div class="alert alert-danger" style="margin-bottom: 20px;">
            <i class="fas fa-exclamation-triangle"></i>
            <strong>Motif de la demande de révision :</strong><br>
            <?= escape($seance['Motif_Revision']) ?>
        </div>
        <?php endif; ?>

        <form action="<?= url('responsable/update_seance.php') ?>" method="POST" data-validate>
            <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
            <input type="hidden" name="id_seance" value="<?= $seance['idSeances'] ?>">
            
            <div class="form-row">
                <div class="form-group">
                    <label for="date_seance" class="form-label">Date de la séance *</label>
                    <input type="date" id="date_seance" name="date_seance" class="form-control" 
                           value="<?= escape($seance['date_Seance']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="heures" class="form-label">Nombre d'heures *</label>
                    <input type="number" id="heures" name="heures" class="form-control" 
                           min="1" max="8" value="<?= $seance['heures_Effectuees'] ?>" required>
                </div>
            </div>

            <div class="form-group">
                <label for="type_seance" class="form-label">Type de séance *</label>
                <select id="type_seance" name="type_seance" class="form-control" required>
                    <option value="CM" <?= ($seance['Type_Seance'] === 'CM') ? 'selected' : '' ?>>CM - Cours Magistral</option>
                    <option value="TD" <?= ($seance['Type_Seance'] === 'TD') ? 'selected' : '' ?>>TD - Travaux Dirigés</option>
                    <option value="TP" <?= ($seance['Type_Seance'] === 'TP') ? 'selected' : '' ?>>TP - Travaux Pratiques</option>
                    <option value="Devoir" <?= ($seance['Type_Seance'] === 'Devoir') ? 'selected' : '' ?>>Devoir</option>
                    <option value="Examen" <?= ($seance['Type_Seance'] === 'Examen') ? 'selected' : '' ?>>Examen</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="module_id" class="form-label">Module *</label>
                <select id="module_id" name="module_id" class="form-control" required>
                    <option value="">Sélectionner un module</option>
                    <?php foreach ($modules as $module): ?>
                        <option value="<?= $module['idModules'] ?>" <?= ($module['idModules'] == $seance['Modules_idModules']) ? 'selected' : '' ?>>
                            <?= escape($module['Nom']) ?> 
                            (<?= escape($module['ue_nom'] ?? 'Sans UE') ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="contenu_seance" class="form-label">Parties traitées lors de la séance</label>
                <textarea id="contenu_seance" name="contenu_seance" class="form-control" rows="3"
                          placeholder="Décrivez les différentes parties faites lors de cette séance..."><?= escape($seance['Contenu_Seance'] ?? '') ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="enseignant_id" class="form-label">Enseignant *</label>
                <select id="enseignant_id" name="enseignant_id" class="form-control" required>
                    <option value="">Sélectionner l'enseignant</option>
                    <?php foreach ($enseignants as $ens): ?>
                        <option value="<?= $ens['idEnseignants'] ?>" <?= ($ens['idEnseignants'] == $seance['Enseignants_idEnseignants']) ? 'selected' : '' ?>>
                            <?= escape($ens['Prenom'] . ' ' . $ens['Nom']) ?> 
                            <?= escape($ens['Grade'] ?? 'Enseignant') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i>
                Après modification, la séance repassera à l'état <strong>"En attente"</strong> 
                et l'enseignant devra la re-valider.
            </div>
            
            <div style="display: flex; gap: 10px; margin-top: 20px;">
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="fas fa-save"></i> Enregistrer les modifications
                </button>
                <a href="<?= url('responsable/mes_seances.php') ?>" class="btn btn-outline">
                    <i class="fas fa-arrow-left"></i> Retour
                </a>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
