<?php
/**
 * Dashboard Responsable de classe (filtré par classe)
 */
$pageTitle = "Tableau de bord" . (!empty($resp['Classe']) ? ' - ' . $resp['Classe'] : '');
require_once __DIR__ . '/../templates/header.php';
?>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon primary">
            <i class="fas fa-calendar-plus"></i>
        </div>
        <div class="stat-content">
            <h3><?= $stats['total'] ?? 0 ?></h3>
            <p>Séances saisies</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon warning">
            <i class="fas fa-clock"></i>
        </div>
        <div class="stat-content">
            <h3><?= $stats['en_attente'] ?? 0 ?></h3>
            <p>En attente</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon success">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="stat-content">
            <h3><?= $stats['validees'] ?? 0 ?></h3>
            <p>Validées</p>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon info">
            <i class="fas fa-graduation-cap"></i>
        </div>
        <div class="stat-content">
            <h3><?= escape($resp['Classe'] ?? 'N/A') ?></h3>
            <p>Ma classe</p>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Actions rapides</h2>
    </div>
    <div class="card-body">
        <div style="display: flex; gap: 15px; flex-wrap: wrap;">
            <a href="<?= url('responsable/saisie_seance.php') ?>" class="btn btn-primary btn-lg">
                <i class="fas fa-plus-circle"></i> Saisir une nouvelle séance
            </a>
            <a href="<?= url('responsable/mes_seances.php') ?>" class="btn btn-secondary">
                <i class="fas fa-history"></i> Voir l'historique
            </a>
        </div>
    </div>
</div>

<?php if (!empty($seances)): ?>
<div class="card">
    <div class="card-header">
        <h2 class="card-title">Dernières séances saisies</h2>
    </div>
    <div class="card-body">
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Module</th>
                        <th>Contenu</th>
                        <th>Type</th>
                        <th>Heures</th>
                        <th>Enseignant</th>
                        <th>État</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach (array_slice($seances, 0, 5) as $seance): ?>
                    <tr>
                        <td><?= formatDateFr($seance['date_Seance']) ?></td>
                        <td><?= escape($seance['module_nom']) ?></td>
                        <td>
                            <?php if (!empty($seance['Contenu_Seance'])): ?>
                                <small title="<?= escape($seance['Contenu_Seance']) ?>">
                                    <?= escape(mb_substr($seance['Contenu_Seance'], 0, 30)) ?><?= mb_strlen($seance['Contenu_Seance']) > 30 ? '...' : '' ?>
                                </small>
                            <?php else: ?>
                                <span style="color: var(--text-muted);">-</span>
                            <?php endif; ?>
                        </td>
                        <td><span class="badge badge-info"><?= $seance['Type_Seance'] ?></span></td>
                        <td><?= $seance['heures_Effectuees'] ?>h</td>
                        <td><?= escape($seance['enseignant_nom']) ?></td>
                        <td><?= getEtatLabel($seance['Etat']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
