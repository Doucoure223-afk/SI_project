<?php
/**
 * Liste des séances de l'enseignant
 */
$pageTitle = $pageTitle ?? "Mes séances";
require_once __DIR__ . '/../templates/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Mes séances</h2>
    </div>
    <div class="card-body">
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Module</th>
                        <th>Contenu</th>
                        <th>Type</th>
                        <th>Heures</th>
                        <th>Classe</th>
                        <th>État</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($seances)): ?>
                        <tr>
                            <td colspan="8" style="text-align: center;">Aucune séance enregistrée.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($seances as $seance): ?>
                        <tr>
                            <td><?= formatDateFr($seance['date_Seance']) ?></td>
                            <td><?= escape($seance['module_nom'] ?? 'N/A') ?></td>
                            <td>
                                <?php if (!empty($seance['Contenu_Seance'])): ?>
                                    <small title="<?= escape($seance['Contenu_Seance']) ?>">
                                        <?= escape(mb_substr($seance['Contenu_Seance'], 0, 40)) ?><?= mb_strlen($seance['Contenu_Seance']) > 40 ? '...' : '' ?>
                                    </small>
                                <?php else: ?>
                                    <span style="color: var(--text-muted);">-</span>
                                <?php endif; ?>
                            </td>
                            <td><?= getTypeSeanceLabel($seance['Type_Seance']) ?></td>
                            <td><strong><?= $seance['heures_Effectuees'] ?>h</strong></td>
                            <td><?= escape($seance['Classe'] ?? '-') ?></td>
                            <td><?= getEtatLabel($seance['Etat']) ?></td>
                            <td class="actions">
                                <?php if ($seance['Etat'] === 'En_attente'): ?>
                                    <a href="<?= url('enseignant/valider_seance.php?id=' . $seance['idSeances']) ?>" 
                                       class="btn btn-success btn-sm" 
                                       data-confirm="Valider cette séance ?">
                                        <i class="fas fa-check"></i> Valider
                                    </a>
                                    <a href="<?= url('enseignant/contester_seance.php?id=' . $seance['idSeances']) ?>" 
                                       class="btn btn-info btn-sm">
                                        <i class="fas fa-redo"></i> Demander révision
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
