<?php
/**
 * Dashboard Enseignant
 */
$pageTitle = "Tableau de bord";
require_once __DIR__ . '/../templates/header.php';
?>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon warning">
            <i class="fas fa-hourglass-half"></i>
        </div>
        <div class="stat-content">
            <h3><?= count($seancesEnAttente ?? []) ?></h3>
            <p>Séances à valider</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon success">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="stat-content">
            <h3><?= $totalHeuresValidees ?? 0 ?>h</h3>
            <p>Heures validées</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon primary">
            <i class="fas fa-calendar"></i>
        </div>
        <div class="stat-content">
            <h3><?= count($seances ?? []) ?></h3>
            <p>Total séances</p>
        </div>
    </div>
</div>

<?php if (!empty($seancesEnAttente)): ?>
<div class="card">
    <div class="card-header">
        <h2 class="card-title">
            <i class="fas fa-exclamation-triangle" style="color: var(--warning-color);"></i>
            Séances en attente de validation
        </h2>
    </div>
    <div class="card-body">
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Module</th>
                        <th>Contenu</th>
                        <th>Type</th>
                        <th>Heures</th>
                        <th>Saisi par</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($seancesEnAttente as $seance): ?>
                    <tr>
                        <td><?= formatDateFr($seance['date_Seance']) ?></td>
                        <td><?= escape($seance['module_nom']) ?></td>
                        <td>
                            <?php if (!empty($seance['Contenu_Seance'])): ?>
                                <small title="<?= escape($seance['Contenu_Seance']) ?>">
                                    <?= escape(mb_substr($seance['Contenu_Seance'], 0, 40)) ?><?= mb_strlen($seance['Contenu_Seance']) > 40 ? '...' : '' ?>
                                </small>
                            <?php else: ?>
                                <span style="color: var(--text-muted);">-</span>
                            <?php endif; ?>
                        </td>
                        <td><span class="badge badge-info"><?= $seance['Type_Seance'] ?></span></td>
                        <td><?= $seance['heures_Effectuees'] ?>h</td>
                        <td>
                            <?= escape($seance['responsable_nom']) ?><br>
                            <small style="color: var(--text-muted);"><?= escape($seance['Classe']) ?></small>
                        </td>
                        <td class="actions">
                            <a href="<?= url('enseignant/valider_seance.php?id=' . $seance['idSeances']) ?>" 
                               class="btn btn-success btn-sm" title="Valider">
                                <i class="fas fa-check"></i> Valider
                            </a>
                            <button type="button" class="btn btn-info btn-sm" 
                                    data-modal="modal-revision-<?= $seance['idSeances'] ?>" title="Demander révision">
                                <i class="fas fa-redo"></i> Révision
                            </button>
                        </td>
                    </tr>
                    
                    <!-- Modal de demande de révision -->
                    <div id="modal-revision-<?= $seance['idSeances'] ?>" class="modal-backdrop">
                        <div class="modal">
                            <div class="modal-header">
                                <h3 class="modal-title">Demander une révision</h3>
                                <button class="modal-close">&times;</button>
                            </div>
                            <form action="<?= url('enseignant/contester_seance.php?id=' . $seance['idSeances']) ?>" method="POST">
                                <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                                <div class="modal-body">
                                    <p><strong>Séance du <?= formatDateFr($seance['date_Seance']) ?></strong></p>
                                    <p><?= escape($seance['module_nom']) ?> - <?= $seance['Type_Seance'] ?> (<?= $seance['heures_Effectuees'] ?>h)</p>
                                    
                                    <div class="form-group" style="margin-top: 15px;">
                                        <label for="motif" class="form-label">Motif de la demande de révision *</label>
                                        <textarea id="motif" name="motif" class="form-control" rows="4" 
                                                  placeholder="Expliquez pourquoi vous demandez une révision de cette séance..." required></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-outline" data-modal-close>Annuler</button>
                                    <button type="submit" class="btn btn-info">Demander la révision</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php else: ?>
<div class="card">
    <div class="card-body">
        <div class="empty-state">
            <i class="fas fa-check-circle"></i>
            <h3>Aucune séance en attente</h3>
            <p>Toutes vos séances ont été traitées.</p>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Mes séances récentes</h2>
        <a href="<?= url('enseignant/seances.php') ?>" class="btn btn-outline btn-sm">Voir tout</a>
    </div>
    <div class="card-body">
        <?php if (empty($seances)): ?>
            <div class="empty-state">
                <i class="fas fa-calendar-times"></i>
                <h3>Aucune séance</h3>
                <p>Vous n'avez pas encore de séances enregistrées.</p>
            </div>
        <?php else: ?>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Module</th>
                            <th>Contenu</th>
                            <th>Type</th>
                            <th>Heures</th>
                            <th>État</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach (array_slice($seances, 0, 5) as $seance): ?>
                        <tr>
                            <td><?= formatDateFr($seance['date_Seance']) ?></td>
                            <td><?= escape($seance['module_nom']) ?></td>
                            <td>
                                <?php if (!empty($seance['Contenu_Seance'])): ?>
                                    <small title="<?= escape($seance['Contenu_Seance']) ?>">
                                        <?= escape(mb_substr($seance['Contenu_Seance'], 0, 30)) ?><?= mb_strlen($seance['Contenu_Seance']) > 30 ? '...' : '' ?>
                                    </small>
                                <?php else: ?>
                                    <span style="color: var(--text-muted);">-</span>
                                <?php endif; ?>
                            </td>
                            <td><span class="badge badge-info"><?= $seance['Type_Seance'] ?></span></td>
                            <td><?= $seance['heures_Effectuees'] ?>h</td>
                            <td><?= getEtatLabel($seance['Etat']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
