<?php
/**
 * Template Header - Inclus dans toutes les pages
 */
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';

$currentRole = getCurrentUserRole();
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= escape($pageTitle ?? 'Gestion des Heures') ?> - GH Enseignement</title>
    <link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <h1><i class="fas fa-graduation-cap"></i> GIT</h1>
                <span>Gestion des Heures</span>
            </div>
            
            <nav class="sidebar-nav">
                <?php if ($currentRole === 'ADMIN'): ?>
                    <div class="nav-section">Administration</div>
                    <a href="<?= url('admin/dashboard.php') ?>" class="nav-link <?= $currentPage === 'dashboard.php' ? 'active' : '' ?>">
                        <i class="fas fa-tachometer-alt"></i> Tableau de bord
                    </a>
                    <a href="<?= url('admin/users.php') ?>" class="nav-link <?= $currentPage === 'users.php' ? 'active' : '' ?>">
                        <i class="fas fa-users"></i> Utilisateurs
                    </a>
                    
                <?php elseif ($currentRole === 'CHEF_DER'): ?>
                    <div class="nav-section">Chef de DER</div>
                    <a href="<?= url('chef_der/dashboard.php') ?>" class="nav-link <?= $currentPage === 'dashboard.php' ? 'active' : '' ?>">
                        <i class="fas fa-tachometer-alt"></i> Tableau de bord
                    </a>
                    <a href="<?= url('chef_der/semestres.php') ?>" class="nav-link <?= $currentPage === 'semestres.php' ? 'active' : '' ?>">
                        <i class="fas fa-calendar-alt"></i> Semestres
                    </a>
                   <a href="<?= url('chef_der/ues.php') ?>" class="nav-link <?= $currentPage === 'ues.php' ? 'active' : '' ?>">
                        <i class="fas fa-layer-group"></i> Unités d'enseignement
                    </a>
                    <a href="<?= url('chef_der/modules.php') ?>" class="nav-link <?= $currentPage === 'modules.php' ? 'active' : '' ?>">
                        <i class="fas fa-book"></i> Modules
                    </a>
                    
                    <div class="nav-section">Rapports</div>
                    <a href="<?= url('chef_der/rapport_global.php') ?>" class="nav-link <?= $currentPage === 'rapport_global.php' ? 'active' : '' ?>">
                        <i class="fas fa-chart-bar"></i> Rapport global
                    </a>
                    <a href="<?= url('chef_der/rapport_modules.php') ?>" class="nav-link <?= $currentPage === 'rapport_modules.php' ? 'active' : '' ?>">
                        <i class="fas fa-chart-pie"></i> Par module
                    </a>
                    <a href="<?= url('chef_der/rapport_enseignants.php') ?>" class="nav-link <?= $currentPage === 'rapport_enseignants.php' ? 'active' : '' ?>">
                        <i class="fas fa-user-tie"></i> Par enseignant
                    </a>
                    <div class="nav-section">Enseignant</div>
                    <a href="<?= url('enseignant/seances.php') ?>" class="nav-link <?= $currentPage === 'seances.php' ? 'active' : '' ?>">
                        <i class="fas fa-calendar-check"></i> Mes séances
                    </a>
                    
                <?php elseif ($currentRole === 'ENSEIGNANT'): ?>
                    <div class="nav-section">Enseignant</div>
                    <a href="<?= url('enseignant/dashboard.php') ?>" class="nav-link <?= $currentPage === 'dashboard.php' ? 'active' : '' ?>">
                        <i class="fas fa-tachometer-alt"></i> Tableau de bord
                    </a>
                    <a href="<?= url('enseignant/seances.php') ?>" class="nav-link <?= $currentPage === 'seances.php' ? 'active' : '' ?>">
                        <i class="fas fa-calendar-check"></i> Mes séances
                    </a>
                    
                <?php elseif ($currentRole === 'RESPONSABLE'): ?>
                    <div class="nav-section">Responsable de classe</div>
                    <a href="<?= url('responsable/dashboard.php') ?>" class="nav-link <?= $currentPage === 'dashboard.php' ? 'active' : '' ?>">
                        <i class="fas fa-tachometer-alt"></i> Tableau de bord
                    </a>
                    <a href="<?= url('responsable/saisie_seance.php') ?>" class="nav-link <?= $currentPage === 'saisie_seance.php' ? 'active' : '' ?>">
                        <i class="fas fa-plus-circle"></i> Saisir une séance
                    </a>
                    <a href="<?= url('responsable/mes_seances.php') ?>" class="nav-link <?= $currentPage === 'mes_seances.php' ? 'active' : '' ?>">
                        <i class="fas fa-history"></i> Historique
                    </a>
                <?php endif; ?>
            </nav>
            
            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar">
                        <?= strtoupper(substr($_SESSION['user_prenom'] ?? 'U', 0, 1)) ?>
                    </div>
                    <div>
                        <div class="user-name"><?= escape(getCurrentUserName()) ?></div>
                        <div class="user-role"><?= getRoleLabel($currentRole) ?></div>
                    </div>
                </div>
                <a href="<?= url('logout.php') ?>" class="btn btn-outline btn-sm" style="margin-top: 10px; width: 100%;">
                    <i class="fas fa-sign-out-alt"></i> Déconnexion
                </a>
            </div>
        </aside>
        
        <!-- Contenu principal -->
        <main class="main-content">
            <header class="main-header">
                <button class="mobile-menu-btn btn btn-outline" onclick="toggleMobileSidebar()">
                    <i class="fas fa-bars"></i>
                </button>
                <h1 class="page-title"><?= escape($pageTitle ?? 'Tableau de bord') ?></h1>
                <div class="header-actions">
                    <span class="badge badge-info"><?= date('d/m/Y') ?></span>
                </div>
            </header>
            
            <div class="content-area">
                <?php 
                // Afficher les messages flash
                $flash = getFlashMessage();
                if ($flash): 
                ?>
                    <div class="alert alert-<?= $flash['type'] ?>">
                        <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : ($flash['type'] === 'error' ? 'exclamation-circle' : 'info-circle') ?>"></i>
                        <?= escape($flash['message']) ?>
                    </div>
                <?php endif; ?>
