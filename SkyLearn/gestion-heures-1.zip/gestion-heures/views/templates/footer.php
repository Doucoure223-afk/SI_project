            </div><!-- .content-area -->
        </main><!-- .main-content -->
    </div><!-- .app-container -->
    
    <script src="<?= url('assets/js/main.js') ?>"></script>
</body>
</html>
