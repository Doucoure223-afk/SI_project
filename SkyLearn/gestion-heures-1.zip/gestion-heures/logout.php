<?php
/**
 * Déconnexion
 */
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/functions.php';

destroyUserSession();
setFlashMessage('success', 'Vous avez été déconnecté avec succès.');
redirect(url('login.php'));
?>
