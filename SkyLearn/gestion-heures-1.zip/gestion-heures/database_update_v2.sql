-- =============================================================
-- MISE À JOUR v2 - Ajout du chapitre dans les séances
-- À exécuter dans phpMyAdmin sur la base `gestion des heures`
-- =============================================================

USE `gestion des heures`;

-- Ajouter la colonne chapitre à la table Seances
ALTER TABLE Seances 
ADD COLUMN Chapitres_idChapitres INT NULL AFTER Modules_idModules,
ADD FOREIGN KEY (Chapitres_idChapitres) 
    REFERENCES Chapitres(idChapitres) 
    ON DELETE SET NULL;
