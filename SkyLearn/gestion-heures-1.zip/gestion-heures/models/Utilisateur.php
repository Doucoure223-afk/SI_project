<?php
/**
 * ============================================================
 * Modèle Utilisateur
 * Couche Métier - Architecture 3-tiers
 * ============================================================
 */

require_once __DIR__ . '/../config/database.php';

class Utilisateur {
    private $conn;
    private $table = "Utilisateurs";

    // Propriétés
    public $idUtilisateurs;
    public $Nom;
    public $Prenom;
    public $Login;
    public $Mot_De_Passe;
    public $Role;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    /**
     * Authentifier un utilisateur
     * @param string $login Login
     * @param string $password Mot de passe en clair
     * @return array|false Données utilisateur ou false
     */
    public function authenticate($login, $password) {
        $query = "SELECT * FROM " . $this->table . " WHERE Login = :login LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':login', $login);
        $stmt->execute();
        
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && password_verify($password, $user['Mot_De_Passe'])) {
            return $user;
        }
        
        return false;
    }

    /**
     * Créer un nouvel utilisateur
     * @return bool
     */
    public function create() {
        $query = "INSERT INTO " . $this->table . " 
                  (Nom, Prenom, Login, Mot_De_Passe, Role) 
                  VALUES (:nom, :prenom, :login, :password, :role)";
        
        $stmt = $this->conn->prepare($query);
        
        // Hasher le mot de passe
        $hashedPassword = password_hash($this->Mot_De_Passe, PASSWORD_DEFAULT);
        
        $stmt->bindParam(':nom', $this->Nom);
        $stmt->bindParam(':prenom', $this->Prenom);
        $stmt->bindParam(':login', $this->Login);
        $stmt->bindParam(':password', $hashedPassword);
        $stmt->bindParam(':role', $this->Role);
        
        if ($stmt->execute()) {
            $this->idUtilisateurs = $this->conn->lastInsertId();
            return true;
        }
        
        return false;
    }

    /**
     * Lire tous les utilisateurs
     * @return PDOStatement
     */
    public function readAll() {
        $query = "SELECT * FROM " . $this->table . " ORDER BY Nom, Prenom";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Lire un utilisateur par ID
     * @param int $id ID utilisateur
     * @return array|false
     */
    public function readOne($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE idUtilisateurs = :id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Mettre à jour un utilisateur
     * @return bool
     */
    public function update() {
        // Requête de base sans mot de passe
        $query = "UPDATE " . $this->table . " 
                  SET Nom = :nom, Prenom = :prenom, Login = :login, Role = :role";
        
        // Ajouter le mot de passe si fourni
        if (!empty($this->Mot_De_Passe)) {
            $query .= ", Mot_De_Passe = :password";
        }
        
        $query .= " WHERE idUtilisateurs = :id";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':nom', $this->Nom);
        $stmt->bindParam(':prenom', $this->Prenom);
        $stmt->bindParam(':login', $this->Login);
        $stmt->bindParam(':role', $this->Role);
        $stmt->bindParam(':id', $this->idUtilisateurs);
        
        if (!empty($this->Mot_De_Passe)) {
            $hashedPassword = password_hash($this->Mot_De_Passe, PASSWORD_DEFAULT);
            $stmt->bindParam(':password', $hashedPassword);
        }
        
        return $stmt->execute();
    }

    /**
     * Supprimer un utilisateur
     * @param int $id ID utilisateur
     * @return bool
     */
    public function delete($id) {
        $query = "DELETE FROM " . $this->table . " WHERE idUtilisateurs = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    /**
     * Vérifier si un login existe déjà
     * @param string $login Login à vérifier
     * @param int|null $excludeId ID à exclure (pour mise à jour)
     * @return bool
     */
    public function loginExists($login, $excludeId = null) {
        $query = "SELECT COUNT(*) FROM " . $this->table . " WHERE Login = :login";
        
        if ($excludeId) {
            $query .= " AND idUtilisateurs != :id";
        }
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':login', $login);
        
        if ($excludeId) {
            $stmt->bindParam(':id', $excludeId);
        }
        
        $stmt->execute();
        return $stmt->fetchColumn() > 0;
    }

    /**
     * Obtenir les utilisateurs par rôle
     * @param string $role Rôle
     * @return PDOStatement
     */
    public function getByRole($role) {
        $query = "SELECT * FROM " . $this->table . " WHERE Role = :role ORDER BY Nom, Prenom";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':role', $role);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Obtenir tous les enseignants avec leurs informations
     * @return PDOStatement
     */
    public function getAllEnseignants() {
        $query = "SELECT u.*, e.idEnseignants, e.Grade 
                  FROM " . $this->table . " u
                  INNER JOIN Enseignants e ON u.idUtilisateurs = e.Utilisateurs_idUtilisateurs
                  WHERE u.Role IN ('ENSEIGNANT', 'CHEF_DER')
                  ORDER BY u.Nom, u.Prenom";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }
}
?>
