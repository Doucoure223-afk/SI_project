<?php
/**
 * ============================================================
 * Modèle Module
 * Couche Métier - Architecture 3-tiers
 * ============================================================
 */

require_once __DIR__ . '/../config/database.php';

class Module {
    private $conn;
    private $table = "Modules";

    // Propriétés
    public $idModules;
    public $Nom;
    public $Volume_Horaires_CM;
    public $Volume_Horaires_TD;
    public $Volume_Horaires_TP;
    public $Unite_enseignement_idUnite_enseignement;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    /**
     * Créer un nouveau module
     */
    public function create() {
        $query = "INSERT INTO " . $this->table . " 
                  (Nom, Volume_Horaires_CM, Volume_Horaires_TD, Volume_Horaires_TP, Unite_enseignement_idUnite_enseignement) 
                  VALUES (:nom, :cm, :td, :tp, :ue)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':nom', $this->Nom);
        $stmt->bindParam(':cm', $this->Volume_Horaires_CM);
        $stmt->bindParam(':td', $this->Volume_Horaires_TD);
        $stmt->bindParam(':tp', $this->Volume_Horaires_TP);
        $stmt->bindParam(':ue', $this->Unite_enseignement_idUnite_enseignement);
        
        if ($stmt->execute()) {
            $this->idModules = $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    /**
     * Lire tous les modules avec leurs UE et classe
     */
    public function readAll() {
        $query = "SELECT m.*, ue.Nom AS ue_nom, sem.idSemestre, sem.date_debut, sem.date_fin, sem.Classe as classe
                  FROM " . $this->table . " m
                  LEFT JOIN Unite_enseignement ue ON m.Unite_enseignement_idUnite_enseignement = ue.idUnite_enseignement
                  LEFT JOIN Semestre sem ON ue.Semestre_idSemestre = sem.idSemestre
                  ORDER BY sem.Classe, ue.Nom, m.Nom";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Lire un module par ID
     */
    public function readOne($id) {
        $query = "SELECT m.*, ue.Nom AS ue_nom, sem.Classe as classe
                  FROM " . $this->table . " m
                  LEFT JOIN Unite_enseignement ue ON m.Unite_enseignement_idUnite_enseignement = ue.idUnite_enseignement
                  LEFT JOIN Semestre sem ON ue.Semestre_idSemestre = sem.idSemestre
                  WHERE m.idModules = :id LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Mettre à jour un module
     */
    public function update() {
        $query = "UPDATE " . $this->table . " 
                  SET Nom = :nom, 
                      Volume_Horaires_CM = :cm, 
                      Volume_Horaires_TD = :td, 
                      Volume_Horaires_TP = :tp,
                      Unite_enseignement_idUnite_enseignement = :ue
                  WHERE idModules = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':nom', $this->Nom);
        $stmt->bindParam(':cm', $this->Volume_Horaires_CM);
        $stmt->bindParam(':td', $this->Volume_Horaires_TD);
        $stmt->bindParam(':tp', $this->Volume_Horaires_TP);
        $stmt->bindParam(':ue', $this->Unite_enseignement_idUnite_enseignement);
        $stmt->bindParam(':id', $this->idModules);
        
        return $stmt->execute();
    }

    /**
     * Supprimer un module
     */
    public function delete($id) {
        $query = "DELETE FROM " . $this->table . " WHERE idModules = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    /**
     * Obtenir les modules par UE
     */
    public function getByUE($ueId) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE Unite_enseignement_idUnite_enseignement = :ueId 
                  ORDER BY Nom";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':ueId', $ueId);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Obtenir les modules par classe (via UE -> Semestre)
     */
    public function getByClasse($classe) {
        $query = "SELECT m.*, ue.Nom AS ue_nom
                  FROM " . $this->table . " m
                  INNER JOIN Unite_enseignement ue ON m.Unite_enseignement_idUnite_enseignement = ue.idUnite_enseignement
                  INNER JOIN Semestre sem ON ue.Semestre_idSemestre = sem.idSemestre
                  WHERE sem.Classe = :classe
                  ORDER BY ue.Nom, m.Nom";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':classe', $classe);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Obtenir les modules d'un semestre (via UE)
     */
    public function getBySemestre($semestreId) {
        $query = "SELECT m.*, ue.Nom AS ue_nom
                  FROM " . $this->table . " m
                  INNER JOIN Unite_enseignement ue ON m.Unite_enseignement_idUnite_enseignement = ue.idUnite_enseignement
                  WHERE ue.Semestre_idSemestre = :semestreId
                  ORDER BY ue.Nom, m.Nom";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':semestreId', $semestreId);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Obtenir le volume horaire restant pour un module
     */
    public function getVolumeRestant($moduleId) {
        $query = "SELECT 
                    m.Volume_Horaires_CM,
                    m.Volume_Horaires_TD,
                    m.Volume_Horaires_TP,
                    COALESCE(SUM(CASE WHEN s.Type_Seance = 'CM' AND s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END), 0) as cm_effectues,
                    COALESCE(SUM(CASE WHEN s.Type_Seance = 'TD' AND s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END), 0) as td_effectues,
                    COALESCE(SUM(CASE WHEN s.Type_Seance = 'TP' AND s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END), 0) as tp_effectues
                  FROM " . $this->table . " m
                  LEFT JOIN Seances s ON m.idModules = s.Modules_idModules
                  WHERE m.idModules = :moduleId
                  GROUP BY m.idModules";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':moduleId', $moduleId);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result) {
            return [
                'cm_restant' => $result['Volume_Horaires_CM'] - $result['cm_effectues'],
                'td_restant' => $result['Volume_Horaires_TD'] - $result['td_effectues'],
                'tp_restant' => $result['Volume_Horaires_TP'] - $result['tp_effectues'],
                'cm_total' => $result['Volume_Horaires_CM'],
                'td_total' => $result['Volume_Horaires_TD'],
                'tp_total' => $result['Volume_Horaires_TP'],
                'cm_effectues' => $result['cm_effectues'],
                'td_effectues' => $result['td_effectues'],
                'tp_effectues' => $result['tp_effectues']
            ];
        }
        
        return null;
    }

    /**
     * Lire tous les modules avec détails complets
     */
    public function readAllWithDetails() {
        $query = "SELECT m.*, 
                         ue.Nom AS ue_nom, 
                         sem.idSemestre, 
                         sem.date_debut, 
                         sem.date_fin,
                         sem.Classe as classe,
                         (SELECT COUNT(*) FROM Seances s WHERE s.Modules_idModules = m.idModules) as nb_seances
                  FROM " . $this->table . " m
                  LEFT JOIN Unite_enseignement ue ON m.Unite_enseignement_idUnite_enseignement = ue.idUnite_enseignement
                  LEFT JOIN Semestre sem ON ue.Semestre_idSemestre = sem.idSemestre
                  ORDER BY sem.Classe, ue.Nom, m.Nom";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }
}
?>
