<?php
/**
 * ============================================================
 * Modèle Responsable de Classe
 * Couche Métier - Architecture 3-tiers
 * ============================================================
 */

require_once __DIR__ . '/../config/database.php';

class ResponsableClasse {
    private $conn;
    private $table = "Responsable_Classe";

    // Propriétés
    public $idResponsable_Classe;
    public $Classe;
    public $Utilisateurs_idUtilisateurs;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    /**
     * Créer un nouveau responsable
     * @return bool
     */
    public function create() {
        $query = "INSERT INTO " . $this->table . " (Classe, Utilisateurs_idUtilisateurs) VALUES (:classe, :userId)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':classe', $this->Classe);
        $stmt->bindParam(':userId', $this->Utilisateurs_idUtilisateurs);
        
        if ($stmt->execute()) {
            $this->idResponsable_Classe = $this->conn->lastInsertId();
            return true;
        }
        
        return false;
    }

    /**
     * Lire tous les responsables avec leurs infos utilisateur
     * @return PDOStatement
     */
    public function readAll() {
        $query = "SELECT rc.*, u.Nom, u.Prenom, u.Login
                  FROM " . $this->table . " rc
                  INNER JOIN Utilisateurs u ON rc.Utilisateurs_idUtilisateurs = u.idUtilisateurs
                  ORDER BY rc.Classe, u.Nom";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Lire un responsable par ID utilisateur
     * @param int $userId
     * @return array|false
     */
    public function getByUserId($userId) {
        $query = "SELECT rc.*, u.Nom, u.Prenom, u.Login
                  FROM " . $this->table . " rc
                  INNER JOIN Utilisateurs u ON rc.Utilisateurs_idUtilisateurs = u.idUtilisateurs
                  WHERE u.idUtilisateurs = :userId LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':userId', $userId);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Lire un responsable par ID
     * @param int $id
     * @return array|false
     */
    public function readOne($id) {
        $query = "SELECT rc.*, u.Nom, u.Prenom, u.Login
                  FROM " . $this->table . " rc
                  INNER JOIN Utilisateurs u ON rc.Utilisateurs_idUtilisateurs = u.idUtilisateurs
                  WHERE rc.idResponsable_Classe = :id LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Mettre à jour un responsable
     * @return bool
     */
    public function update() {
        $query = "UPDATE " . $this->table . " SET Classe = :classe WHERE idResponsable_Classe = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':classe', $this->Classe);
        $stmt->bindParam(':id', $this->idResponsable_Classe);
        
        return $stmt->execute();
    }

    /**
     * Supprimer un responsable
     * @param int $id
     * @return bool
     */
    public function delete($id) {
        $query = "DELETE FROM " . $this->table . " WHERE idResponsable_Classe = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }
}
?>
