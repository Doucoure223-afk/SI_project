<?php
/**
 * ============================================================
 * Modèle Séance
 * Couche Métier - Architecture 3-tiers
 * ============================================================
 */

require_once __DIR__ . '/../config/database.php';

class Seance {
    private $conn;
    private $table = "Seances";

    // Propriétés
    public $idSeances;
    public $date_Seance;
    public $heures_Effectuees;
    public $Type_Seance;
    public $Etat;
    public $Motif_Revision;
    public $Contenu_Seance;
    public $Responsable_Classe_idResponsable_Classe;
    public $Modules_idModules;
    public $Enseignants_idEnseignants;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    /**
     * Créer une nouvelle séance
     */
    public function create() {
        $query = "INSERT INTO " . $this->table . " 
                  (date_Seance, heures_Effectuees, Type_Seance, Etat, Contenu_Seance,
                   Responsable_Classe_idResponsable_Classe, Modules_idModules, Enseignants_idEnseignants) 
                  VALUES (:date, :heures, :type, 'En_attente', :contenu, :responsable, :module, :enseignant)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':date', $this->date_Seance);
        $stmt->bindParam(':heures', $this->heures_Effectuees);
        $stmt->bindParam(':type', $this->Type_Seance);
        $stmt->bindParam(':contenu', $this->Contenu_Seance);
        $stmt->bindParam(':responsable', $this->Responsable_Classe_idResponsable_Classe);
        $stmt->bindParam(':module', $this->Modules_idModules);
        $stmt->bindParam(':enseignant', $this->Enseignants_idEnseignants);
        
        if ($stmt->execute()) {
            $this->idSeances = $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    /**
     * Modifier une séance (uniquement si En_attente ou Revision_demandee)
     */
    public function update() {
        $query = "UPDATE " . $this->table . " 
                  SET date_Seance = :date, heures_Effectuees = :heures, Type_Seance = :type,
                      Modules_idModules = :module, Contenu_Seance = :contenu,
                      Enseignants_idEnseignants = :enseignant, Etat = 'En_attente', Motif_Revision = NULL
                  WHERE idSeances = :id AND Etat IN ('En_attente', 'Revision_demandee')";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':date', $this->date_Seance);
        $stmt->bindParam(':heures', $this->heures_Effectuees);
        $stmt->bindParam(':type', $this->Type_Seance);
        $stmt->bindParam(':module', $this->Modules_idModules);
        $stmt->bindParam(':contenu', $this->Contenu_Seance);
        $stmt->bindParam(':enseignant', $this->Enseignants_idEnseignants);
        $stmt->bindParam(':id', $this->idSeances);
        
        return $stmt->execute() && $stmt->rowCount() > 0;
    }

    /**
     * Lire toutes les séances avec détails
     */
    public function readAll() {
        $query = "SELECT s.*, 
                         m.Nom AS module_nom,
                         ue.Nom AS ue_nom,
                         CONCAT(u.Prenom, ' ', u.Nom) AS enseignant_nom,
                         CONCAT(ur.Prenom, ' ', ur.Nom) AS responsable_nom,
                         rc.Classe,
                         sem.Classe as classe_semestre
                  FROM " . $this->table . " s
                  LEFT JOIN Modules m ON s.Modules_idModules = m.idModules
                  LEFT JOIN Unite_enseignement ue ON m.Unite_enseignement_idUnite_enseignement = ue.idUnite_enseignement
                  LEFT JOIN Semestre sem ON ue.Semestre_idSemestre = sem.idSemestre
                  LEFT JOIN Enseignants e ON s.Enseignants_idEnseignants = e.idEnseignants
                  LEFT JOIN Utilisateurs u ON e.Utilisateurs_idUtilisateurs = u.idUtilisateurs
                  LEFT JOIN Responsable_Classe rc ON s.Responsable_Classe_idResponsable_Classe = rc.idResponsable_Classe
                  LEFT JOIN Utilisateurs ur ON rc.Utilisateurs_idUtilisateurs = ur.idUtilisateurs
                  ORDER BY s.date_Seance DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Lire toutes les séances d'un semestre
     */
    public function readAllBySemestre($semestreId) {
        $query = "SELECT s.*, 
                         m.Nom AS module_nom,
                         ue.Nom AS ue_nom,
                         CONCAT(u.Prenom, ' ', u.Nom) AS enseignant_nom,
                         CONCAT(ur.Prenom, ' ', ur.Nom) AS responsable_nom,
                         rc.Classe
                  FROM " . $this->table . " s
                  LEFT JOIN Modules m ON s.Modules_idModules = m.idModules
                  LEFT JOIN Unite_enseignement ue ON m.Unite_enseignement_idUnite_enseignement = ue.idUnite_enseignement
                  LEFT JOIN Enseignants e ON s.Enseignants_idEnseignants = e.idEnseignants
                  LEFT JOIN Utilisateurs u ON e.Utilisateurs_idUtilisateurs = u.idUtilisateurs
                  LEFT JOIN Responsable_Classe rc ON s.Responsable_Classe_idResponsable_Classe = rc.idResponsable_Classe
                  LEFT JOIN Utilisateurs ur ON rc.Utilisateurs_idUtilisateurs = ur.idUtilisateurs
                  WHERE ue.Semestre_idSemestre = :semestreId
                  ORDER BY s.date_Seance DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':semestreId', $semestreId);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Lire les séances d'un enseignant
     */
    public function getByEnseignant($enseignantId) {
        $query = "SELECT s.*, 
                         m.Nom AS module_nom,
                         ue.Nom AS ue_nom,
                         CONCAT(ur.Prenom, ' ', ur.Nom) AS responsable_nom,
                         rc.Classe,
                         sem.Classe as classe_semestre
                  FROM " . $this->table . " s
                  LEFT JOIN Modules m ON s.Modules_idModules = m.idModules
                  LEFT JOIN Unite_enseignement ue ON m.Unite_enseignement_idUnite_enseignement = ue.idUnite_enseignement
                  LEFT JOIN Semestre sem ON ue.Semestre_idSemestre = sem.idSemestre
                  LEFT JOIN Responsable_Classe rc ON s.Responsable_Classe_idResponsable_Classe = rc.idResponsable_Classe
                  LEFT JOIN Utilisateurs ur ON rc.Utilisateurs_idUtilisateurs = ur.idUtilisateurs
                  WHERE s.Enseignants_idEnseignants = :enseignantId
                  ORDER BY s.date_Seance DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':enseignantId', $enseignantId);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Lire les séances d'un responsable de classe
     */
    public function getByResponsable($responsableId) {
        $query = "SELECT s.*, 
                         m.Nom AS module_nom,
                         ue.Nom AS ue_nom,
                         CONCAT(u.Prenom, ' ', u.Nom) AS enseignant_nom
                  FROM " . $this->table . " s
                  LEFT JOIN Modules m ON s.Modules_idModules = m.idModules
                  LEFT JOIN Unite_enseignement ue ON m.Unite_enseignement_idUnite_enseignement = ue.idUnite_enseignement
                  LEFT JOIN Enseignants e ON s.Enseignants_idEnseignants = e.idEnseignants
                  LEFT JOIN Utilisateurs u ON e.Utilisateurs_idUtilisateurs = u.idUtilisateurs
                  WHERE s.Responsable_Classe_idResponsable_Classe = :responsableId
                  ORDER BY s.date_Seance DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':responsableId', $responsableId);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Valider une séance
     */
    public function valider($id) {
        $query = "UPDATE " . $this->table . " 
                  SET Etat = 'Validée', Motif_Revision = NULL 
                  WHERE idSeances = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    /**
     * Demander une révision
     */
    public function demanderRevision($id, $motif) {
        $query = "UPDATE " . $this->table . " 
                  SET Etat = 'Revision_demandee', Motif_Revision = :motif 
                  WHERE idSeances = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':motif', $motif);
        return $stmt->execute();
    }

    /**
     * Obtenir les séances en attente pour un enseignant
     */
    public function getEnAttenteByEnseignant($enseignantId) {
        $query = "SELECT s.*, 
                         m.Nom AS module_nom,
                         CONCAT(ur.Prenom, ' ', ur.Nom) AS responsable_nom,
                         rc.Classe
                  FROM " . $this->table . " s
                  LEFT JOIN Modules m ON s.Modules_idModules = m.idModules
                  LEFT JOIN Responsable_Classe rc ON s.Responsable_Classe_idResponsable_Classe = rc.idResponsable_Classe
                  LEFT JOIN Utilisateurs ur ON rc.Utilisateurs_idUtilisateurs = ur.idUtilisateurs
                  WHERE s.Enseignants_idEnseignants = :enseignantId
                  AND s.Etat = 'En_attente'
                  ORDER BY s.date_Seance DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':enseignantId', $enseignantId);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Statistiques globales des séances
     */
    public function getStatistiques() {
        $query = "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN Etat = 'Validée' THEN heures_Effectuees ELSE 0 END) as heures_validees,
                    SUM(CASE WHEN Etat = 'En_attente' THEN heures_Effectuees ELSE 0 END) as heures_en_attente,
                    SUM(CASE WHEN Type_Seance = 'CM' AND Etat = 'Validée' THEN heures_Effectuees ELSE 0 END) as cm_valides,
                    SUM(CASE WHEN Type_Seance = 'TD' AND Etat = 'Validée' THEN heures_Effectuees ELSE 0 END) as td_valides,
                    SUM(CASE WHEN Type_Seance = 'TP' AND Etat = 'Validée' THEN heures_Effectuees ELSE 0 END) as tp_valides
                  FROM " . $this->table;
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Statistiques globales par classe
     */
    public function getStatistiquesByClasse($classe) {
        $query = "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END) as heures_validees,
                    SUM(CASE WHEN s.Etat = 'En_attente' THEN s.heures_Effectuees ELSE 0 END) as heures_en_attente,
                    SUM(CASE WHEN s.Type_Seance = 'CM' AND s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END) as cm_valides,
                    SUM(CASE WHEN s.Type_Seance = 'TD' AND s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END) as td_valides,
                    SUM(CASE WHEN s.Type_Seance = 'TP' AND s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END) as tp_valides
                  FROM " . $this->table . " s
                  INNER JOIN Modules m ON s.Modules_idModules = m.idModules
                  INNER JOIN Unite_enseignement ue ON m.Unite_enseignement_idUnite_enseignement = ue.idUnite_enseignement
                  INNER JOIN Semestre sem ON ue.Semestre_idSemestre = sem.idSemestre
                  WHERE sem.Classe = :classe";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':classe', $classe);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Statistiques globales des séances par semestre
     */
    public function getStatistiquesBySemestre($semestreId) {
        $query = "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END) as heures_validees,
                    SUM(CASE WHEN s.Etat = 'En_attente' THEN s.heures_Effectuees ELSE 0 END) as heures_en_attente,
                    SUM(CASE WHEN s.Type_Seance = 'CM' AND s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END) as cm_valides,
                    SUM(CASE WHEN s.Type_Seance = 'TD' AND s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END) as td_valides,
                    SUM(CASE WHEN s.Type_Seance = 'TP' AND s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END) as tp_valides
                  FROM " . $this->table . " s
                  INNER JOIN Modules m ON s.Modules_idModules = m.idModules
                  INNER JOIN Unite_enseignement ue ON m.Unite_enseignement_idUnite_enseignement = ue.idUnite_enseignement
                  WHERE ue.Semestre_idSemestre = :semestreId";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':semestreId', $semestreId);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Statistiques par module
     */
    public function getStatistiquesByModule() {
        $query = "SELECT 
                    m.idModules,
                    m.Nom as module_nom,
                    m.Volume_Horaires_CM,
                    m.Volume_Horaires_TD,
                    m.Volume_Horaires_TP,
                    COALESCE(SUM(CASE WHEN s.Type_Seance = 'CM' AND s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END), 0) as cm_effectues,
                    COALESCE(SUM(CASE WHEN s.Type_Seance = 'TD' AND s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END), 0) as td_effectues,
                    COALESCE(SUM(CASE WHEN s.Type_Seance = 'TP' AND s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END), 0) as tp_effectues
                  FROM Modules m
                  LEFT JOIN " . $this->table . " s ON m.idModules = s.Modules_idModules
                  GROUP BY m.idModules, m.Nom, m.Volume_Horaires_CM, m.Volume_Horaires_TD, m.Volume_Horaires_TP
                  ORDER BY m.Nom";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Statistiques par module filtré par classe
     */
    public function getStatistiquesByModuleByClasse($classe) {
        $query = "SELECT 
                    m.idModules,
                    m.Nom as module_nom,
                    m.Volume_Horaires_CM,
                    m.Volume_Horaires_TD,
                    m.Volume_Horaires_TP,
                    COALESCE(SUM(CASE WHEN s.Type_Seance = 'CM' AND s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END), 0) as cm_effectues,
                    COALESCE(SUM(CASE WHEN s.Type_Seance = 'TD' AND s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END), 0) as td_effectues,
                    COALESCE(SUM(CASE WHEN s.Type_Seance = 'TP' AND s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END), 0) as tp_effectues
                  FROM Modules m
                  INNER JOIN Unite_enseignement ue ON m.Unite_enseignement_idUnite_enseignement = ue.idUnite_enseignement
                  INNER JOIN Semestre sem ON ue.Semestre_idSemestre = sem.idSemestre
                  LEFT JOIN " . $this->table . " s ON m.idModules = s.Modules_idModules
                  WHERE sem.Classe = :classe
                  GROUP BY m.idModules, m.Nom, m.Volume_Horaires_CM, m.Volume_Horaires_TD, m.Volume_Horaires_TP
                  ORDER BY m.Nom";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':classe', $classe);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Statistiques par module filtré par semestre
     */
    public function getStatistiquesByModuleBySemestre($semestreId) {
        $query = "SELECT 
                    m.idModules,
                    m.Nom as module_nom,
                    m.Volume_Horaires_CM,
                    m.Volume_Horaires_TD,
                    m.Volume_Horaires_TP,
                    COALESCE(SUM(CASE WHEN s.Type_Seance = 'CM' AND s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END), 0) as cm_effectues,
                    COALESCE(SUM(CASE WHEN s.Type_Seance = 'TD' AND s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END), 0) as td_effectues,
                    COALESCE(SUM(CASE WHEN s.Type_Seance = 'TP' AND s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END), 0) as tp_effectues
                  FROM Modules m
                  INNER JOIN Unite_enseignement ue ON m.Unite_enseignement_idUnite_enseignement = ue.idUnite_enseignement
                  LEFT JOIN " . $this->table . " s ON m.idModules = s.Modules_idModules
                  WHERE ue.Semestre_idSemestre = :semestreId
                  GROUP BY m.idModules, m.Nom, m.Volume_Horaires_CM, m.Volume_Horaires_TD, m.Volume_Horaires_TP
                  ORDER BY m.Nom";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':semestreId', $semestreId);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Statistiques par enseignant
     */
    public function getStatistiquesByEnseignant() {
        $query = "SELECT 
                    e.idEnseignants,
                    CONCAT(u.Prenom, ' ', u.Nom) as enseignant_nom,
                    e.Grade,
                    COUNT(s.idSeances) as total_seances,
                    COALESCE(SUM(CASE WHEN s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END), 0) as heures_validees,
                    COALESCE(SUM(CASE WHEN s.Etat = 'En_attente' THEN s.heures_Effectuees ELSE 0 END), 0) as heures_en_attente,
                    COALESCE(SUM(s.heures_Effectuees), 0) as heures_totales
                  FROM Enseignants e
                  INNER JOIN Utilisateurs u ON e.Utilisateurs_idUtilisateurs = u.idUtilisateurs
                  LEFT JOIN " . $this->table . " s ON e.idEnseignants = s.Enseignants_idEnseignants
                  GROUP BY e.idEnseignants, u.Prenom, u.Nom, e.Grade
                  ORDER BY u.Nom, u.Prenom";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Statistiques par enseignant filtré par classe
     */
    public function getStatistiquesByEnseignantByClasse($classe) {
        $query = "SELECT 
                    e.idEnseignants,
                    CONCAT(u.Prenom, ' ', u.Nom) as enseignant_nom,
                    e.Grade,
                    COUNT(s.idSeances) as total_seances,
                    COALESCE(SUM(CASE WHEN s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END), 0) as heures_validees,
                    COALESCE(SUM(CASE WHEN s.Etat = 'En_attente' THEN s.heures_Effectuees ELSE 0 END), 0) as heures_en_attente,
                    COALESCE(SUM(s.heures_Effectuees), 0) as heures_totales
                  FROM Enseignants e
                  INNER JOIN Utilisateurs u ON e.Utilisateurs_idUtilisateurs = u.idUtilisateurs
                  INNER JOIN " . $this->table . " s ON e.idEnseignants = s.Enseignants_idEnseignants
                  INNER JOIN Modules m ON s.Modules_idModules = m.idModules
                  INNER JOIN Unite_enseignement ue ON m.Unite_enseignement_idUnite_enseignement = ue.idUnite_enseignement
                  INNER JOIN Semestre sem ON ue.Semestre_idSemestre = sem.idSemestre
                  WHERE sem.Classe = :classe
                  GROUP BY e.idEnseignants, u.Prenom, u.Nom, e.Grade
                  HAVING COUNT(s.idSeances) > 0
                  ORDER BY u.Nom, u.Prenom";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':classe', $classe);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Statistiques par enseignant filtré par semestre
     */
    public function getStatistiquesByEnseignantBySemestre($semestreId) {
        $query = "SELECT 
                    e.idEnseignants,
                    CONCAT(u.Prenom, ' ', u.Nom) as enseignant_nom,
                    e.Grade,
                    COUNT(s.idSeances) as total_seances,
                    COALESCE(SUM(CASE WHEN s.Etat = 'Validée' THEN s.heures_Effectuees ELSE 0 END), 0) as heures_validees,
                    COALESCE(SUM(CASE WHEN s.Etat = 'En_attente' THEN s.heures_Effectuees ELSE 0 END), 0) as heures_en_attente,
                    COALESCE(SUM(s.heures_Effectuees), 0) as heures_totales
                  FROM Enseignants e
                  INNER JOIN Utilisateurs u ON e.Utilisateurs_idUtilisateurs = u.idUtilisateurs
                  INNER JOIN " . $this->table . " s ON e.idEnseignants = s.Enseignants_idEnseignants
                  INNER JOIN Modules m ON s.Modules_idModules = m.idModules
                  INNER JOIN Unite_enseignement ue ON m.Unite_enseignement_idUnite_enseignement = ue.idUnite_enseignement
                  WHERE ue.Semestre_idSemestre = :semestreId
                  GROUP BY e.idEnseignants, u.Prenom, u.Nom, e.Grade
                  HAVING COUNT(s.idSeances) > 0
                  ORDER BY u.Nom, u.Prenom";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':semestreId', $semestreId);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Lire une séance par ID
     */
    public function readOne($id) {
        $query = "SELECT s.*, 
                         m.Nom AS module_nom,
                         CONCAT(u.Prenom, ' ', u.Nom) AS enseignant_nom
                  FROM " . $this->table . " s
                  LEFT JOIN Modules m ON s.Modules_idModules = m.idModules
                  LEFT JOIN Enseignants e ON s.Enseignants_idEnseignants = e.idEnseignants
                  LEFT JOIN Utilisateurs u ON e.Utilisateurs_idUtilisateurs = u.idUtilisateurs
                  WHERE s.idSeances = :id LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Lire les séances par module
     */
    public function getByModule($moduleId) {
        $query = "SELECT s.*, 
                         m.Nom AS module_nom,
                         CONCAT(u.Prenom, ' ', u.Nom) AS enseignant_nom
                  FROM " . $this->table . " s
                  LEFT JOIN Modules m ON s.Modules_idModules = m.idModules
                  LEFT JOIN Enseignants e ON s.Enseignants_idEnseignants = e.idEnseignants
                  LEFT JOIN Utilisateurs u ON e.Utilisateurs_idUtilisateurs = u.idUtilisateurs
                  WHERE s.Modules_idModules = :moduleId
                  ORDER BY s.date_Seance DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':moduleId', $moduleId);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Séances par classe
     */
    public function readAllByClasse($classe) {
        $query = "SELECT s.*, 
                         m.Nom AS module_nom,
                         ue.Nom AS ue_nom,
                         CONCAT(u.Prenom, ' ', u.Nom) AS enseignant_nom,
                         CONCAT(ur.Prenom, ' ', ur.Nom) AS responsable_nom,
                         rc.Classe,
                         sem.Classe as classe_semestre
                  FROM " . $this->table . " s
                  INNER JOIN Modules m ON s.Modules_idModules = m.idModules
                  INNER JOIN Unite_enseignement ue ON m.Unite_enseignement_idUnite_enseignement = ue.idUnite_enseignement
                  INNER JOIN Semestre sem ON ue.Semestre_idSemestre = sem.idSemestre
                  LEFT JOIN Enseignants e ON s.Enseignants_idEnseignants = e.idEnseignants
                  LEFT JOIN Utilisateurs u ON e.Utilisateurs_idUtilisateurs = u.idUtilisateurs
                  LEFT JOIN Responsable_Classe rc ON s.Responsable_Classe_idResponsable_Classe = rc.idResponsable_Classe
                  LEFT JOIN Utilisateurs ur ON rc.Utilisateurs_idUtilisateurs = ur.idUtilisateurs
                  WHERE sem.Classe = :classe
                  ORDER BY s.date_Seance DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':classe', $classe);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Alias pour dashboard
     */
    public function getStatsParModule() {
        return $this->getStatistiquesByModule()->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getStatsParEnseignant() {
        return $this->getStatistiquesByEnseignant()->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getStatsParModuleByClasse($classe) {
        return $this->getStatistiquesByModuleByClasse($classe)->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getStatsParEnseignantByClasse($classe) {
        return $this->getStatistiquesByEnseignantByClasse($classe)->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
