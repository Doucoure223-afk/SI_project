<?php
/**
 * ============================================================
 * Modèle Semestre
 * Couche Métier - Architecture 3-tiers
 * ============================================================
 */

require_once __DIR__ . '/../config/database.php';

class Semestre {
    private $conn;
    private $table = "Semestre";

    // Propriétés
    public $idSemestre;
    public $date_debut;
    public $date_fin;
    public $Classe;
    public $Etat;

    /**
     * Liste des classes disponibles
     */
    public static $CLASSES = [
        'L1S1' => 'Licence 1 - Semestre 1',
        'L1S2' => 'Licence 1 - Semestre 2',
        'L2S3' => 'Licence 2 - Semestre 3',
        'L2S4' => 'Licence 2 - Semestre 4',
        'L3S5' => 'Licence 3 - Semestre 5',
        'L3S6' => 'Licence 3 - Semestre 6',
        'M1S1' => 'Master 1 - Semestre 1',
        'M1S2' => 'Master 1 - Semestre 2',
        'M2S3' => 'Master 2 - Semestre 3'
    ];

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    /**
     * Créer un nouveau semestre
     */
    public function create() {
        $query = "INSERT INTO " . $this->table . " (date_debut, date_fin, Classe, Etat) VALUES (:debut, NULL, :classe, 'En_cours')";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':debut', $this->date_debut);
        $stmt->bindParam(':classe', $this->Classe);
        
        if ($stmt->execute()) {
            $this->idSemestre = $this->conn->lastInsertId();
            return true;
        }
        
        return false;
    }

    /**
     * Lire tous les semestres
     */
    public function readAll() {
        $query = "SELECT * FROM " . $this->table . " ORDER BY Classe, date_debut DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Lire un semestre par ID
     */
    public function readOne($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE idSemestre = :id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Mettre à jour un semestre (uniquement si En_cours)
     */
    public function update() {
        $query = "UPDATE " . $this->table . " SET date_debut = :debut, Classe = :classe WHERE idSemestre = :id AND Etat = 'En_cours'";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':debut', $this->date_debut);
        $stmt->bindParam(':classe', $this->Classe);
        $stmt->bindParam(':id', $this->idSemestre);
        
        return $stmt->execute() && $stmt->rowCount() > 0;
    }

    /**
     * Clôturer un semestre
     */
    public function cloturer($id) {
        $today = date('Y-m-d');
        $query = "UPDATE " . $this->table . " SET date_fin = :today, Etat = 'Terminé' WHERE idSemestre = :id AND Etat = 'En_cours'";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':today', $today);
        $stmt->bindParam(':id', $id);
        
        return $stmt->execute() && $stmt->rowCount() > 0;
    }

    /**
     * Supprimer un semestre
     */
    public function delete($id) {
        $query = "DELETE FROM " . $this->table . " WHERE idSemestre = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    /**
     * Obtenir le semestre actuel (En_cours) pour une classe
     */
    public function getCurrent($classe = null) {
        if ($classe) {
            $query = "SELECT * FROM " . $this->table . " WHERE Etat = 'En_cours' AND Classe = :classe ORDER BY date_debut DESC LIMIT 1";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':classe', $classe);
        } else {
            $query = "SELECT * FROM " . $this->table . " WHERE Etat = 'En_cours' ORDER BY date_debut DESC LIMIT 1";
            $stmt = $this->conn->prepare($query);
        }
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Obtenir les semestres par classe
     */
    public function getByClasse($classe) {
        $query = "SELECT * FROM " . $this->table . " WHERE Classe = :classe ORDER BY date_debut DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':classe', $classe);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Vérifier si un semestre est modifiable (En_cours)
     */
    public function isModifiable($id) {
        $sem = $this->readOne($id);
        return $sem && $sem['Etat'] === 'En_cours';
    }

    /**
     * Formater le label d'un semestre
     */
    public static function formatLabel($semestre) {
        if (!$semestre) return 'N/A';
        
        $classe = $semestre['Classe'] ?? '';
        $classeLabel = self::$CLASSES[$classe] ?? $classe;
        
        $debut = new DateTime($semestre['date_debut']);
        $label = $classeLabel . ' (' . $debut->format('M Y');
        
        if (!empty($semestre['date_fin'])) {
            $fin = new DateTime($semestre['date_fin']);
            $label .= ' - ' . $fin->format('M Y');
        } else {
            $label .= ' - En cours';
        }
        
        return $label . ')';
    }
}
?>
