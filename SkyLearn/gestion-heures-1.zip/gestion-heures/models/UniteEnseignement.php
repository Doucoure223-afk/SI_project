<?php
/**
 * ============================================================
 * Modèle Unité d'Enseignement
 * Couche Métier - Architecture 3-tiers
 * ============================================================
 */

require_once __DIR__ . '/../config/database.php';

class UniteEnseignement {
    private $conn;
    private $table = "Unite_enseignement";

    // Propriétés
    public $idUnite_enseignement;
    public $Nom;
    public $Semestre_idSemestre;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    /**
     * Créer une nouvelle UE
     */
    public function create() {
        $query = "INSERT INTO " . $this->table . " (Nom, Semestre_idSemestre) VALUES (:nom, :semestre)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':nom', $this->Nom);
        $stmt->bindParam(':semestre', $this->Semestre_idSemestre);
        
        if ($stmt->execute()) {
            $this->idUnite_enseignement = $this->conn->lastInsertId();
            return true;
        }
        
        return false;
    }

    /**
     * Lire toutes les UE avec leurs semestres et classe
     */
    public function readAll() {
        $query = "SELECT ue.*, sem.date_debut, sem.date_fin, sem.Classe as classe
                  FROM " . $this->table . " ue
                  LEFT JOIN Semestre sem ON ue.Semestre_idSemestre = sem.idSemestre
                  ORDER BY sem.Classe, sem.date_debut, ue.Nom";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Lire une UE par ID
     */
    public function readOne($id) {
        $query = "SELECT ue.*, sem.date_debut, sem.date_fin, sem.Classe as classe
                  FROM " . $this->table . " ue
                  LEFT JOIN Semestre sem ON ue.Semestre_idSemestre = sem.idSemestre
                  WHERE ue.idUnite_enseignement = :id LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Mettre à jour une UE
     */
    public function update() {
        $query = "UPDATE " . $this->table . " 
                  SET Nom = :nom, Semestre_idSemestre = :semestre 
                  WHERE idUnite_enseignement = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':nom', $this->Nom);
        $stmt->bindParam(':semestre', $this->Semestre_idSemestre);
        $stmt->bindParam(':id', $this->idUnite_enseignement);
        
        return $stmt->execute();
    }

    /**
     * Supprimer une UE
     */
    public function delete($id) {
        $query = "DELETE FROM " . $this->table . " WHERE idUnite_enseignement = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    /**
     * Obtenir les UE par semestre
     */
    public function getBySemestre($semestreId) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE Semestre_idSemestre = :semestreId 
                  ORDER BY Nom";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':semestreId', $semestreId);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Obtenir les UE par classe (via semestre)
     */
    public function getByClasse($classe) {
        $query = "SELECT ue.*, sem.date_debut, sem.date_fin, sem.Classe as classe
                  FROM " . $this->table . " ue
                  INNER JOIN Semestre sem ON ue.Semestre_idSemestre = sem.idSemestre
                  WHERE sem.Classe = :classe
                  ORDER BY ue.Nom";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':classe', $classe);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Lire toutes les UE avec détails complets
     */
    public function readAllWithDetails() {
        $query = "SELECT ue.*, 
                         sem.date_debut, 
                         sem.date_fin,
                         sem.Classe as classe,
                         (SELECT COUNT(*) FROM Modules m WHERE m.Unite_enseignement_idUnite_enseignement = ue.idUnite_enseignement) as nb_modules
                  FROM " . $this->table . " ue
                  LEFT JOIN Semestre sem ON ue.Semestre_idSemestre = sem.idSemestre
                  ORDER BY sem.Classe, sem.date_debut DESC, ue.Nom";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }
}
?>
