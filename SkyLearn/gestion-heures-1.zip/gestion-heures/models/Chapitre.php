<?php
/**
 * ============================================================
 * Modèle Chapitre
 * Couche Métier - Architecture 3-tiers
 * ============================================================
 */

require_once __DIR__ . '/../config/database.php';

class Chapitre {
    private $conn;
    private $table = "Chapitres";

    // Propriétés
    public $idChapitres;
    public $Nom;
    public $Modules_idModules;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    /**
     * Créer un nouveau chapitre
     * @return bool
     */
    public function create() {
        $query = "INSERT INTO " . $this->table . " (Nom, Modules_idModules) VALUES (:nom, :module)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':nom', $this->Nom);
        $stmt->bindParam(':module', $this->Modules_idModules);
        
        if ($stmt->execute()) {
            $this->idChapitres = $this->conn->lastInsertId();
            return true;
        }
        
        return false;
    }

    /**
     * Lire tous les chapitres avec leurs modules
     * @return PDOStatement
     */
    public function readAll() {
        $query = "SELECT c.*, m.Nom AS module_nom
                  FROM " . $this->table . " c
                  LEFT JOIN Modules m ON c.Modules_idModules = m.idModules
                  ORDER BY m.Nom, c.Nom";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Lire un chapitre par ID
     * @param int $id
     * @return array|false
     */
    public function readOne($id) {
        $query = "SELECT c.*, m.Nom AS module_nom
                  FROM " . $this->table . " c
                  LEFT JOIN Modules m ON c.Modules_idModules = m.idModules
                  WHERE c.idChapitres = :id LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Mettre à jour un chapitre
     * @return bool
     */
    public function update() {
        $query = "UPDATE " . $this->table . " SET Nom = :nom, Modules_idModules = :module WHERE idChapitres = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':nom', $this->Nom);
        $stmt->bindParam(':module', $this->Modules_idModules);
        $stmt->bindParam(':id', $this->idChapitres);
        
        return $stmt->execute();
    }

    /**
     * Supprimer un chapitre
     * @param int $id
     * @return bool
     */
    public function delete($id) {
        $query = "DELETE FROM " . $this->table . " WHERE idChapitres = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    /**
     * Obtenir les chapitres par module
     * @param int $moduleId
     * @return PDOStatement
     */
    public function getByModule($moduleId) {
        $query = "SELECT * FROM " . $this->table . " WHERE Modules_idModules = :moduleId ORDER BY Nom";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':moduleId', $moduleId);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Lire tous les chapitres avec leurs modules
     * @return PDOStatement
     */
    public function readAllWithModules() {
        $query = "SELECT c.*, m.Nom AS module_nom
                  FROM " . $this->table . " c
                  LEFT JOIN Modules m ON c.Modules_idModules = m.idModules
                  ORDER BY m.Nom, c.Nom";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }
}
?>
