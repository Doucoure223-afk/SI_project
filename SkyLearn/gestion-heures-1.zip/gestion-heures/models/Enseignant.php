<?php
/**
 * ============================================================
 * Modèle Enseignant
 * Couche Métier - Architecture 3-tiers
 * ============================================================
 */

require_once __DIR__ . '/../config/database.php';

class Enseignant {
    private $conn;
    private $table = "Enseignants";

    // Propriétés
    public $idEnseignants;
    public $Grade;
    public $Utilisateurs_idUtilisateurs;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    /**
     * Créer un nouvel enseignant
     * @return bool
     */
    public function create() {
        $query = "INSERT INTO " . $this->table . " (Grade, Utilisateurs_idUtilisateurs) VALUES (:grade, :userId)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':grade', $this->Grade);
        $stmt->bindParam(':userId', $this->Utilisateurs_idUtilisateurs);
        
        if ($stmt->execute()) {
            $this->idEnseignants = $this->conn->lastInsertId();
            return true;
        }
        
        return false;
    }

    /**
     * Lire tous les enseignants avec leurs infos utilisateur
     * @return PDOStatement
     */
    public function readAll() {
        $query = "SELECT e.*, u.Nom, u.Prenom, u.Login, u.Role
                  FROM " . $this->table . " e
                  INNER JOIN Utilisateurs u ON e.Utilisateurs_idUtilisateurs = u.idUtilisateurs
                  ORDER BY u.Nom, u.Prenom";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Lire un enseignant par ID utilisateur
     * @param int $userId
     * @return array|false
     */
    public function getByUserId($userId) {
        $query = "SELECT e.*, u.Nom, u.Prenom, u.Login, u.Role
                  FROM " . $this->table . " e
                  INNER JOIN Utilisateurs u ON e.Utilisateurs_idUtilisateurs = u.idUtilisateurs
                  WHERE u.idUtilisateurs = :userId LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':userId', $userId);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Lire un enseignant par ID enseignant
     * @param int $id
     * @return array|false
     */
    public function readOne($id) {
        $query = "SELECT e.*, u.Nom, u.Prenom, u.Login, u.Role
                  FROM " . $this->table . " e
                  INNER JOIN Utilisateurs u ON e.Utilisateurs_idUtilisateurs = u.idUtilisateurs
                  WHERE e.idEnseignants = :id LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Mettre à jour un enseignant
     * @return bool
     */
    public function update() {
        $query = "UPDATE " . $this->table . " SET Grade = :grade WHERE idEnseignants = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':grade', $this->Grade);
        $stmt->bindParam(':id', $this->idEnseignants);
        
        return $stmt->execute();
    }

    /**
     * Supprimer un enseignant
     * @param int $id
     * @return bool
     */
    public function delete($id) {
        $query = "DELETE FROM " . $this->table . " WHERE idEnseignants = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    /**
     * Lire tous les enseignants avec leurs utilisateurs
     * @return PDOStatement
     */
    public function readAllWithUsers() {
        $query = "SELECT e.*, u.Nom, u.Prenom, u.Login, u.Role, u.idUtilisateurs
                  FROM " . $this->table . " e
                  INNER JOIN Utilisateurs u ON e.Utilisateurs_idUtilisateurs = u.idUtilisateurs
                  WHERE u.Role IN ('ENSEIGNANT', 'CHEF_DER')
                  ORDER BY u.Nom, u.Prenom";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Lire un enseignant avec ses infos utilisateur par ID enseignant
     * @param int $id
     * @return array|false
     */
    public function readOneWithUser($id) {
        $query = "SELECT e.*, u.Nom, u.Prenom, u.Login, u.Role
                  FROM " . $this->table . " e
                  INNER JOIN Utilisateurs u ON e.Utilisateurs_idUtilisateurs = u.idUtilisateurs
                  WHERE e.idEnseignants = :id LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>
