<?php
/**
 * Point d'entrée - Dashboard Enseignant
 */
require_once __DIR__ . '/../controllers/SeanceController.php';

$controller = new SeanceController();
$controller->enseignantDashboard();
?>
