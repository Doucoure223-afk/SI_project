<?php
/**
 * Point d'entrée - Demande de révision de séance
 */
require_once __DIR__ . '/../controllers/SeanceController.php';

$controller = new SeanceController();
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

if (!$id) {
    header("Location: dashboard.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $motif = trim($_POST['motif'] ?? '');
    $controller->demanderRevision($id, $motif);
} else {
    // Afficher le formulaire de demande de révision
    require_once __DIR__ . '/../includes/session.php';
    require_once __DIR__ . '/../includes/functions.php';
    requireRole(['ENSEIGNANT', 'CHEF_DER']);
    
    $pageTitle = "Demander une révision";
    require_once __DIR__ . '/../views/templates/header.php';
    ?>
    <div class="card" style="max-width: 500px;">
        <div class="card-header">
            <h2 class="card-title">Demander la révision de la séance #<?= $id ?></h2>
        </div>
        <div class="card-body">
            <form action="contester_seance.php?id=<?= $id ?>" method="POST">
                <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                
                <div class="form-group">
                    <label for="motif" class="form-label">Motif de la demande de révision *</label>
                    <textarea id="motif" name="motif" class="form-control" rows="4" required
                              placeholder="Expliquez pourquoi vous demandez une révision de cette séance..."></textarea>
                </div>
                
                <div style="display: flex; gap: 10px; margin-top: 20px;">
                    <button type="submit" class="btn btn-info">
                        <i class="fas fa-redo"></i> Confirmer la demande de révision
                    </button>
                    <a href="dashboard.php" class="btn btn-outline">
                        <i class="fas fa-arrow-left"></i> Annuler
                    </a>
                </div>
            </form>
        </div>
    </div>
    <?php
    require_once __DIR__ . '/../views/templates/footer.php';
}
?>
