<?php
/**
 * Point d'entrée - Liste des séances (Enseignant)
 */
require_once __DIR__ . '/../controllers/SeanceController.php';

$controller = new SeanceController();
$controller->mesSeances();
?>
