<?php
/**
 * Point d'entrée - Validation séance
 */
require_once __DIR__ . '/../controllers/SeanceController.php';

$controller = new SeanceController();
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

if (!$id) {
    header("Location: dashboard.php");
    exit();
}

$controller->validerSeance($id);
?>
