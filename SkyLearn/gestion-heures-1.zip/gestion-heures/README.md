# Système de Gestion des Heures d'Enseignement

## Description
Application web de gestion des heures d'enseignement et du suivi de l'état d'avancement des cours pour un département universitaire.

## Technologies
- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **Backend**: PHP 7.4+ (Architecture MVC simple)
- **Base de données**: MySQL 5.7+
- **Serveur**: Compatible WAMP/XAMPP/LAMP

## Architecture
Architecture web 3-tiers:
1. **Couche Présentation** (`views/`) - Interfaces utilisateur
2. **Couche Métier/Application** (`controllers/`) - Logique métier
3. **Couche Données** (`models/`) - Accès base de données

## Arborescence complète du projet

```
gestion-heures/
├── config/
│   └── database.php              # Configuration PDO MySQL
│
├── includes/
│   ├── session.php               # Gestion sessions et sécurité
│   └── functions.php             # Fonctions utilitaires globales
│
├── models/
│   ├── Utilisateur.php           # Modèle utilisateurs
│   ├── Enseignant.php            # Modèle enseignants
│   ├── ResponsableClasse.php     # Modèle responsables de classe
│   ├── Seance.php                # Modèle séances
│   ├── Module.php                # Modèle modules
│   ├── UniteEnseignement.php     # Modèle UE
│   ├── Semestre.php              # Modèle semestres
│   └── Chapitre.php              # Modèle chapitres
│
├── controllers/
│   ├── AuthController.php        # Authentification
│   ├── AdminController.php       # Gestion utilisateurs (Admin)
│   ├── SeanceController.php      # Gestion séances
│   ├── ModuleController.php      # Gestion modules/UE/chapitres
│   └── RapportController.php     # Rapports et statistiques
│
├── views/
│   ├── templates/
│   │   ├── header.php            # En-tête commun
│   │   └── footer.php            # Pied de page commun
│   │
│   ├── auth/
│   │   └── login.php             # Page de connexion
│   │
│   ├── admin/
│   │   ├── dashboard.php         # Tableau de bord admin
│   │   ├── users.php             # Liste utilisateurs
│   │   └── user_form.php         # Formulaire utilisateur
│   │
│   ├── chef_der/
│   │   ├── dashboard.php         # Tableau de bord Chef DER
│   │   ├── modules.php           # Liste modules
│   │   ├── module_form.php       # Formulaire module
│   │   ├── semestres.php         # Liste semestres
│   │   ├── semestre_form.php     # Formulaire semestre
│   │   ├── unites.php            # Liste UE
│   │   ├── unite_form.php        # Formulaire UE
│   │   ├── chapitres.php         # Liste chapitres
│   │   ├── chapitre_form.php     # Formulaire chapitre
│   │   ├── rapport_global.php    # Rapport global
│   │   ├── rapport_enseignant.php # Rapport par enseignant
│   │   └── rapport_module.php    # Rapport par module
│   │
│   ├── enseignant/
│   │   └── dashboard.php         # Tableau de bord enseignant
│   │
│   └── responsable/
│       ├── dashboard.php         # Tableau de bord responsable
│       └── saisie_seance.php     # Formulaire saisie séance
│
├── admin/                        # Points d'entrée Admin
│   ├── dashboard.php
│   ├── users.php
│   ├── user_form.php
│   ├── create_user.php
│   ├── update_user.php
│   └── delete_user.php
│
├── chef_der/                     # Points d'entrée Chef DER
│   ├── dashboard.php
│   ├── modules.php
│   ├── module_form.php
│   ├── create_module.php
│   ├── update_module.php
│   ├── delete_module.php
│   ├── semestres.php
│   ├── semestre_form.php
│   ├── create_semestre.php
│   ├── update_semestre.php
│   ├── delete_semestre.php
│   ├── unites.php
│   ├── unite_form.php
│   ├── create_unite.php
│   ├── update_unite.php
│   ├── delete_unite.php
│   ├── chapitres.php
│   ├── chapitre_form.php
│   ├── create_chapitre.php
│   ├── update_chapitre.php
│   ├── delete_chapitre.php
│   ├── rapport_global.php
│   ├── rapport_enseignant.php
│   └── rapport_module.php
│
├── enseignant/                   # Points d'entrée Enseignant
│   ├── dashboard.php
│   ├── valider_seance.php
│   └── contester_seance.php
│
├── responsable/                  # Points d'entrée Responsable
│   ├── dashboard.php
│   ├── saisie_seance.php
│   └── create_seance.php
│
├── assets/
│   ├── css/
│   │   └── style.css             # Styles CSS
│   └── js/
│       └── main.js               # JavaScript
│
├── index.php                     # Point d'entrée principal
├── login.php                     # Connexion
├── logout.php                    # Déconnexion
├── unauthorized.php              # Page accès refusé
├── 404.php                       # Page non trouvée
├── database.sql                  # Script création BDD
└── README.md                     # Documentation
```

## Installation

### 1. Prérequis
- WAMP/XAMPP/LAMP installé
- PHP 7.4 ou supérieur
- MySQL 5.7 ou supérieur

### 2. Configuration base de données
1. Créer la base de données:
```sql
CREATE DATABASE `gestion des heures` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
```

2. Importer le fichier `database.sql`:
```bash
mysql -u root -p "gestion des heures" < database.sql
```

### 3. Configuration
Modifier `config/database.php` si nécessaire:
```php
private $host = "localhost";
private $db_name = "gestion des heures";
private $username = "root";
private $password = "";
```

### 4. Déploiement
Copier le dossier dans `www/` (WAMP) ou `htdocs/` (XAMPP).

## Comptes de test
| Rôle | Login | Mot de passe |
|------|-------|--------------|
| Admin | admin | admin123 |
| Chef DER | chef.der | chef123 |
| Enseignant | prof.martin | prof123 |
| Responsable | resp.l3info | resp123 |

## Fonctionnalités par rôle

### Administrateur
- Gestion complète des utilisateurs (CRUD)
- Attribution des rôles
- Tableau de bord avec statistiques

### Chef de DER
- Création/modification des modules, UE, chapitres
- Gestion des semestres
- Rapports globaux et détaillés
- Validation des séances (en tant qu'enseignant)

### Enseignant
- Visualisation des séances assignées
- Validation ou contestation des séances
- Historique personnel

### Responsable de classe
- Saisie des séances effectuées
- Sélection du module, enseignant et type
- Suivi des séances saisies

## Sécurité
- Authentification par session PHP
- Mots de passe hashés (bcrypt)
- Protection CSRF sur tous les formulaires
- Requêtes préparées PDO (anti-injection SQL)
- Contrôle d'accès basé sur les rôles (RBAC)
- Échappement des sorties (XSS)

## Règles métier
- Une séance saisie a l'état "En_attente"
- Une séance validée met à jour le volume horaire effectué
- Une séance contestée nécessite un motif
- Les rapports calculent heures effectuées vs prévues

## Support
Pour toute question, contacter l'équipe de développement.
