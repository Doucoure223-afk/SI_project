<?php
/**
 * Page 404 - Non trouvé
 */
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = "Page non trouvée";
require_once __DIR__ . '/views/templates/header.php';
?>

<div class="card" style="max-width: 500px; text-align: center;">
    <div class="card-body">
        <div style="font-size: 80px; color: var(--warning); margin-bottom: 20px;">
            <i class="fas fa-search"></i>
        </div>
        <h1 style="color: var(--dark); margin-bottom: 15px;">Page Non Trouvée</h1>
        <p style="color: var(--gray); margin-bottom: 25px;">
            La page que vous recherchez n'existe pas ou a été déplacée.
        </p>
        
        <?php if (isLoggedIn()): ?>
            <a href="<?= url(getDashboardUrl()) ?>" class="btn btn-primary">
                <i class="fas fa-home"></i> Retour au tableau de bord
            </a>
        <?php else: ?>
            <a href="<?= url('login.php') ?>" class="btn btn-primary">
                <i class="fas fa-sign-in-alt"></i> Se connecter
            </a>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/views/templates/footer.php'; ?>
