<?php
/**
 * Point d'entrée - Mise à jour séance
 */
require_once __DIR__ . '/../controllers/SeanceController.php';

$controller = new SeanceController();
$controller->updateSeance();
?>
