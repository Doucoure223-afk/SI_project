<?php
/**
 * Point d'entrée - Formulaire saisie séance
 */
require_once __DIR__ . '/../controllers/SeanceController.php';

$controller = new SeanceController();
$controller->formSaisie();
?>
