<?php
/**
 * Point d'entrée - Formulaire modification séance
 */
require_once __DIR__ . '/../controllers/SeanceController.php';

$controller = new SeanceController();
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

if (!$id) {
    header("Location: mes_seances.php");
    exit();
}

$controller->formEditSeance($id);
?>
