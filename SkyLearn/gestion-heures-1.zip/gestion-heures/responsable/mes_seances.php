<?php
/**
 * Point d'entrée - Mes séances (Responsable de classe)
 */
require_once __DIR__ . '/../controllers/SeanceController.php';

$controller = new SeanceController();
$controller->mesSeances();
?>
