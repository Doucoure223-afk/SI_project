<?php
/**
 * Point d'entrée - Dashboard Responsable de classe
 */
require_once __DIR__ . '/../controllers/SeanceController.php';

$controller = new SeanceController();
$controller->responsableDashboard();
?>
