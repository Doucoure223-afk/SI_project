<?php
/**
 * Point d'entrée - Création séance
 */
require_once __DIR__ . '/../controllers/SeanceController.php';

$controller = new SeanceController();
$controller->createSeance();
?>
