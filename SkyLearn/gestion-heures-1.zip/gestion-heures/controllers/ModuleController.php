<?php
/**
 * ============================================================
 * Contrôleur Modules (Complet)
 * Couche Application - Architecture 3-tiers
 * ============================================================
 */

require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../models/Module.php';
require_once __DIR__ . '/../models/UniteEnseignement.php';
require_once __DIR__ . '/../models/Semestre.php';
require_once __DIR__ . '/../models/Chapitre.php';

class ModuleController {
    private $module;
    private $ue;
    private $semestre;
    private $chapitre;

    public function __construct() {
        requireRole('CHEF_DER');
        $this->module = new Module();
        $this->ue = new UniteEnseignement();
        $this->semestre = new Semestre();
        $this->chapitre = new Chapitre();
    }

    /**
     * Dashboard Chef DER avec filtre par classe
     */
    public function dashboard() {
        require_once __DIR__ . '/../models/Seance.php';
        $seance = new Seance();
        
        $classeFilter = $_GET['classe'] ?? '';
        $allClasses = getClassesList();
        
        if ($classeFilter) {
            // Stats filtrées par classe
            $stats = $seance->getStatistiquesByClasse($classeFilter);
            $statsModules = $seance->getStatsParModuleByClasse($classeFilter);
            $statsEnseignants = $seance->getStatsParEnseignantByClasse($classeFilter);
            $modules = $this->module->getByClasse($classeFilter)->fetchAll(PDO::FETCH_ASSOC);
        } else {
            // Stats globales
            $stats = $seance->getStatistiques();
            $statsModules = $seance->getStatsParModule();
            $statsEnseignants = $seance->getStatsParEnseignant();
            $modules = $this->module->readAll()->fetchAll(PDO::FETCH_ASSOC);
        }
        
        $totalHeuresPrevues = 0;
        $totalHeuresEffectuees = $stats['heures_validees'] ?? 0;
        
        foreach ($modules as $m) {
            $totalHeuresPrevues += $m['Volume_Horaires_CM'] + $m['Volume_Horaires_TD'] + $m['Volume_Horaires_TP'];
        }
        
        $pourcentageGlobal = $totalHeuresPrevues > 0 
            ? round(($totalHeuresEffectuees / $totalHeuresPrevues) * 100, 1) 
            : 0;
        
        require_once __DIR__ . '/../views/chef_der/dashboard.php';
    }

    /**
     * Liste des modules
     */
    public function listModules() {
        $modules = $this->module->readAllWithDetails()->fetchAll(PDO::FETCH_ASSOC);
        $ues = $this->ue->readAll()->fetchAll(PDO::FETCH_ASSOC);

        require_once __DIR__ . '/../views/chef_der/modules.php';
    }

    /**
     * Formulaire module
     */
    public function moduleForm($id = null) {
        $module = null;
        if ($id) {
            $module = $this->module->readOne($id);
            if (!$module) {
                setFlashMessage('error', 'Module non trouvé.');
                redirect(url('chef_der/modules.php'));
            }
        }
        $unites = $this->ue->readAll()->fetchAll(PDO::FETCH_ASSOC);
        
        require_once __DIR__ . '/../views/chef_der/module_form.php';
    }

    /**
     * Créer un module
     */
    public function createModule() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(url('chef_der/module_form.php'));
        }

        if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            setFlashMessage('error', 'Token de sécurité invalide.');
            redirect(url('chef_der/module_form.php'));
        }

        $nom = trim($_POST['nom'] ?? '');
        $cm = (int)($_POST['volume_cm'] ?? 0);
        $td = (int)($_POST['volume_td'] ?? 0);
        $tp = (int)($_POST['volume_tp'] ?? 0);
        $ueId = (int)($_POST['unite_id'] ?? 0);

        if (empty($nom)) {
            setFlashMessage('error', 'Le nom du module est requis.');
            redirect(url('chef_der/module_form.php'));
        }

        $this->module->Nom = $nom;
        $this->module->Volume_Horaires_CM = $cm;
        $this->module->Volume_Horaires_TD = $td;
        $this->module->Volume_Horaires_TP = $tp;
        $this->module->Unite_enseignement_idUnite_enseignement = $ueId > 0 ? $ueId : null;

        if ($this->module->create()) {
            setFlashMessage('success', 'Module créé avec succès.');
        } else {
            setFlashMessage('error', 'Erreur lors de la création.');
        }

        redirect(url('chef_der/modules.php'));
    }

    /**
     * Modifier un module
     */
    public function updateModule($id) {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(url('chef_der/module_form.php?id=' . $id));
        }

        if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            setFlashMessage('error', 'Token de sécurité invalide.');
            redirect(url('chef_der/module_form.php?id=' . $id));
        }

        $nom = trim($_POST['nom'] ?? '');
        $cm = (int)($_POST['volume_cm'] ?? 0);
        $td = (int)($_POST['volume_td'] ?? 0);
        $tp = (int)($_POST['volume_tp'] ?? 0);
        $ueId = (int)($_POST['unite_id'] ?? 0);

        if (empty($nom)) {
            setFlashMessage('error', 'Le nom du module est requis.');
            redirect(url('chef_der/module_form.php?id=' . $id));
        }

        $this->module->idModules = $id;
        $this->module->Nom = $nom;
        $this->module->Volume_Horaires_CM = $cm;
        $this->module->Volume_Horaires_TD = $td;
        $this->module->Volume_Horaires_TP = $tp;
        $this->module->Unite_enseignement_idUnite_enseignement = $ueId > 0 ? $ueId : null;

        if ($this->module->update()) {
            setFlashMessage('success', 'Module modifié avec succès.');
        } else {
            setFlashMessage('error', 'Erreur lors de la modification.');
        }

        redirect(url('chef_der/modules.php'));
    }

    /**
     * Supprimer un module
     */
    public function deleteModule($id) {
        if ($this->module->delete($id)) {
            setFlashMessage('success', 'Module supprimé.');
        } else {
            setFlashMessage('error', 'Erreur lors de la suppression. Vérifiez qu\'aucune séance n\'est liée.');
        }

        redirect(url('chef_der/modules.php'));
    }

    // ==================== SEMESTRES ====================

    public function listSemestres() {
        $semestres = $this->semestre->readAll()->fetchAll(PDO::FETCH_ASSOC);
        require_once __DIR__ . '/../views/chef_der/semestres.php';
    }

    public function semestreForm($id = null) {
        $semestre = null;
        if ($id) {
            $semestre = $this->semestre->readOne($id);
            if (!$semestre) {
                setFlashMessage('error', 'Semestre non trouvé.');
                redirect(url('chef_der/semestres.php'));
            }
        }
        require_once __DIR__ . '/../views/chef_der/semestre_form.php';
    }

    public function createSemestre() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(url('chef_der/semestre_form.php'));
        }

        if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            setFlashMessage('error', 'Token de sécurité invalide.');
            redirect(url('chef_der/semestre_form.php'));
        }

        $dateDebut = $_POST['date_debut'] ?? '';
        $classe = $_POST['classe'] ?? '';

        if (!validateDate($dateDebut)) {
            setFlashMessage('error', 'Date invalide.');
            redirect(url('chef_der/semestre_form.php'));
        }

        if (empty($classe)) {
            setFlashMessage('error', 'La classe est obligatoire.');
            redirect(url('chef_der/semestre_form.php'));
        }

        $this->semestre->date_debut = $dateDebut;
        $this->semestre->Classe = $classe;

        if ($this->semestre->create()) {
            setFlashMessage('success', 'Semestre créé avec succès (état : En cours).');
        } else {
            setFlashMessage('error', 'Erreur lors de la création.');
        }

        redirect(url('chef_der/semestres.php'));
    }

    public function updateSemestre($id) {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(url('chef_der/semestre_form.php?id=' . $id));
        }

        if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            setFlashMessage('error', 'Token de sécurité invalide.');
            redirect(url('chef_der/semestre_form.php?id=' . $id));
        }

        if (!$this->semestre->isModifiable($id)) {
            setFlashMessage('error', 'Ce semestre est terminé et ne peut plus être modifié.');
            redirect(url('chef_der/semestres.php'));
        }

        $dateDebut = $_POST['date_debut'] ?? '';
        $classe = $_POST['classe'] ?? '';

        if (!validateDate($dateDebut) || empty($classe)) {
            setFlashMessage('error', 'Date et classe obligatoires.');
            redirect(url('chef_der/semestre_form.php?id=' . $id));
        }

        $this->semestre->idSemestre = $id;
        $this->semestre->date_debut = $dateDebut;
        $this->semestre->Classe = $classe;

        if ($this->semestre->update()) {
            setFlashMessage('success', 'Semestre modifié avec succès.');
        } else {
            setFlashMessage('error', 'Erreur lors de la modification.');
        }

        redirect(url('chef_der/semestres.php'));
    }

    public function cloturerSemestre() {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        
        if (!$id) {
            setFlashMessage('error', 'Semestre non spécifié.');
            redirect(url('chef_der/semestres.php'));
        }

        if ($this->semestre->cloturer($id)) {
            setFlashMessage('success', 'Semestre clôturé avec succès. Aucune modification ne sera possible.');
        } else {
            setFlashMessage('error', 'Erreur lors de la clôture du semestre.');
        }

        redirect(url('chef_der/semestres.php'));
    }

    public function deleteSemestre($id) {
        if ($this->semestre->delete($id)) {
            setFlashMessage('success', 'Semestre supprimé.');
        } else {
            setFlashMessage('error', 'Erreur lors de la suppression.');
        }

        redirect(url('chef_der/semestres.php'));
    }

    // ==================== UNITÉS D'ENSEIGNEMENT ====================

    public function listUnites() {
        $unites = $this->ue->readAllWithDetails()->fetchAll(PDO::FETCH_ASSOC);
        require_once __DIR__ . '/../views/chef_der/unites.php';
    }

    public function uniteForm($id = null) {
        $unite = null;
        if ($id) {
            $unite = $this->ue->readOne($id);
            if (!$unite) {
                setFlashMessage('error', 'Unité non trouvée.');
                redirect(url('chef_der/unites.php'));
            }
        }
        $semestres = $this->semestre->readAll()->fetchAll(PDO::FETCH_ASSOC);
        require_once __DIR__ . '/../views/chef_der/unite_form.php';
    }

    public function createUnite() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(url('chef_der/unite_form.php'));
        }

        if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            setFlashMessage('error', 'Token de sécurité invalide.');
            redirect(url('chef_der/unite_form.php'));
        }

        $nom = trim($_POST['nom'] ?? '');
        $semestreId = (int)($_POST['semestre_id'] ?? 0);

        if (empty($nom)) {
            setFlashMessage('error', 'Le nom de l\'unité est requis.');
            redirect(url('chef_der/unite_form.php'));
        }

        $this->ue->Nom = $nom;
        $this->ue->Semestre_idSemestre = $semestreId > 0 ? $semestreId : null;

        if ($this->ue->create()) {
            setFlashMessage('success', 'Unité d\'enseignement créée.');
        } else {
            setFlashMessage('error', 'Erreur lors de la création.');
        }

        redirect(url('chef_der/unites.php'));
    }

    public function updateUnite($id) {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(url('chef_der/unite_form.php?id=' . $id));
        }

        if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            setFlashMessage('error', 'Token de sécurité invalide.');
            redirect(url('chef_der/unite_form.php?id=' . $id));
        }

        $nom = trim($_POST['nom'] ?? '');
        $semestreId = (int)($_POST['semestre_id'] ?? 0);

        if (empty($nom)) {
            setFlashMessage('error', 'Le nom de l\'unité est requis.');
            redirect(url('chef_der/unite_form.php?id=' . $id));
        }

        $this->ue->idUnite_enseignement = $id;
        $this->ue->Nom = $nom;
        $this->ue->Semestre_idSemestre = $semestreId > 0 ? $semestreId : null;

        if ($this->ue->update()) {
            setFlashMessage('success', 'Unité modifiée avec succès.');
        } else {
            setFlashMessage('error', 'Erreur lors de la modification.');
        }

        redirect(url('chef_der/unites.php'));
    }

    public function deleteUnite($id) {
        if ($this->ue->delete($id)) {
            setFlashMessage('success', 'Unité supprimée.');
        } else {
            setFlashMessage('error', 'Erreur lors de la suppression.');
        }

        redirect(url('chef_der/unites.php'));
    }

    // ==================== CHAPITRES ====================

    public function listChapitres() {
        $chapitres = $this->chapitre->readAllWithModules()->fetchAll(PDO::FETCH_ASSOC);
        $modules = $this->module->readAll()->fetchAll(PDO::FETCH_ASSOC);
        require_once __DIR__ . '/../views/chef_der/chapitres.php';
    }

    public function chapitreForm($id = null) {
        $chapitre = null;
        if ($id) {
            $chapitre = $this->chapitre->readOne($id);
            if (!$chapitre) {
                setFlashMessage('error', 'Chapitre non trouvé.');
                redirect(url('chef_der/chapitres.php'));
            }
        }
        $modules = $this->module->readAll()->fetchAll(PDO::FETCH_ASSOC);
        require_once __DIR__ . '/../views/chef_der/chapitre_form.php';
    }

    public function createChapitre() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(url('chef_der/chapitre_form.php'));
        }

        if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            setFlashMessage('error', 'Token de sécurité invalide.');
            redirect(url('chef_der/chapitre_form.php'));
        }

        $nom = trim($_POST['nom'] ?? '');
        $moduleId = (int)($_POST['module_id'] ?? 0);

        if (empty($nom) || $moduleId <= 0) {
            setFlashMessage('error', 'Nom et module requis.');
            redirect(url('chef_der/chapitre_form.php'));
        }

        $this->chapitre->Nom = $nom;
        $this->chapitre->Modules_idModules = $moduleId;

        if ($this->chapitre->create()) {
            setFlashMessage('success', 'Chapitre créé.');
        } else {
            setFlashMessage('error', 'Erreur lors de la création.');
        }

        redirect(url('chef_der/chapitres.php'));
    }

    public function updateChapitre($id) {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(url('chef_der/chapitre_form.php?id=' . $id));
        }

        if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            setFlashMessage('error', 'Token de sécurité invalide.');
            redirect(url('chef_der/chapitre_form.php?id=' . $id));
        }

        $nom = trim($_POST['nom'] ?? '');
        $moduleId = (int)($_POST['module_id'] ?? 0);

        if (empty($nom) || $moduleId <= 0) {
            setFlashMessage('error', 'Nom et module requis.');
            redirect(url('chef_der/chapitre_form.php?id=' . $id));
        }

        $this->chapitre->idChapitres = $id;
        $this->chapitre->Nom = $nom;
        $this->chapitre->Modules_idModules = $moduleId;

        if ($this->chapitre->update()) {
            setFlashMessage('success', 'Chapitre modifié.');
        } else {
            setFlashMessage('error', 'Erreur lors de la modification.');
        }

        redirect(url('chef_der/chapitres.php'));
    }

    public function deleteChapitre($id) {
        if ($this->chapitre->delete($id)) {
            setFlashMessage('success', 'Chapitre supprimé.');
        } else {
            setFlashMessage('error', 'Erreur lors de la suppression.');
        }

        redirect(url('chef_der/chapitres.php'));
    }
}
?>