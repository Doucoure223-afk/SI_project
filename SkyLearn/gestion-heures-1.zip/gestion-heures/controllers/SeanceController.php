<?php
/**
 * ============================================================
 * Contrôleur Séances (Complet)
 * Couche Application - Architecture 3-tiers
 * ============================================================
 */

require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../models/Seance.php';
require_once __DIR__ . '/../models/Module.php';
require_once __DIR__ . '/../models/Enseignant.php';
require_once __DIR__ . '/../models/ResponsableClasse.php';

class SeanceController {
    private $seance;
    private $module;
    private $enseignant;
    private $responsable;

    public function __construct() {
        requireLogin();
        $this->seance = new Seance();
        $this->module = new Module();
        $this->enseignant = new Enseignant();
        $this->responsable = new ResponsableClasse();
    }

    /**
     * Dashboard Responsable de classe (filtré par sa classe)
     */
    public function responsableDashboard() {
        requireRole('RESPONSABLE');

        $resp = $this->responsable->getByUserId(getCurrentUserId());
        if (!$resp) {
            setFlashMessage('error', 'Profil responsable non trouvé.');
            redirect(url('login.php'));
        }

        $seances = $this->seance->getByResponsable($resp['idResponsable_Classe'])->fetchAll(PDO::FETCH_ASSOC);
        
        // Statistiques filtrées par la classe du responsable
        $classe = $resp['Classe'] ?? '';
        $modulesClasse = $this->module->getByClasse($classe)->fetchAll(PDO::FETCH_ASSOC);
        
        $totalHeuresPrevues = 0;
        foreach ($modulesClasse as $m) {
            $totalHeuresPrevues += $m['Volume_Horaires_CM'] + $m['Volume_Horaires_TD'] + $m['Volume_Horaires_TP'];
        }
        
        $seancesValidees = array_filter($seances, fn($s) => $s['Etat'] === 'Validée');
        $totalHeuresValidees = array_sum(array_column(array_values($seancesValidees), 'heures_Effectuees'));
        
        $stats = [
            'total' => count($seances),
            'validees' => count($seancesValidees),
            'en_attente' => count(array_filter($seances, fn($s) => $s['Etat'] === 'En_attente')),
            'heures_prevues' => $totalHeuresPrevues,
            'heures_validees' => $totalHeuresValidees
        ];

        require_once __DIR__ . '/../views/responsable/dashboard.php';
    }

    /**
     * Dashboard Enseignant
     */
    public function enseignantDashboard() {
        requireRole(['ENSEIGNANT', 'CHEF_DER']);

        $ens = $this->enseignant->getByUserId(getCurrentUserId());
        if (!$ens) {
            setFlashMessage('error', 'Profil enseignant non trouvé.');
            redirect(url('login.php'));
        }

        $seances = $this->seance->getByEnseignant($ens['idEnseignants'])->fetchAll(PDO::FETCH_ASSOC);
        $seancesEnAttente = $this->seance->getEnAttenteByEnseignant($ens['idEnseignants'])->fetchAll(PDO::FETCH_ASSOC);
        $seancesValidees = array_filter($seances, fn($s) => $s['Etat'] === 'Validée');

        $totalHeuresValidees = array_sum(array_column(array_values($seancesValidees), 'heures_Effectuees'));
        $stats = [
            'total_heures' => $totalHeuresValidees,
            'en_attente' => count($seancesEnAttente),
            'validees' => count($seancesValidees)
        ];

        require_once __DIR__ . '/../views/enseignant/dashboard.php';
    }

    /**
     * Formulaire de saisie de séance (modules filtrés par classe)
     */
    public function formSaisie() {
        requireRole('RESPONSABLE');

        $resp = $this->responsable->getByUserId(getCurrentUserId());
        if (!$resp) {
            setFlashMessage('error', 'Profil responsable non trouvé.');
            redirect(url('login.php'));
        }
        
        // Ne montrer que les modules de la classe du responsable
        $classe = $resp['Classe'] ?? '';
        $modules = $this->module->getByClasse($classe)->fetchAll(PDO::FETCH_ASSOC);
        $enseignants = $this->enseignant->readAllWithUsers()->fetchAll(PDO::FETCH_ASSOC);
        
        require_once __DIR__ . '/../views/responsable/saisie_seance.php';
    }

    /**
     * Créer une séance
     */
    public function createSeance() {
        requireRole('RESPONSABLE');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(url('responsable/saisie_seance.php'));
        }

        if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            setFlashMessage('error', 'Token de sécurité invalide.');
            redirect(url('responsable/saisie_seance.php'));
        }

        $date = $_POST['date_seance'] ?? '';
        $heures = (int)($_POST['heures'] ?? 0);
        $type = $_POST['type_seance'] ?? '';
        $moduleId = (int)($_POST['module_id'] ?? 0);
        $contenuSeance = trim($_POST['contenu_seance'] ?? '');
        $enseignantId = (int)($_POST['enseignant_id'] ?? 0);

        if (!validateDate($date)) {
            setFlashMessage('error', 'Date invalide.');
            redirect(url('responsable/saisie_seance.php'));
        }

        if ($heures <= 0 || $heures > 8) {
            setFlashMessage('error', 'Le nombre d\'heures doit être entre 1 et 8.');
            redirect(url('responsable/saisie_seance.php'));
        }

        if (!in_array($type, ['CM', 'TD', 'TP', 'Devoir', 'Examen'])) {
            setFlashMessage('error', 'Type de séance invalide.');
            redirect(url('responsable/saisie_seance.php'));
        }

        if ($moduleId <= 0 || $enseignantId <= 0) {
            setFlashMessage('error', 'Module et enseignant requis.');
            redirect(url('responsable/saisie_seance.php'));
        }

        $resp = $this->responsable->getByUserId(getCurrentUserId());
        if (!$resp) {
            setFlashMessage('error', 'Profil responsable non trouvé.');
            redirect(url('responsable/dashboard.php'));
        }

        $this->seance->date_Seance = $date;
        $this->seance->heures_Effectuees = $heures;
        $this->seance->Type_Seance = $type;
        $this->seance->Modules_idModules = $moduleId;
        $this->seance->Contenu_Seance = !empty($contenuSeance) ? $contenuSeance : null;
        $this->seance->Enseignants_idEnseignants = $enseignantId;
        $this->seance->Responsable_Classe_idResponsable_Classe = $resp['idResponsable_Classe'];

        if ($this->seance->create()) {
            setFlashMessage('success', 'Séance enregistrée avec succès. En attente de validation.');
            redirect(url('responsable/dashboard.php'));
        } else {
            setFlashMessage('error', 'Erreur lors de l\'enregistrement.');
            redirect(url('responsable/saisie_seance.php'));
        }
    }

    /**
     * Formulaire de modification de séance
     */
    public function formEditSeance($id) {
        requireRole('RESPONSABLE');

        $resp = $this->responsable->getByUserId(getCurrentUserId());
        if (!$resp) {
            setFlashMessage('error', 'Profil responsable non trouvé.');
            redirect(url('responsable/dashboard.php'));
        }

        $seance = $this->seance->readOne($id);
        if (!$seance || $seance['Responsable_Classe_idResponsable_Classe'] != $resp['idResponsable_Classe']) {
            setFlashMessage('error', 'Séance non trouvée ou non autorisée.');
            redirect(url('responsable/mes_seances.php'));
        }

        if (!in_array($seance['Etat'], ['En_attente', 'Revision_demandee'])) {
            setFlashMessage('error', 'Cette séance ne peut plus être modifiée.');
            redirect(url('responsable/mes_seances.php'));
        }

        // Ne montrer que les modules de la classe du responsable
        $classe = $resp['Classe'] ?? '';
        $modules = $this->module->getByClasse($classe)->fetchAll(PDO::FETCH_ASSOC);
        $enseignants = $this->enseignant->readAllWithUsers()->fetchAll(PDO::FETCH_ASSOC);

        require_once __DIR__ . '/../views/responsable/edit_seance.php';
    }

    /**
     * Modifier une séance
     */
    public function updateSeance() {
        requireRole('RESPONSABLE');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(url('responsable/mes_seances.php'));
        }

        if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            setFlashMessage('error', 'Token de sécurité invalide.');
            redirect(url('responsable/mes_seances.php'));
        }

        $id = (int)($_POST['id_seance'] ?? 0);
        $resp = $this->responsable->getByUserId(getCurrentUserId());
        if (!$resp) {
            setFlashMessage('error', 'Profil responsable non trouvé.');
            redirect(url('responsable/dashboard.php'));
        }

        $existing = $this->seance->readOne($id);
        if (!$existing || $existing['Responsable_Classe_idResponsable_Classe'] != $resp['idResponsable_Classe']) {
            setFlashMessage('error', 'Séance non trouvée ou non autorisée.');
            redirect(url('responsable/mes_seances.php'));
        }

        if (!in_array($existing['Etat'], ['En_attente', 'Revision_demandee'])) {
            setFlashMessage('error', 'Cette séance ne peut plus être modifiée.');
            redirect(url('responsable/mes_seances.php'));
        }

        $date = $_POST['date_seance'] ?? '';
        $heures = (int)($_POST['heures'] ?? 0);
        $type = $_POST['type_seance'] ?? '';
        $moduleId = (int)($_POST['module_id'] ?? 0);
        $contenuSeance = trim($_POST['contenu_seance'] ?? '');
        $enseignantId = (int)($_POST['enseignant_id'] ?? 0);

        if (!validateDate($date) || $heures <= 0 || $heures > 8 || !in_array($type, ['CM', 'TD', 'TP', 'Devoir', 'Examen']) || $moduleId <= 0 || $enseignantId <= 0) {
            setFlashMessage('error', 'Données invalides.');
            redirect(url('responsable/edit_seance.php?id=' . $id));
        }

        $this->seance->idSeances = $id;
        $this->seance->date_Seance = $date;
        $this->seance->heures_Effectuees = $heures;
        $this->seance->Type_Seance = $type;
        $this->seance->Modules_idModules = $moduleId;
        $this->seance->Contenu_Seance = !empty($contenuSeance) ? $contenuSeance : null;
        $this->seance->Enseignants_idEnseignants = $enseignantId;

        if ($this->seance->update()) {
            setFlashMessage('success', 'Séance modifiée avec succès. En attente de re-validation par l\'enseignant.');
            redirect(url('responsable/mes_seances.php'));
        } else {
            setFlashMessage('error', 'Erreur lors de la modification.');
            redirect(url('responsable/edit_seance.php?id=' . $id));
        }
    }

    /**
     * Valider une séance
     */
    public function validerSeance($id) {
        requireRole(['ENSEIGNANT', 'CHEF_DER']);

        $ens = $this->enseignant->getByUserId(getCurrentUserId());
        if (!$ens) {
            setFlashMessage('error', 'Profil enseignant non trouvé.');
            redirect(url('enseignant/dashboard.php'));
        }

        $seance = $this->seance->readOne($id);
        if (!$seance || $seance['Enseignants_idEnseignants'] != $ens['idEnseignants']) {
            setFlashMessage('error', 'Séance non trouvée ou non autorisée.');
            redirect(url('enseignant/dashboard.php'));
        }

        if ($this->seance->valider($id)) {
            setFlashMessage('success', 'Séance validée avec succès.');
        } else {
            setFlashMessage('error', 'Erreur lors de la validation.');
        }

        redirect(url('enseignant/dashboard.php'));
    }

    /**
     * Demander une révision
     */
    public function demanderRevision($id, $motif) {
        requireRole(['ENSEIGNANT', 'CHEF_DER']);

        if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            setFlashMessage('error', 'Token de sécurité invalide.');
            redirect(url('enseignant/dashboard.php'));
        }

        $ens = $this->enseignant->getByUserId(getCurrentUserId());
        if (!$ens) {
            setFlashMessage('error', 'Profil enseignant non trouvé.');
            redirect(url('enseignant/dashboard.php'));
        }

        $seance = $this->seance->readOne($id);
        if (!$seance || $seance['Enseignants_idEnseignants'] != $ens['idEnseignants']) {
            setFlashMessage('error', 'Séance non trouvée ou non autorisée.');
            redirect(url('enseignant/dashboard.php'));
        }

        if (empty($motif)) {
            setFlashMessage('error', 'Le motif de la demande de révision est requis.');
            redirect(url('enseignant/contester_seance.php?id=' . $id));
        }

        if ($this->seance->demanderRevision($id, $motif)) {
            setFlashMessage('success', 'Demande de révision envoyée avec succès.');
        } else {
            setFlashMessage('error', 'Erreur lors de la demande de révision.');
        }

        redirect(url('enseignant/dashboard.php'));
    }

    /**
     * Liste des séances (pour Enseignant ou Responsable)
     */
    public function mesSeances() {
        $userId = getCurrentUserId();
        $userRole = getCurrentUserRole();
        
        if ($userRole === 'RESPONSABLE') {
            $resp = $this->responsable->getByUserId($userId);
            if (!$resp) {
                setFlashMessage('error', 'Profil responsable non trouvé.');
                redirect(url('login.php'));
            }
            
            $seances = $this->seance->getByResponsable($resp['idResponsable_Classe'])->fetchAll(PDO::FETCH_ASSOC);
            $pageTitle = "Mes séances saisies";
            require_once __DIR__ . '/../views/responsable/mes_seances.php';
            
        } else {
            requireRole(['ENSEIGNANT', 'CHEF_DER']);
            
            $ens = $this->enseignant->getByUserId($userId);
            if (!$ens) {
                setFlashMessage('error', 'Profil enseignant non trouvé.');
                redirect(url('login.php'));
            }
            
            $seances = $this->seance->getByEnseignant($ens['idEnseignants'])->fetchAll(PDO::FETCH_ASSOC);
            $pageTitle = "Mes séances";
            require_once __DIR__ . '/../views/enseignant/seances.php';
        }
    }
}
?>
