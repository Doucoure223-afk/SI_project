<?php
/**
 * ============================================================
 * Contrôleur Rapports (Complet)
 * Couche Application - Architecture 3-tiers
 * ============================================================
 */

require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../models/Seance.php';
require_once __DIR__ . '/../models/Module.php';
require_once __DIR__ . '/../models/Semestre.php';
require_once __DIR__ . '/../models/UniteEnseignement.php';
require_once __DIR__ . '/../models/Enseignant.php';
require_once __DIR__ . '/../models/Chapitre.php';

class RapportController {
    private $seance;
    private $module;
    private $semestre;
    private $ue;
    private $enseignant;
    private $chapitre;

    public function __construct() {
        requireRole('CHEF_DER');
        $this->seance = new Seance();
        $this->module = new Module();
        $this->semestre = new Semestre();
        $this->ue = new UniteEnseignement();
        $this->enseignant = new Enseignant();
        $this->chapitre = new Chapitre();
    }

    /**
     * Déterminer le semestre à utiliser
     */
    private function getSemestreId() {
        if (isset($_GET['semestre']) && (int)$_GET['semestre'] > 0) {
            return (int)$_GET['semestre'];
        }
        $current = $this->semestre->getCurrent();
        return $current ? $current['idSemestre'] : null;
    }

    /**
     * Récupérer le filtre classe
     */
    private function getClasseFilter() {
        return $_GET['classe'] ?? '';
    }

    /**
     * Rapport global (filtré par classe)
     */
    public function rapportGlobal() {
        $classeFilter = $this->getClasseFilter();
        $allClasses = getClassesList();
        $allSemestres = $this->semestre->readAll()->fetchAll(PDO::FETCH_ASSOC);

        if ($classeFilter) {
            $stats = $this->seance->getStatistiquesByClasse($classeFilter);
            $modules = $this->module->getByClasse($classeFilter)->fetchAll(PDO::FETCH_ASSOC);
            $seances = $this->seance->readAllByClasse($classeFilter)->fetchAll(PDO::FETCH_ASSOC);
        } else {
            $stats = $this->seance->getStatistiques();
            $modules = $this->module->readAll()->fetchAll(PDO::FETCH_ASSOC);
            $seances = $this->seance->readAll()->fetchAll(PDO::FETCH_ASSOC);
        }

        $totalHeuresPrevues = 0;
        foreach ($modules as $m) {
            $totalHeuresPrevues += $m['Volume_Horaires_CM'] + $m['Volume_Horaires_TD'] + $m['Volume_Horaires_TP'];
        }

        $totalHeuresEffectuees = $stats['heures_validees'] ?? 0;
        $pourcentageGlobal = $totalHeuresPrevues > 0 
            ? round(($totalHeuresEffectuees / $totalHeuresPrevues) * 100, 1) 
            : 0;

        // Variables pour compatibilité avec la vue
        $semestreInfo = null;

        require_once __DIR__ . '/../views/chef_der/rapport_global.php';
    }

    /**
     * Liste des rapports par module (filtré par classe)
     */
    public function listeRapportModules() {
        $classeFilter = $this->getClasseFilter();
        $allClasses = getClassesList();

        if ($classeFilter) {
            $statsModules = $this->seance->getStatsParModuleByClasse($classeFilter);
        } else {
            $statsModules = $this->seance->getStatsParModule();
        }

        require_once __DIR__ . '/../views/chef_der/rapport_modules_liste.php';
    }

    /**
     * Rapport par module (détail)
     */
    public function rapportModule($id) {
        $classeFilter = $this->getClasseFilter();

        if (!$id) {
            setFlashMessage('error', 'Module non spécifié.');
            redirect(url('chef_der/rapport_modules.php'));
        }

        $module = $this->module->readOne($id);
        if (!$module) {
            setFlashMessage('error', 'Module non trouvé.');
            redirect(url('chef_der/rapport_modules.php'));
        }

        $semestreInfo = null;
        $seances = $this->seance->getByModule($id)->fetchAll(PDO::FETCH_ASSOC);
        $chapitres = $this->chapitre->getByModule($id)->fetchAll(PDO::FETCH_ASSOC);
        
        $seancesValidees = array_filter($seances, fn($s) => $s['Etat'] === 'Validée');
        
        $cmEffectue = array_sum(array_column(
            array_filter($seancesValidees, fn($s) => $s['Type_Seance'] === 'CM'), 'heures_Effectuees'
        ));
        $tdEffectue = array_sum(array_column(
            array_filter($seancesValidees, fn($s) => $s['Type_Seance'] === 'TD'), 'heures_Effectuees'
        ));
        $tpEffectue = array_sum(array_column(
            array_filter($seancesValidees, fn($s) => $s['Type_Seance'] === 'TP'), 'heures_Effectuees'
        ));

        $stats = [
            'cm_effectue' => $cmEffectue,
            'td_effectue' => $tdEffectue,
            'tp_effectue' => $tpEffectue,
            'cm_restant' => max(0, $module['Volume_Horaires_CM'] - $cmEffectue),
            'td_restant' => max(0, $module['Volume_Horaires_TD'] - $tdEffectue),
            'tp_restant' => max(0, $module['Volume_Horaires_TP'] - $tpEffectue)
        ];

        $enseignantsIds = array_unique(array_column($seancesValidees, 'Enseignants_idEnseignants'));
        $enseignants = [];
        foreach ($enseignantsIds as $ensId) {
            $ens = $this->enseignant->readOneWithUser($ensId);
            if ($ens) {
                $ensSeances = array_filter($seancesValidees, fn($s) => $s['Enseignants_idEnseignants'] == $ensId);
                $ens['total_heures'] = array_sum(array_column($ensSeances, 'heures_Effectuees'));
                $enseignants[] = $ens;
            }
        }

        require_once __DIR__ . '/../views/chef_der/rapport_module.php';
    }

    /**
     * Liste des rapports par enseignant (filtré par classe)
     */
    public function listeRapportEnseignants() {
        $classeFilter = $this->getClasseFilter();
        $allClasses = getClassesList();

        if ($classeFilter) {
            $statsEnseignants = $this->seance->getStatsParEnseignantByClasse($classeFilter);
        } else {
            $statsEnseignants = $this->seance->getStatsParEnseignant();
        }

        require_once __DIR__ . '/../views/chef_der/rapport_enseignants_liste.php';
    }

    /**
     * Rapport par enseignant (détail)
     */
    public function rapportEnseignant($id) {
        $classeFilter = $this->getClasseFilter();

        if (!$id) {
            setFlashMessage('error', 'Enseignant non spécifié.');
            redirect(url('chef_der/rapport_enseignants.php'));
        }

        $enseignant = $this->enseignant->readOneWithUser($id);
        if (!$enseignant) {
            setFlashMessage('error', 'Enseignant non trouvé.');
            redirect(url('chef_der/rapport_enseignants.php'));
        }

        $semestreInfo = null;
        $seances = $this->seance->getByEnseignant($id)->fetchAll(PDO::FETCH_ASSOC);

        // Filtrer par classe si spécifié
        if ($classeFilter) {
            $seances = array_filter($seances, fn($s) => ($s['classe_semestre'] ?? '') === $classeFilter);
        }
        
        $seancesValidees = array_filter($seances, fn($s) => $s['Etat'] === 'Validée');
        $stats = [
            'heures_validees' => array_sum(array_column($seancesValidees, 'heures_Effectuees')),
            'heures_attente' => array_sum(array_column(
                array_filter($seances, fn($s) => $s['Etat'] === 'En_attente'), 'heures_Effectuees'
            )),
            'heures_cm' => array_sum(array_column(
                array_filter($seancesValidees, fn($s) => $s['Type_Seance'] === 'CM'), 'heures_Effectuees'
            )),
            'heures_td' => array_sum(array_column(
                array_filter($seancesValidees, fn($s) => $s['Type_Seance'] === 'TD'), 'heures_Effectuees'
            )),
            'heures_tp' => array_sum(array_column(
                array_filter($seancesValidees, fn($s) => $s['Type_Seance'] === 'TP'), 'heures_Effectuees'
            )),
            'nb_modules' => count(array_unique(array_column($seances, 'Modules_idModules')))
        ];

        require_once __DIR__ . '/../views/chef_der/rapport_enseignant.php';
    }
}
?>