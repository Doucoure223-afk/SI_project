<?php
/**
 * ============================================================
 * Contrôleur Authentification
 * Couche Application - Architecture 3-tiers
 * ============================================================
 */

require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../models/Utilisateur.php';

class AuthController {
    private $utilisateur;

    public function __construct() {
        $this->utilisateur = new Utilisateur();
    }

    /**
     * Traiter la connexion
     */
    public function login() {
        // Si déjà connecté, rediriger vers le dashboard
        if (isLoggedIn()) {
            $this->redirectToDashboard();
        }

        // Traitement du formulaire
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Vérifier le token CSRF
            if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
                setFlashMessage('error', 'Token de sécurité invalide.');
                redirect(url('login.php'));
            }

            $login = trim($_POST['login'] ?? '');
            $password = $_POST['password'] ?? '';

            // Validation
            if (empty($login) || empty($password)) {
                setFlashMessage('error', 'Veuillez remplir tous les champs.');
                redirect(url('login.php'));
            }

            // Authentification
            $user = $this->utilisateur->authenticate($login, $password);

            if ($user) {
                createUserSession($user);
                setFlashMessage('success', 'Bienvenue ' . escape($user['Prenom']) . ' !');
                $this->redirectToDashboard();
            } else {
                setFlashMessage('error', 'Identifiants incorrects.');
                redirect(url('login.php'));
            }
        }

        // Afficher le formulaire de connexion
        require_once __DIR__ . '/../views/auth/login.php';
    }

    /**
     * Déconnexion
     */
    public function logout() {
        destroyUserSession();
        setFlashMessage('success', 'Vous avez été déconnecté.');
        redirect(url('login.php'));
    }

    /**
     * Rediriger vers le dashboard approprié selon le rôle
     */
    private function redirectToDashboard() {
        $role = getCurrentUserRole();

        switch ($role) {
            case 'ADMIN':
                redirect(url('admin/dashboard.php'));
                break;
            case 'CHEF_DER':
                redirect(url('chef_der/dashboard.php'));
                break;
            case 'ENSEIGNANT':
                redirect(url('enseignant/dashboard.php'));
                break;
            case 'RESPONSABLE':
                redirect(url('responsable/dashboard.php'));
                break;
            default:
                redirect(url('login.php'));
        }
    }
}

// Point d'entrée si appelé directement
if (basename($_SERVER['PHP_SELF']) === 'login.php' || 
    basename($_SERVER['PHP_SELF']) === 'logout.php') {
    $controller = new AuthController();
    
    if (basename($_SERVER['PHP_SELF']) === 'logout.php') {
        $controller->logout();
    } else {
        $controller->login();
    }
}
?>
