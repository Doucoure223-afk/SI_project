<?php
/**
 * ============================================================
 * Contrôleur Administration
 * Couche Application - Architecture 3-tiers
 * ============================================================
 */

require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../models/Utilisateur.php';
require_once __DIR__ . '/../models/Enseignant.php';
require_once __DIR__ . '/../models/ResponsableClasse.php';

class AdminController {
    private $utilisateur;
    private $enseignant;
    private $responsable;

    public function __construct() {
        requireRole('ADMIN');
        $this->utilisateur = new Utilisateur();
        $this->enseignant = new Enseignant();
        $this->responsable = new ResponsableClasse();
    }

    /**
     * Dashboard administrateur
     */
    public function dashboard() {
        $users = $this->utilisateur->readAll()->fetchAll(PDO::FETCH_ASSOC);
        $stats = [
            'total_users' => count($users),
            'admins' => count(array_filter($users, fn($u) => $u['Role'] === 'ADMIN')),
            'enseignants' => count(array_filter($users, fn($u) => in_array($u['Role'], ['ENSEIGNANT', 'CHEF_DER']))),
            'responsables' => count(array_filter($users, fn($u) => $u['Role'] === 'RESPONSABLE'))
        ];
        
        require_once __DIR__ . '/../views/admin/dashboard.php';
    }

    /**
     * Liste des utilisateurs
     */
    public function listUsers() {
        $users = $this->utilisateur->readAll()->fetchAll(PDO::FETCH_ASSOC);
        require_once __DIR__ . '/../views/admin/users.php';
    }

    /**
     * Formulaire création/modification utilisateur
     */
    public function userForm($id = null) {
        $user = null;
        $enseignant = null;
        $responsable = null;

        if ($id) {
            $user = $this->utilisateur->readOne($id);
            if (!$user) {
                setFlashMessage('error', 'Utilisateur non trouvé.');
                redirect(url('admin/users.php'));
            }

            if (in_array($user['Role'], ['ENSEIGNANT', 'CHEF_DER'])) {
                $enseignant = $this->enseignant->getByUserId($id);
            } elseif ($user['Role'] === 'RESPONSABLE') {
                $responsable = $this->responsable->getByUserId($id);
            }
        }

        require_once __DIR__ . '/../views/admin/user_form.php';
    }

    /**
     * Créer un utilisateur
     */
    public function createUser() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(url('admin/user_form.php'));
        }

        // Vérifier CSRF
        if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            setFlashMessage('error', 'Token de sécurité invalide.');
            redirect(url('admin/user_form.php'));
        }

        // Validation
        $nom = trim($_POST['nom'] ?? '');
        $prenom = trim($_POST['prenom'] ?? '');
        $login = trim($_POST['login'] ?? '');
        $password = $_POST['password'] ?? '';
        $role = $_POST['role'] ?? '';

        if (empty($nom) || empty($prenom) || empty($login) || empty($password) || empty($role)) {
            setFlashMessage('error', 'Tous les champs sont obligatoires.');
            redirect(url('admin/user_form.php'));
        }

        // Vérifier si le login existe
        if ($this->utilisateur->loginExists($login)) {
            setFlashMessage('error', 'Ce login est déjà utilisé.');
            redirect(url('admin/user_form.php'));
        }

        // Créer l'utilisateur
        $this->utilisateur->Nom = $nom;
        $this->utilisateur->Prenom = $prenom;
        $this->utilisateur->Login = $login;
        $this->utilisateur->Mot_De_Passe = $password;
        $this->utilisateur->Role = $role;

        if ($this->utilisateur->create()) {
            $userId = $this->utilisateur->idUtilisateurs;

            // Créer l'entrée spécifique selon le rôle
            if (in_array($role, ['ENSEIGNANT', 'CHEF_DER'])) {
                $grade = trim($_POST['grade'] ?? '');
                if ($grade === 'Autre') {
                    $grade = trim($_POST['grade_autre'] ?? 'Non spécifié');
                }
                $this->enseignant->Grade = !empty($grade) ? $grade : 'Non spécifié';
                $this->enseignant->Utilisateurs_idUtilisateurs = $userId;
                $this->enseignant->create();

                // Si Chef DER, créer aussi l'entrée Chef_DER
                if ($role === 'CHEF_DER') {
                    $database = new Database();
                    $conn = $database->getConnection();
                    $stmt = $conn->prepare("INSERT INTO Chef_DER (Enseignants_idEnseignants) VALUES (:id)");
                    $stmt->bindParam(':id', $this->enseignant->idEnseignants);
                    $stmt->execute();
                }
            } elseif ($role === 'RESPONSABLE') {
                $this->responsable->Classe = trim($_POST['classe'] ?? '');
                $this->responsable->Utilisateurs_idUtilisateurs = $userId;
                $this->responsable->create();
            }

            setFlashMessage('success', 'Utilisateur créé avec succès.');
            redirect(url('admin/users.php'));
        } else {
            setFlashMessage('error', 'Erreur lors de la création.');
            redirect(url('admin/user_form.php'));
        }
    }

    /**
     * Modifier un utilisateur
     */
    public function updateUser($id) {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(url('admin/user_form.php?id=' . $id));
        }

        // Vérifier CSRF
        if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            setFlashMessage('error', 'Token de sécurité invalide.');
            redirect(url('admin/user_form.php?id=' . $id));
        }

        $user = $this->utilisateur->readOne($id);
        if (!$user) {
            setFlashMessage('error', 'Utilisateur non trouvé.');
            redirect(url('admin/users.php'));
        }

        // Validation
        $nom = trim($_POST['nom'] ?? '');
        $prenom = trim($_POST['prenom'] ?? '');
        $login = trim($_POST['login'] ?? '');
        $password = $_POST['password'] ?? '';
        $role = $_POST['role'] ?? '';

        if (empty($nom) || empty($prenom) || empty($login) || empty($role)) {
            setFlashMessage('error', 'Les champs nom, prénom, login et rôle sont obligatoires.');
            redirect(url('admin/user_form.php?id=' . $id));
        }

        // Vérifier si le login existe (sauf pour cet utilisateur)
        if ($this->utilisateur->loginExists($login, $id)) {
            setFlashMessage('error', 'Ce login est déjà utilisé.');
            redirect(url('admin/user_form.php?id=' . $id));
        }

        // Mettre à jour
        $this->utilisateur->idUtilisateurs = $id;
        $this->utilisateur->Nom = $nom;
        $this->utilisateur->Prenom = $prenom;
        $this->utilisateur->Login = $login;
        $this->utilisateur->Mot_De_Passe = $password; // Vide si pas de changement
        $this->utilisateur->Role = $role;

        if ($this->utilisateur->update()) {
            setFlashMessage('success', 'Utilisateur modifié avec succès.');
        } else {
            setFlashMessage('error', 'Erreur lors de la modification.');
        }

        redirect(url('admin/users.php'));
    }

    /**
     * Supprimer un utilisateur
     */
    public function deleteUser($id) {
        // Empêcher la suppression de soi-même
        if ($id == getCurrentUserId()) {
            setFlashMessage('error', 'Vous ne pouvez pas supprimer votre propre compte.');
            redirect(url('admin/users.php'));
        }

        if ($this->utilisateur->delete($id)) {
            setFlashMessage('success', 'Utilisateur supprimé avec succès.');
        } else {
            setFlashMessage('error', 'Erreur lors de la suppression.');
        }

        redirect(url('admin/users.php'));
    }
}
?>
