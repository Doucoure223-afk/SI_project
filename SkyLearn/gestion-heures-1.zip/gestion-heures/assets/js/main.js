/**
 * ============================================================
 * JavaScript Principal - Gestion des Heures d'Enseignement
 * ============================================================
 */

// ========== Fonctions globales pour la sidebar mobile ==========
function toggleMobileSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.querySelector('.sidebar-overlay');
    sidebar.classList.toggle('active');
    if (overlay) overlay.classList.toggle('active');
    document.body.style.overflow = sidebar.classList.contains('active') ? 'hidden' : '';
}

function closeMobileSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.querySelector('.sidebar-overlay');
    sidebar.classList.remove('active');
    if (overlay) overlay.classList.remove('active');
    document.body.style.overflow = '';
}

document.addEventListener('DOMContentLoaded', function() {
    // ========== Créer l'overlay mobile ==========
    const overlay = document.createElement('div');
    overlay.className = 'sidebar-overlay';
    document.body.appendChild(overlay);
    overlay.addEventListener('click', closeMobileSidebar);

    // ========== Fermer les alertes ==========
    const alertCloseButtons = document.querySelectorAll('.alert-close');
    alertCloseButtons.forEach(function(btn) {
        btn.addEventListener('click', function() {
            this.closest('.alert').remove();
        });
    });

    // Auto-fermer les alertes après 5 secondes
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            alert.style.opacity = '0';
            setTimeout(function() {
                alert.remove();
            }, 300);
        }, 5000);
    });

    // ========== Gestion des modals ==========
    const modalTriggers = document.querySelectorAll('[data-modal]');
    const modalBackdrops = document.querySelectorAll('.modal-backdrop');
    const modalCloseButtons = document.querySelectorAll('.modal-close, [data-modal-close]');

    modalTriggers.forEach(function(trigger) {
        trigger.addEventListener('click', function(e) {
            e.preventDefault();
            const modalId = this.getAttribute('data-modal');
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.classList.add('active');
                document.body.style.overflow = 'hidden';
            }
        });
    });

    modalCloseButtons.forEach(function(btn) {
        btn.addEventListener('click', function() {
            const modal = this.closest('.modal-backdrop');
            if (modal) {
                modal.classList.remove('active');
                document.body.style.overflow = '';
            }
        });
    });

    modalBackdrops.forEach(function(backdrop) {
        backdrop.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('active');
                document.body.style.overflow = '';
            }
        });
    });

    // ========== Confirmation de suppression ==========
    const deleteButtons = document.querySelectorAll('[data-confirm]');
    deleteButtons.forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            const message = this.getAttribute('data-confirm') || 'Êtes-vous sûr de vouloir supprimer cet élément ?';
            if (!confirm(message)) {
                e.preventDefault();
            }
        });
    });

    // ========== Validation des formulaires ==========
    const forms = document.querySelectorAll('form[data-validate]');
    forms.forEach(function(form) {
        form.addEventListener('submit', function(e) {
            let isValid = true;
            const requiredFields = form.querySelectorAll('[required]');
            
            requiredFields.forEach(function(field) {
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('is-invalid');
                } else {
                    field.classList.remove('is-invalid');
                }
            });

            if (!isValid) {
                e.preventDefault();
                alert('Veuillez remplir tous les champs obligatoires.');
            }
        });
    });

    // ========== Toggle pour champs conditionnels (rôle utilisateur) ==========
    const roleSelect = document.getElementById('role');
    if (roleSelect) {
        const gradeField = document.getElementById('grade-field');
        const classeField = document.getElementById('classe-field');

        function toggleRoleFields() {
            const role = roleSelect.value;
            
            if (gradeField) {
                gradeField.style.display = (role === 'ENSEIGNANT' || role === 'CHEF_DER') ? 'block' : 'none';
            }
            
            if (classeField) {
                classeField.style.display = (role === 'RESPONSABLE') ? 'block' : 'none';
            }
        }

        roleSelect.addEventListener('change', toggleRoleFields);
        toggleRoleFields();
    }

    // ========== Toggle grade "Autre" ==========
    const gradeSelect = document.getElementById('grade');
    if (gradeSelect) {
        function toggleGradeAutre() {
            const autreField = document.getElementById('grade-autre-field');
            if (autreField) {
                autreField.style.display = gradeSelect.value === 'Autre' ? 'block' : 'none';
            }
        }
        gradeSelect.addEventListener('change', toggleGradeAutre);
        toggleGradeAutre();
    }

    // ========== Calcul dynamique des heures restantes ==========
    const moduleSelect = document.getElementById('module_id');
    const typeSelect = document.getElementById('type_seance');
    const heuresInput = document.getElementById('heures');
    const heuresInfo = document.getElementById('heures-info');

    if (moduleSelect && typeSelect && heuresInput && heuresInfo) {
        function updateHeuresInfo() {
            const moduleId = moduleSelect.value;
            const type = typeSelect.value;
            
            if (moduleId && type) {
                fetch(`api/module_heures.php?module_id=${moduleId}&type=${type}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            heuresInfo.textContent = `Heures restantes : ${data.restant}h sur ${data.total}h`;
                            heuresInfo.style.display = 'block';
                        }
                    })
                    .catch(error => {
                        console.error('Erreur:', error);
                    });
            }
        }

        moduleSelect.addEventListener('change', updateHeuresInfo);
        typeSelect.addEventListener('change', updateHeuresInfo);
    }

    // ========== Recherche dans les tables ==========
    const searchInput = document.getElementById('table-search');
    if (searchInput) {
        const table = document.querySelector('table tbody');
        
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const rows = table.querySelectorAll('tr');
            
            rows.forEach(function(row) {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });
    }

    // ========== Tooltips ==========
    const tooltipElements = document.querySelectorAll('[data-tooltip]');
    tooltipElements.forEach(function(el) {
        el.addEventListener('mouseenter', function() {
            const text = this.getAttribute('data-tooltip');
            const tooltip = document.createElement('div');
            tooltip.className = 'tooltip';
            tooltip.textContent = text;
            document.body.appendChild(tooltip);
            
            const rect = this.getBoundingClientRect();
            tooltip.style.top = (rect.top - tooltip.offsetHeight - 10) + 'px';
            tooltip.style.left = (rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2)) + 'px';
        });
        
        el.addEventListener('mouseleave', function() {
            const tooltip = document.querySelector('.tooltip');
            if (tooltip) tooltip.remove();
        });
    });

    // ========== Impression des rapports ==========
    const printBtn = document.getElementById('print-report');
    if (printBtn) {
        printBtn.addEventListener('click', function() {
            window.print();
        });
    }

    // ========== Export CSV ==========
    const exportBtn = document.getElementById('export-csv');
    if (exportBtn) {
        exportBtn.addEventListener('click', function() {
            const table = document.querySelector('table');
            if (!table) return;
            
            let csv = [];
            const rows = table.querySelectorAll('tr');
            
            rows.forEach(function(row) {
                const cols = row.querySelectorAll('td, th');
                const rowData = [];
                
                cols.forEach(function(col) {
                    if (!col.classList.contains('actions')) {
                        rowData.push('"' + col.textContent.trim().replace(/"/g, '""') + '"');
                    }
                });
                
                csv.push(rowData.join(','));
            });
            
            const csvContent = csv.join('\n');
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            
            link.setAttribute('href', url);
            link.setAttribute('download', 'export_' + new Date().toISOString().slice(0,10) + '.csv');
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        });
    }
});
