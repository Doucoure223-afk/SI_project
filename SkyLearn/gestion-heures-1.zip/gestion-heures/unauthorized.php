<?php
/**
 * Page d'accès non autorisé
 */
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = "Accès refusé";
require_once __DIR__ . '/views/templates/header.php';
?>

<div class="card" style="max-width: 500px; text-align: center;">
    <div class="card-body">
        <div style="font-size: 80px; color: var(--danger); margin-bottom: 20px;">
            <i class="fas fa-ban"></i>
        </div>
        <h1 style="color: var(--danger); margin-bottom: 15px;">Accès Refusé</h1>
        <p style="color: var(--gray); margin-bottom: 25px;">
            Vous n'avez pas les permissions nécessaires pour accéder à cette page.
        </p>
        
        <?php if (isLoggedIn()): ?>
            <a href="<?= url(getDashboardUrl()) ?>" class="btn btn-primary">
                <i class="fas fa-home"></i> Retour au tableau de bord
            </a>
        <?php else: ?>
            <a href="<?= url('login.php') ?>" class="btn btn-primary">
                <i class="fas fa-sign-in-alt"></i> Se connecter
            </a>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/views/templates/footer.php'; ?>
