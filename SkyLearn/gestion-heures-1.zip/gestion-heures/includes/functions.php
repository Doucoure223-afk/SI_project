<?php
/**
 * ============================================================
 * Fonctions utilitaires
 * ============================================================
 */

/**
 * Échapper les caractères HTML pour prévenir XSS
 */
function escape($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Rediriger vers une URL
 */
function redirect($url) {
    header("Location: " . $url);
    exit();
}

/**
 * Formater une date en français
 */
function formatDateFr($date) {
    $timestamp = strtotime($date);
    $jours = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
    $mois = ['', 'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 
             'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
    
    return $jours[date('w', $timestamp)] . ' ' . 
           date('d', $timestamp) . ' ' . 
           $mois[intval(date('m', $timestamp))] . ' ' . 
           date('Y', $timestamp);
}

/**
 * Obtenir le libellé d'un état de séance
 */
function getEtatLabel($etat) {
    $labels = [
        'En_attente' => '<span class="badge badge-warning">En attente</span>',
        'Validée' => '<span class="badge badge-success">Validée</span>',
        'Revision_demandee' => '<span class="badge badge-info">Révision demandée</span>'
    ];
    return $labels[$etat] ?? $etat;
}

/**
 * Obtenir le libellé d'un type de séance
 */
function getTypeSeanceLabel($type) {
    $labels = [
        'CM' => 'Cours Magistral',
        'TD' => 'Travaux Dirigés',
        'TP' => 'Travaux Pratiques',
        'Devoir' => 'Devoir',
        'Examen' => 'Examen'
    ];
    return $labels[$type] ?? $type;
}

/**
 * Obtenir le libellé d'un rôle
 */
function getRoleLabel($role) {
    $labels = [
        'ADMIN' => 'Administrateur',
        'CHEF_DER' => 'Chef de DER',
        'ENSEIGNANT' => 'Enseignant',
        'RESPONSABLE' => 'Responsable de classe'
    ];
    return $labels[$role] ?? $role;
}

/**
 * Obtenir le libellé d'un état de semestre
 */
function getEtatSemestreLabel($etat) {
    $labels = [
        'En_cours' => '<span class="badge badge-success">En cours</span>',
        'Terminé' => '<span class="badge badge-secondary">Terminé</span>'
    ];
    return $labels[$etat] ?? $etat;
}

/**
 * Liste des classes disponibles
 */
function getClassesList() {
    return [
        'L1S1' => 'Licence 1 - Semestre 1',
        'L1S2' => 'Licence 1 - Semestre 2',
        'L2S3' => 'Licence 2 - Semestre 3',
        'L2S4' => 'Licence 2 - Semestre 4',
        'L3S5-Gén' => 'Licence 3 - Semestre 5 - Générale',
        'L3S5-Pro-Info' => 'Licence 3 - Semestre 5 - Professionnelle - Informatique',
        'L3S5-Pro-Telecom' => 'Licence 3 - Semestre 5 - Professionnelle - Télécommunication',
        'L3S6-Gén' => 'Licence 3 - Semestre 6 - Générale',
        'L3S6-Pro-Info' => 'Licence 3 - Semestre 6 - Professionnelle - Informatique',
        'L3S6-Pro-Telecom' => 'Licence 3 - Semestre 6 - Professionnelle - Télécommunication',
        'M1S1' => 'Master 1 - Semestre 1',
        'M1S2' => 'Master 1 - Semestre 2',
        'M2S3-GL' => 'Master 2 - Semestre 3 - Génie logiciel'
    ];
}

/**
 * Liste des grades disponibles
 */
function getGradesList() {
    return [
        'Assistant' => 'Assistant',
        'Maître Assistant' => 'Maître Assistant',
        'Maître de conférences' => 'Maître de conférences',
        'Professeur' => 'Professeur'
    ];
}

/**
 * Calculer le pourcentage d'avancement
 */
function calculerPourcentage($effectue, $total) {
    if ($total <= 0) return 0;
    return min(100, round(($effectue / $total) * 100, 1));
}

/**
 * Obtenir la classe CSS pour une barre de progression
 */
function getProgressBarClass($pourcentage) {
    if ($pourcentage >= 100) return 'progress-success';
    elseif ($pourcentage >= 75) return 'progress-info';
    elseif ($pourcentage >= 50) return 'progress-warning';
    else return 'progress-danger';
}

/**
 * Valider une date
 */
function validateDate($date, $format = 'Y-m-d') {
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}

/**
 * Nettoyer et valider un entier positif
 */
function validatePositiveInt($value) {
    $int = filter_var($value, FILTER_VALIDATE_INT);
    return ($int !== false && $int > 0) ? $int : false;
}

/**
 * Générer le chemin de base de l'application
 */
function basePath() {
    return '/gestion-heures/';
}

/**
 * Générer une URL absolue
 */
function url($path = '') {
    return basePath() . ltrim($path, '/');
}
?>
