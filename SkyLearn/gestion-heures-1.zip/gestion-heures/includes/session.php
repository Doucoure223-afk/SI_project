<?php
/**
 * ============================================================
 * Gestion des sessions et sécurité
 * ============================================================
 */

// Démarrer la session si pas déjà active
if (session_status() === PHP_SESSION_NONE) {
    // Configuration sécurisée des sessions
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_secure', 0); // Mettre à 1 en HTTPS
    
    session_start();
}

/**
 * Vérifier si l'utilisateur est connecté
 * @return bool
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Obtenir l'ID de l'utilisateur connecté
 * @return int|null
 */
function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Obtenir le rôle de l'utilisateur connecté
 * @return string|null
 */
function getCurrentUserRole() {
    return $_SESSION['user_role'] ?? null;
}

/**
 * Obtenir le nom complet de l'utilisateur
 * @return string
 */
function getCurrentUserName() {
    return ($_SESSION['user_prenom'] ?? '') . ' ' . ($_SESSION['user_nom'] ?? '');
}

/**
 * Vérifier si l'utilisateur a un rôle spécifique
 * @param string|array $roles Rôle ou tableau de rôles autorisés
 * @return bool
 */
function hasRole($roles) {
    if (!isLoggedIn()) {
        return false;
    }
    
    $currentRole = getCurrentUserRole();
    
    if (is_array($roles)) {
        return in_array($currentRole, $roles);
    }
    
    return $currentRole === $roles;
}

/**
 * Rediriger si non connecté
 * @param string $redirect URL de redirection
 */
function requireLogin($redirect = 'login.php') {
    if (!isLoggedIn()) {
        header("Location: " . $redirect);
        exit();
    }
}

/**
 * Rediriger si l'utilisateur n'a pas le rôle requis
 * @param string|array $roles Rôle(s) autorisé(s)
 * @param string $redirect URL de redirection
 */
function requireRole($roles, $redirect = 'unauthorized.php') {
    requireLogin();
    
    if (!hasRole($roles)) {
        header("Location: " . $redirect);
        exit();
    }
}

/**
 * Créer une session utilisateur
 * @param array $user Données utilisateur
 */
function createUserSession($user) {
    $_SESSION['user_id'] = $user['idUtilisateurs'];
    $_SESSION['user_login'] = $user['Login'];
    $_SESSION['user_nom'] = $user['Nom'];
    $_SESSION['user_prenom'] = $user['Prenom'];
    $_SESSION['user_role'] = $user['Role'];
    $_SESSION['login_time'] = time();
    
    // Régénérer l'ID de session pour la sécurité
    session_regenerate_id(true);
}

/**
 * Détruire la session utilisateur
 */
function destroyUserSession() {
    $_SESSION = [];
    
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    session_destroy();
}

/**
 * Générer un token CSRF
 * @return string
 */
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Vérifier le token CSRF
 * @param string $token Token à vérifier
 * @return bool
 */
function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Afficher un message flash
 * @param string $type Type de message (success, error, warning, info)
 * @param string $message Message à afficher
 */
function setFlashMessage($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

/**
 * Obtenir et supprimer le message flash
 * @return array|null
 */
function getFlashMessage() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}
?>
