<?php
/**
 * Point d'entrée - Liste des unités d'enseignement
 */
require_once __DIR__ . '/../controllers/ModuleController.php';

$controller = new ModuleController();
$controller->listUnites();
?>
