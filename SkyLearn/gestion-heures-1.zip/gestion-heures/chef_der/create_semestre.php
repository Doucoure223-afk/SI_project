<?php
/**
 * Point d'entrée - Création semestre
 */
require_once __DIR__ . '/../controllers/ModuleController.php';

$controller = new ModuleController();
$controller->createSemestre();
?>
