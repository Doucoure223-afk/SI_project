<?php
/**
 * Point d'entrée - Modification module
 */
require_once __DIR__ . '/../controllers/ModuleController.php';

$controller = new ModuleController();
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

if (!$id) {
    header("Location: modules.php");
    exit();
}

$controller->updateModule($id);
?>
