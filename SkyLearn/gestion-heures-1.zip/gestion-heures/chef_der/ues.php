<?php
/**
 * Point d'entrée - Liste des unités d'enseignement (alias)
 */
require_once __DIR__ . '/../controllers/ModuleController.php';

$controller = new ModuleController();
$controller->listUnites();
?>
