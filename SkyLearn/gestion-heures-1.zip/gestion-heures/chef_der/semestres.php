<?php
/**
 * Point d'entrée - Liste des semestres
 */
require_once __DIR__ . '/../controllers/ModuleController.php';

$controller = new ModuleController();
$controller->listSemestres();
?>
