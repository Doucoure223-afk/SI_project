<?php
/**
 * Point d'entrée - Modification unité d'enseignement
 */
require_once __DIR__ . '/../controllers/ModuleController.php';

$controller = new ModuleController();
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

if (!$id) {
    header("Location: unites.php");
    exit();
}

$controller->updateUnite($id);
?>
