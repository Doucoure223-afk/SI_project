<?php
/**
 * Point d'entrée - Modification semestre
 */
require_once __DIR__ . '/../controllers/ModuleController.php';

$controller = new ModuleController();
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

if (!$id) {
    header("Location: semestres.php");
    exit();
}

$controller->updateSemestre($id);
?>
