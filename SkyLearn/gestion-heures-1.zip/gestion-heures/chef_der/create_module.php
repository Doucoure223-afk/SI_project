<?php
/**
 * Point d'entrée - Création module
 */
require_once __DIR__ . '/../controllers/ModuleController.php';

$controller = new ModuleController();
$controller->createModule();
?>
