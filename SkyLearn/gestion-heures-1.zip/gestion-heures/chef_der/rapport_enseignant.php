<?php
/**
 * Point d'entrée - Rapport par enseignant
 */
require_once __DIR__ . '/../controllers/RapportController.php';

$controller = new RapportController();
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$controller->rapportEnseignant($id);
?>
