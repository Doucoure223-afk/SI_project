<?php
/**
 * Point d'entrée - Formulaire module
 */
require_once __DIR__ . '/../controllers/ModuleController.php';

$controller = new ModuleController();
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$controller->moduleForm($id);
?>
