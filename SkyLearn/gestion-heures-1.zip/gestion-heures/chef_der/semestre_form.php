<?php
/**
 * Point d'entrée - Formulaire semestre
 */
require_once __DIR__ . '/../controllers/ModuleController.php';

$controller = new ModuleController();
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$controller->semestreForm($id);
?>
