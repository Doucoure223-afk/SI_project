<?php
/**
 * Point d'entrée - Formulaire unité d'enseignement
 */
require_once __DIR__ . '/../controllers/ModuleController.php';

$controller = new ModuleController();
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$controller->uniteForm($id);
?>
