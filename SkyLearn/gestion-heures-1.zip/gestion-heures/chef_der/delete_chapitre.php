<?php
/**
 * Point d'entrée - Suppression chapitre
 */
require_once __DIR__ . '/../controllers/ModuleController.php';

$controller = new ModuleController();
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

if (!$id) {
    header("Location: chapitres.php");
    exit();
}

$controller->deleteChapitre($id);
?>
