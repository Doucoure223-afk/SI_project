<?php
/**
 * Point d'entrée - Création unité d'enseignement
 */
require_once __DIR__ . '/../controllers/ModuleController.php';

$controller = new ModuleController();
$controller->createUnite();
?>
