<?php
/**
 * Point d'entrée - Rapport par enseignants (liste)
 */
require_once __DIR__ . '/../controllers/RapportController.php';

$controller = new RapportController();

if (isset($_GET['id'])) {
    $controller->rapportEnseignant((int)$_GET['id']);
} else {
    $controller->listeRapportEnseignants();
}
?>
