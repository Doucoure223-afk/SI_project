<?php
/**
 * Point d'entrée - Clôture d'un semestre
 */
require_once __DIR__ . '/../controllers/ModuleController.php';

$controller = new ModuleController();
$controller->cloturerSemestre();
?>
