<?php
/**
 * Point d'entrée - Rapport global
 */
require_once __DIR__ . '/../controllers/RapportController.php';

$controller = new RapportController();
$controller->rapportGlobal();
?>
