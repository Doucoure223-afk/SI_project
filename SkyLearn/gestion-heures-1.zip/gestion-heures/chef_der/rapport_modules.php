<?php
/**
 * Point d'entrée - Rapport par modules (liste)
 */
require_once __DIR__ . '/../controllers/RapportController.php';

$controller = new RapportController();

if (isset($_GET['id'])) {
    $controller->rapportModule((int)$_GET['id']);
} else {
    $controller->listeRapportModules();
}
?>
