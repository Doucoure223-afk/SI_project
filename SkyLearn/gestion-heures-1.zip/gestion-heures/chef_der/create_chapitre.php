<?php
/**
 * Point d'entrée - Création chapitre
 */
require_once __DIR__ . '/../controllers/ModuleController.php';

$controller = new ModuleController();
$controller->createChapitre();
?>
