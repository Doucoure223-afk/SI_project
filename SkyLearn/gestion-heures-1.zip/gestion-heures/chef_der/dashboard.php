<?php
/**
 * Point d'entrée - Dashboard Chef de DER
 */
require_once __DIR__ . '/../controllers/ModuleController.php';

$controller = new ModuleController();
$controller->dashboard();
?>
