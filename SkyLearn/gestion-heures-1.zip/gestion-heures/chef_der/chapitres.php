<?php
/**
 * Point d'entrée - Liste des chapitres
 */
require_once __DIR__ . '/../controllers/ModuleController.php';

$controller = new ModuleController();
$controller->listChapitres();
?>
