<?php
/**
 * Point d'entrée - Liste des modules
 */
require_once __DIR__ . '/../controllers/ModuleController.php';

$controller = new ModuleController();
$controller->listModules();
?>
