<?php
/**
 * Page de connexion - Point d'entrée
 */
require_once __DIR__ . '/controllers/AuthController.php';
?>
